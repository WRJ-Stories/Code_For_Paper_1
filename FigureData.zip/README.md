# Figure Data

This directory contains the source data used to generate all figures in the manuscript. Files should be organized or named so that each dataset can be linked to its corresponding figure and panel (for example, Figure 1A, Figure 1B, and so on). Please consult the associated figure legends when interpreting these data.
