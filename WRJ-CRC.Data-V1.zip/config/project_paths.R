# Shared, machine-independent project paths.
# Run scripts from the repository root (open WRJ-CRC.Rproj in RStudio).
PROJECT_ROOT <- normalizePath(Sys.getenv("WRJCRC_PROJECT_ROOT", unset = getwd()),
                              winslash = "/", mustWork = TRUE)
if (!file.exists(file.path(PROJECT_ROOT, ".here"))) {
  stop("Project root not detected. Open WRJ-CRC.Rproj or run Rscript from the repository root.",
       call. = FALSE)
}
DATA_ROOT <- file.path(PROJECT_ROOT, "Rawdata")
PUBLIC_DATA_DIR <- file.path(DATA_ROOT, "public_cohort")
CLINICAL_DATA_DIR <- file.path(DATA_ROOT, "clinical_cohort")
AP_META_DATA_DIR <- file.path(DATA_ROOT, "ap_meta_analysis")
RESULTS_ROOT <- file.path(PROJECT_ROOT, "results")
RESULTS <- list(
  differential = file.path(RESULTS_ROOT, "differential"),
  lefse = file.path(RESULTS_ROOT, "lefse"),
  maaslin3 = file.path(RESULTS_ROOT, "maaslin3"),
  lasso = file.path(RESULTS_ROOT, "lasso"),
  bayesian = file.path(RESULTS_ROOT, "bayesian"),
  random_forest = file.path(RESULTS_ROOT, "random_forest_shap"),
  importance = file.path(RESULTS_ROOT, "importance_scoring"),
  mrmr = file.path(RESULTS_ROOT, "mrmr"),
  ap_meta = file.path(RESULTS_ROOT, "ap_meta_analysis"),
  network = file.path(RESULTS_ROOT, "microbial_network"),
  classification = file.path(RESULTS_ROOT, "classification"),
  performance = file.path(RESULTS_ROOT, "performance_improvement")
)
GROUP_HC <- Sys.getenv("WRJCRC_GROUP_HC", unset = "HC")
GROUP_AP <- Sys.getenv("WRJCRC_GROUP_AP", unset = "AP")
GROUP_CRC <- Sys.getenv("WRJCRC_GROUP_CRC", unset = "CRC")
ensure_dir <- function(path) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  normalizePath(path, winslash = "/", mustWork = TRUE)
}
assert_files_exist <- function(paths, context = "input") {
  missing <- paths[!file.exists(paths)]
  if (length(missing)) stop("Missing ", context, " file(s):\n", paste(missing, collapse = "\n"),
                            call. = FALSE)
  invisible(paths)
}
