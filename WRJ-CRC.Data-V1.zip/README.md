# WRJ-CRC: Analysis code

This repository contains the computational analysis code accompanying a study of stool *SDC2* methylation (mSDC2), gut microbiome features, and colorectal cancer (CRC).

**The full patient-level clinical and metagenomic input datasets are not distributed in this repository.** The `Figure Data/` directory contains the source data used for all figures in the manuscript. The full cohort-level input files remain separate and should only be placed in the local `data/` directory when access and redistribution are permitted. The local `data/` directory is excluded from version control.

## Repository contents

```text
WRJ-CRC/
├── Figure Data/                  # Source data underlying all manuscript figures
├── config/
│   └── project_paths.R
├── data/                         # Local input data; not tracked by Git
│   ├── public_cohort/
│   ├── ap_meta_analysis/
│   └── clinical_cohort/
├── results/                      # Generated results; not tracked by Git
└── scripts/
    ├── differential/
    │   ├── lefse_analysis.R
    │   └── maaslin3_analysis.R
    ├── feature_selection/
    │   ├── lasso_regression.R
    │   ├── bayesian_regression.R
    │   ├── random_forest_shap_analysis.R
    │   ├── importance_scoring.R
    │   ├── mrmr_screening.R
    │   └── mrmr_panel_core.R
    ├── meta_analysis/
    │   └── ap_clr_meta_analysis.R
    ├── microbial_network/
    │   └── network_module_analysis.R
    ├── classification/
    │   ├── crc_msd2_microbiome_nested_analysis.R
    │   └── crc_msd2_performance_improvement_analysis.R
    └── dki_keystoneness/
        ├── dki_calculate.py
        └── Keystoneness_computing.R
```

## Data availability and access

The full analysis input datasets are not provided in this repository. These include public-cohort working tables and the complete clinical/metagenomic study datasets. In particular, the full patient-level clinical records, sample-level metadata, sequencing abundance matrices, qPCR measurements, and patient-level prediction files are not distributed here. The separate `Figure Data/` directory contains the data used to generate all manuscript figures and should be consulted alongside the corresponding figure and panel labels.

Data availability information, including relevant public database accession numbers and the conditions for accessing study-specific data, will be provided in the associated manuscript and repository record. Reproducing the complete analyses requires obtaining the corresponding input datasets through the appropriate data sources and permissions.

**Do not upload data to GitHub merely to make the scripts runnable.** Confirm that each dataset can be redistributed and that institutional, ethics, consent, and data-use requirements permit public release before publishing any data or derived files.

## Local setup

1. Clone or download this repository.
2. Open `WRJ-CRC.Rproj` in RStudio, or run commands from the repository root.
3. Place the required input files in the corresponding local subdirectories under `data/`.
4. Install the R/Python dependencies listed below.
5. Run the scripts in the workflow order described in the next section.

The scripts use project-relative paths configured in `config/project_paths.R`; they do not require editing computer-specific absolute paths. `WRJCRC_PROJECT_ROOT` can be set if scripts are launched from outside the repository root. For the classification workflow, `SDC2_INPUT_DIR` can be set to an external clinical-cohort directory if the files are not stored under `data/clinical_cohort/`; the network workflow accepts `--project-dir` for the same purpose.

### Expected local input files

The following filenames document the input interface expected by the scripts. The files themselves are intentionally absent from this repository.

#### `data/public_cohort/`

| File | Main use |
|---|---|
| `metadata_filtered.txt` | LEfSe, MaAsLin3, LASSO, Bayesian regression, RF/SHAP, and mRMR metadata |
| `taxonomy_species.txt` | Species-by-sample abundance table |
| `species_for_adenoma.txt` | Candidate AP species list for LASSO |
| `species_for_crc.txt` | Candidate CRC species list for LASSO |
| `Diff_ks.txt` | Species-level distribution summaries and effect-size inputs for composite importance scoring |

The metadata must contain the sample identifiers and group labels required by each script. The mRMR workflow additionally expects `Sample_ID`, `Project_ID`, and `Group`. The abundance table is expected to contain a species/taxonomy identifier column and sample columns. The `Diff_ks.txt` input is expected to contain the columns `species_name`, `median_hc`, `median_ade`, `diff_ade_vs_hc`, `median_crc`, and `diff_crc_vs_hc`.

The LASSO workflow creates candidate feature lists under `results/`, which are consumed by downstream Bayesian and RF/SHAP analyses.

#### `data/ap_meta_analysis/`

| File | Main use |
|---|---|
| `metadata_filtered.txt` | Project and group metadata for AP meta-analysis |
| `taxonomy_species.txt` | Species-by-sample abundance table |
| `self_select_species_ap.txt` | Prespecified AP candidate species used by the meta-analysis |

The AP ranking file consumed by the meta-analysis is generated by the importance-scoring workflow under `results/`; it should not be manually copied into the input directory.

#### `data/clinical_cohort/`

| File | Main use |
|---|---|
| `NF_Cohort_1.txt` | Source cohort (452 participants) used to estimate the mSDC2 baseline component |
| `NF_Cohort2.txt` | Clinical MGS cohort metadata (349 participants) for model development and network analyses |
| `taxonomy_Species.txt` | Species-by-sample abundance table |
| `self_selected_microbiota.txt` | Selected microbiome features used by the nested model |
| `pathabundance_relab3_stratified.tsv` | HUMAnN pathway abundance input |
| `level4ec_relab_stratified.tsv` | HUMAnN level-4 EC abundance input |

For `NF_Cohort_1.txt`, `ID` is the participant identifier; `Cohort`, `Group_All`, and `SDC2_Category` are used to define the source-cohort records and clinical groups. The former `SampleID` field is no longer required.

For `NF_Cohort2.txt`, `ID` is the participant identifier and `Sequence_ID` is the sequencing/sample identifier. `Sequence_ID` is used to match the clinical metadata to the sample columns in `taxonomy_Species.txt` and the HUMAnN functional tables; the former `EP_ID` and `SampleID` fields are no longer required. The file also provides `Sub_Group`, `Group`, `SDC2_Category`, `Age`, and `Gender` for downstream analyses.

Exact column names, factor levels, and sample-ID conventions are validated by the individual scripts. Consult the input-reading sections of each script before preparing local files.

## Analysis workflow

Run the analyses from the repository root. The general order is:

1. Differential microbial association analyses using LEfSe and MaAsLin 3.
2. LASSO-based candidate feature selection in the public cohort.
3. Bayesian regression and random-forest/SHAP analyses using the selected feature lists.
4. Composite species-importance scoring for AP- and CRC-related candidates.
5. Project-grouped mRMR feature-panel screening.
6. AP cross-project CLR meta-analysis.
7. Nested mSDC2–microbiome classification modelling and internal validation.
8. Incremental diagnostic-performance evaluation using the nested model's out-of-fold predictions.
9. Microbial network and module analyses.
10. DKI/keystoneness calculations, when the corresponding model outputs and mapping files are available locally.

Example commands:

```bash
Rscript scripts/differential/lefse_analysis.R
Rscript scripts/differential/maaslin3_analysis.R
Rscript scripts/feature_selection/lasso_regression.R
Rscript scripts/feature_selection/bayesian_regression.R
Rscript scripts/feature_selection/random_forest_shap_analysis.R
Rscript scripts/feature_selection/importance_scoring.R
Rscript scripts/feature_selection/mrmr_screening.R --tasks=AP,CRC
Rscript scripts/meta_analysis/ap_clr_meta_analysis.R
Rscript scripts/classification/crc_msd2_microbiome_nested_analysis.R
Rscript scripts/classification/crc_msd2_performance_improvement_analysis.R
Rscript scripts/microbial_network/network_module_analysis.R
```

The mRMR script also provides a `--smoke` option for a limited code-path check and the network script provides `--validate-only` for input validation. These options are not substitutes for the full analysis and must not be used to generate manuscript results.

The DKI/keystoneness scripts have their own input layout and dependencies. Review their input-reading sections and configure the expected local working directory before execution.

## Outputs

Machine-readable intermediate and final analysis outputs are written under `results/`. These files are excluded from Git by default because some may contain sample-level or otherwise sensitive derived information. This includes model objects, out-of-fold predictions, bootstrap outputs, coefficients, feature rankings, and intermediate tables.

The `Figure Data/` directory contains the source data for all manuscript figures. It is distinct from the full cohort-level input data under `data/`, and figure data should be interpreted together with the corresponding figure legends and panel labels. The repository does not include the manuscript figure artwork or a complete figure-formatting workflow. The analytical scripts retain the tabular/model outputs required for downstream analyses and computational auditing.

## Software and dependencies

The R workflows use packages including (depending on the script): `data.table`, `dplyr`, `tidyr`, `purrr`, `tibble`, `readr`, `glmnet`, `brms`, `posterior`, `ranger`, `fastshap`, `pROC`, `microeco`, `maaslin3`, `metafor`, `SpiecEasi`, `igraph`, `zCompositions`, `limma`, `future`, `future.apply`, `mRMRe`, and `brglm2`.

The DKI Python workflow uses Python packages including PyTorch and NumPy. The exact package versions should be recorded for the computational environment used to produce the final manuscript results. `brms` requires a working Stan backend.

For reproducibility, users should record `R.version`, `sessionInfo()`, Python version, and installed package versions. A package lockfile (for example, `renv.lock`) can be added after the final analysis environment has been frozen.

