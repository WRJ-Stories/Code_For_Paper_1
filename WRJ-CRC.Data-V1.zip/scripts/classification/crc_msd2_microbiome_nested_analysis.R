#!/usr/bin/env Rscript

# Nested internal validation for the mSDC2 + microbiome diagnostic models.
# This is a new analysis-only pipeline. It does not source, modify, or overwrite
# CRC_mSDC2_microbiome_pipeline.R and it does not create figures.

env_or <- function(name, default) {
  value <- Sys.getenv(name, unset = "")
  if (nzchar(value)) value else default
}

env_int <- function(name, default) {
  value <- suppressWarnings(as.integer(Sys.getenv(name, unset = "")))
  if (length(value) == 1L && is.finite(value)) value else as.integer(default)
}

env_num <- function(name, default) {
  value <- suppressWarnings(as.numeric(Sys.getenv(name, unset = "")))
  if (length(value) == 1L && is.finite(value)) value else as.numeric(default)
}

source(file.path("config", "project_paths.R"))
INPUT_DIR <- normalizePath(env_or("SDC2_INPUT_DIR", CLINICAL_DATA_DIR),
                           winslash = "/", mustWork = TRUE)
OUTPUT_DIR <- env_or("SDC2_OUTPUT_DIR", RESULTS$classification)

CONFIG <- list(
  nfyy_file = file.path(INPUT_DIR, "NF_Cohort_1.txt"),
  nfyy_source_cohort = "NF_Cohort1",
  expected_nfyy_source_n = 452L,
  mgs_meta_file = file.path(INPUT_DIR, "NF_Cohort2.txt"),
  abundance_file = file.path(INPUT_DIR, "taxonomy_Species.txt"),
  feature_file = file.path(INPUT_DIR, "self_selected_microbiota.txt"),
  output_dir = OUTPUT_DIR,
  seed = env_int("SDC2_SEED", 20260730L),
  b_boot = env_int("SDC2_B_BOOT", 1000L),
  outer_folds = env_int("SDC2_OUTER_FOLDS", 5L),
  inner_folds = env_int("SDC2_INNER_FOLDS", 5L),
  lambda_rule = env_or("SDC2_LAMBDA_RULE", "lambda.1se"),
  abundance_total = 100,
  roc_grid = seq(0, 1, by = 0.01),
  min_boot_success_rate = env_num("SDC2_MIN_BOOT_SUCCESS", 0.90),
  selected_tasks = strsplit(env_or(
    "SDC2_TASKS",
    "ACN,CRC_SPECIFICITY,NC_ADVANCED,NC_CRC,BENIGN_LESION"
  ), ",", fixed = TRUE)[[1]]
)

TASKS <- list(
  ACN = list(
    positive = c("APL", "CRC"),
    negative = c("NC", "NACL"),
    feature_panel = "CRC"
  ),
  CRC_SPECIFICITY = list(
    positive = "CRC",
    negative = c("NACL", "APL"),
    feature_panel = "CRC"
  ),
  NC_ADVANCED = list(
    positive = c("APL", "CRC"),
    negative = "NC",
    feature_panel = "CRC"
  ),
  NC_CRC = list(
    positive = "CRC",
    negative = "NC",
    feature_panel = "CRC"
  ),
  BENIGN_LESION = list(
    positive = c("NACL", "APL"),
    negative = "NC",
    feature_panel = "AP"
  )
)

CHALLENGE_GROUPS <- c(
  "NCRM",
  "ASP",
  "CRID",
  'PUCP'
)

required_packages <- c(
  "data.table", "dplyr", "tidyr", "purrr", "tibble",
  "glmnet", "pROC", "brglm2"
)
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) {
  stop(
    "缺少R包: ", paste(missing_packages, collapse = ", "),
    "。请先安装后再运行。", call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(tibble)
  library(glmnet)
  library(pROC)
  library(brglm2)
})

stopf <- function(...) stop(sprintf(...), call. = FALSE)
assert_true <- function(condition, ...) if (!isTRUE(condition)) stopf(...)

make_seed <- function(...) {
  parts <- list(...)
  key <- paste(vapply(
    parts,
    function(x) paste(as.character(x), collapse = ","),
    character(1)
  ), collapse = "|")
  bytes <- utf8ToInt(enc2utf8(key))
  modulus <- as.double(.Machine$integer.max - 1L)
  hash <- 0
  for (byte in bytes) {
    hash <- (hash * 131 + as.double(byte)) %% modulus
  }
  as.integer(hash + 1)
}

build_seed_plan <- function(base_seed, task_names, n_replicates) {
  rows <- list(data.frame(
    task = NA_character_, stage = "global", replicate = NA_integer_,
    seed = make_seed(base_seed, "global")
  ))
  for (task_name in task_names) {
    rows[[length(rows) + 1L]] <- data.frame(
      task = task_name, stage = "central", replicate = NA_integer_,
      seed = make_seed(base_seed, "central", task_name)
    )
    rows[[length(rows) + 1L]] <- data.frame(
      task = task_name, stage = "final_locked", replicate = NA_integer_,
      seed = make_seed(base_seed, "final_locked", task_name)
    )
    for (replicate in seq_len(n_replicates)) {
      workflow_seed <- make_seed(
        base_seed, "bootstrap_workflow", task_name, replicate
      )
      rows[[length(rows) + 1L]] <- data.frame(
        task = task_name, stage = "bootstrap_resample", replicate = replicate,
        seed = make_seed(base_seed, "bootstrap_resample", task_name, replicate)
      )
      rows[[length(rows) + 1L]] <- data.frame(
        task = task_name, stage = "bootstrap_workflow", replicate = replicate,
        seed = workflow_seed
      )
      rows[[length(rows) + 1L]] <- data.frame(
        task = task_name, stage = "bootstrap_locked", replicate = replicate,
        seed = make_seed(workflow_seed, "bootstrap_locked")
      )
    }
  }
  plan <- do.call(rbind, rows)
  rownames(plan) <- NULL
  assert_true(
    !anyDuplicated(plan$seed),
    "当前配置生成了重复随机种，请更换SDC2_SEED后重试。"
  )
  plan
}

assert_columns <- function(x, cols, object_name) {
  missing <- setdiff(cols, names(x))
  if (length(missing) > 0L) {
    stopf("%s缺少字段: %s", object_name, paste(missing, collapse = ", "))
  }
}

clip_prob <- function(p, eps = 1e-6) pmin(pmax(as.numeric(p), eps), 1 - eps)

write_csv <- function(x, name) {
  write.csv(
    x, file.path(CONFIG$output_dir, "tables", name),
    row.names = FALSE, fileEncoding = "UTF-8"
  )
}

for (subdir in c("tables", "rds")) {
  dir.create(file.path(CONFIG$output_dir, subdir), recursive = TRUE, showWarnings = FALSE)
}

assert_true(CONFIG$b_boot >= 1L, "SDC2_B_BOOT必须至少为1。")
assert_true(CONFIG$outer_folds >= 3L, "外层折数必须至少为3。")
assert_true(CONFIG$inner_folds >= 3L, "内层折数必须至少为3。")
assert_true(CONFIG$lambda_rule %in% c("lambda.1se", "lambda.min"),
            "SDC2_LAMBDA_RULE只能是lambda.1se或lambda.min。")
assert_true(all(CONFIG$selected_tasks %in% names(TASKS)),
            "SDC2_TASKS包含未知任务。")
TASKS <- TASKS[CONFIG$selected_tasks]
assert_true(CONFIG$seed >= 1L, "SDC2_SEED必须是正整数。")
SEED_PLAN <- build_seed_plan(CONFIG$seed, names(TASKS), CONFIG$b_boot)
write_csv(SEED_PLAN, "00a_seed_plan_audit.csv")
set.seed(make_seed(CONFIG$seed, "global"))

task_subset <- function(meta, task_def, group_col) {
  keep_groups <- c(task_def$positive, task_def$negative)
  out <- meta %>%
    filter(.data[[group_col]] %in% keep_groups) %>%
    mutate(outcome = as.integer(.data[[group_col]] %in% task_def$positive))
  assert_true(nrow(out) > 0L && length(unique(out$outcome)) == 2L,
              "任务分组后没有同时包含阳性和阴性样本。")
  out
}

fit_bias_reduced_logistic <- function(formula, data) {
  glm(
    formula = formula, data = data, family = binomial(),
    method = brglm2::brglmFit, type = "AS_mean", maxit = 100
  )
}

make_grouped_stratified_foldid <- function(y, ids, nfolds = 5L, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  id_outcome <- tibble(id = as.character(ids), outcome = as.integer(y)) %>% distinct()
  assert_true(
    nrow(id_outcome) == n_distinct(id_outcome$id),
    "同一患者ID在当前数据中对应不同结局。"
  )
  min_class <- min(table(id_outcome$outcome))
  k <- min(as.integer(nfolds), as.integer(min_class))
  assert_true(k >= 3L, "某一类别的独立患者少于3例，无法进行交叉验证。")
  id_outcome$fold <- 0L
  for (lev in sort(unique(id_outcome$outcome))) {
    idx <- sample(which(id_outcome$outcome == lev))
    id_outcome$fold[idx] <- rep(seq_len(k), length.out = length(idx))
  }
  foldid <- id_outcome$fold[match(as.character(ids), id_outcome$id)]
  attr(foldid, "nfolds") <- k
  foldid
}

stratified_bootstrap_indices <- function(y) {
  unlist(lapply(split(seq_along(y), y), function(idx) {
    sample(idx, length(idx), replace = TRUE)
  }), use.names = FALSE)
}

fit_msdc2_model <- function(source_task) {
  list(fit = fit_bias_reduced_logistic(outcome ~ msdc2_bin, source_task))
}

predict_msdc2_lp <- function(model, new_meta) {
  as.numeric(predict(model$fit, newdata = new_meta, type = "link"))
}

fit_microbiome_model <- function(train_meta, abundance, features, seed) {
  x_raw <- abundance[train_meta$Sequence_ID, features, drop = FALSE]
  positive <- x_raw[x_raw > 0]
  assert_true(length(positive) > 0L, "训练集中固定8物种面板全部为零。")
  pseudocount <- min(positive) / 2
  x_log2 <- log2(x_raw + pseudocount)
  foldid <- make_grouped_stratified_foldid(
    train_meta$outcome, train_meta$ID, CONFIG$inner_folds, seed
  )
  cvfit <- withCallingHandlers(
    cv.glmnet(
      x = x_log2,
      y = train_meta$outcome,
      family = "binomial",
      alpha = 0,
      foldid = foldid,
      type.measure = "deviance",
      standardize = TRUE,
      intercept = TRUE
    ),
    warning = function(w) {
      if (grepl("fewer than 8\\s+observations", conditionMessage(w))) {
        invokeRestart("muffleWarning")
      }
    }
  )
  lambda_value <- cvfit[[CONFIG$lambda_rule]]
  assert_true(length(lambda_value) == 1L && is.finite(lambda_value),
              "岭回归未得到有效lambda。")
  list(
    cvfit = cvfit,
    features = features,
    pseudocount = pseudocount,
    lambda_value = lambda_value,
    lambda_rule = CONFIG$lambda_rule,
    training_sd_log2 = apply(x_log2, 2, sd),
    tuning_folds = attr(foldid, "nfolds")
  )
}

predict_microbiome <- function(model, new_meta, abundance, type = c("link", "response")) {
  type <- match.arg(type)
  x_raw <- abundance[new_meta$Sequence_ID, model$features, drop = FALSE]
  x_log2 <- log2(x_raw + model$pseudocount)
  as.numeric(predict(
    model$cvfit, newx = x_log2, s = model$lambda_value, type = type
  ))
}

extract_microbiome_coefficients <- function(model) {
  cm <- as.matrix(coef(model$cvfit, s = model$lambda_value))
  out <- tibble(term = rownames(cm), coefficient = as.numeric(cm[, 1]))
  out %>%
    mutate(
      standardized_coefficient = ifelse(
        term == "(Intercept)", NA_real_,
        coefficient * model$training_sd_log2[match(term, names(model$training_sd_log2))]
      ),
      lambda = model$lambda_value,
      pseudocount = model$pseudocount
    )
}

inner_oof_microbiome <- function(train_meta, abundance, features, seed) {
  foldid <- make_grouped_stratified_foldid(
    train_meta$outcome, train_meta$ID, CONFIG$inner_folds, seed
  )
  oof <- rep(NA_real_, nrow(train_meta))
  for (fold in sort(unique(foldid))) {
    analysis_idx <- which(foldid != fold)
    assessment_idx <- which(foldid == fold)
    model <- fit_microbiome_model(
      train_meta[analysis_idx, , drop = FALSE], abundance, features,
      make_seed(seed, "inner_fit", fold)
    )
    oof[assessment_idx] <- predict_microbiome(
      model, train_meta[assessment_idx, , drop = FALSE], abundance, "link"
    )
  }
  assert_true(all(is.finite(oof)), "内层OOF菌群评分存在非有限值。")
  list(score = oof, nfolds = attr(foldid, "nfolds"))
}

fit_bridge_models <- function(bridge_meta, msdc2_lp, micro_lp) {
  dat <- bridge_meta %>% mutate(
    msdc2_lp = as.numeric(msdc2_lp), micro_lp = as.numeric(micro_lp)
  )
  micro_estimable <- is.finite(sd(dat$micro_lp)) &&
    sd(dat$micro_lp) > sqrt(.Machine$double.eps)
  
  msdc2_offset <- fit_bias_reduced_logistic(
    outcome ~ 1 + offset(msdc2_lp), dat
  )
  if (micro_estimable) {
    combined_offset <- fit_bias_reduced_logistic(
      outcome ~ micro_lp + offset(msdc2_lp), dat
    )
    combined_free <- fit_bias_reduced_logistic(
      outcome ~ msdc2_lp + micro_lp, dat
    )
  } else {
    combined_offset <- msdc2_offset
    combined_free <- fit_bias_reduced_logistic(outcome ~ msdc2_lp, dat)
  }
  list(
    msdc2_offset = msdc2_offset,
    combined_offset = combined_offset,
    combined_free = combined_free,
    micro_increment_estimable = micro_estimable
  )
}

predict_bridge_models <- function(models, msdc2_lp, micro_lp) {
  newdat <- data.frame(msdc2_lp = as.numeric(msdc2_lp), micro_lp = as.numeric(micro_lp))
  list(
    mSDC2 = as.numeric(predict(models$msdc2_offset, newdat, type = "response")),
    Microbiome = plogis(micro_lp),
    Combined_offset = as.numeric(predict(models$combined_offset, newdat, type = "response")),
    Combined_free_sensitivity = as.numeric(predict(models$combined_free, newdat, type = "response"))
  )
}

coef_or <- function(fit, term, default = NA_real_) {
  value <- coef(fit)
  if (term %in% names(value)) unname(value[[term]]) else default
}

extract_bridge_coefficients <- function(models) {
  bind_rows(
    tibble(
      bridge_model = "mSDC2_offset",
      term = c("(Intercept)", "msdc2_lp_offset_fixed"),
      coefficient = c(coef_or(models$msdc2_offset, "(Intercept)"), 1)
    ),
    tibble(
      bridge_model = "Combined_offset",
      term = c("(Intercept)", "msdc2_lp_offset_fixed", "micro_lp"),
      coefficient = c(
        coef_or(models$combined_offset, "(Intercept)"), 1,
        coef_or(models$combined_offset, "micro_lp", 0)
      )
    ),
    tibble(
      bridge_model = "Combined_free_sensitivity",
      term = c("(Intercept)", "msdc2_lp", "micro_lp"),
      coefficient = c(
        coef_or(models$combined_free, "(Intercept)"),
        coef_or(models$combined_free, "msdc2_lp"),
        coef_or(models$combined_free, "micro_lp", 0)
      )
    )
  ) %>% mutate(micro_increment_estimable = models$micro_increment_estimable)
}

features_for_task <- function(task_def, feature_table) {
  out <- feature_table %>%
    filter(Model == task_def$feature_panel) %>%
    distinct(Species) %>%
    pull(Species)
  assert_true(length(out) == 8L,
              "每个任务的固定物种面板去重后必须恰好为8个物种。")
  out
}

crossfit_task <- function(task_name, source_meta, bridge_meta, abundance,
                          feature_table, seed) {
  task_def <- TASKS[[task_name]]
  source_task <- task_subset(source_meta, task_def, group_col = "Sub_Group")
  bridge_task <- task_subset(bridge_meta, task_def, group_col = "Sub_Group")
  features <- features_for_task(task_def, feature_table)
  msdc2_model <- fit_msdc2_model(source_task)
  outer_foldid <- make_grouped_stratified_foldid(
    bridge_task$outcome, bridge_task$ID, CONFIG$outer_folds, seed
  )
  prediction_rows <- vector("list", max(outer_foldid))
  fold_rows <- vector("list", max(outer_foldid))

  for (fold in sort(unique(outer_foldid))) {
    train_idx <- which(outer_foldid != fold)
    valid_idx <- which(outer_foldid == fold)
    outer_train <- bridge_task[train_idx, , drop = FALSE]
    outer_valid <- bridge_task[valid_idx, , drop = FALSE]

    inner <- inner_oof_microbiome(
      outer_train, abundance, features,
      make_seed(seed, "outer_inner_oof", fold)
    )
    msdc2_train_lp <- predict_msdc2_lp(msdc2_model, outer_train)
    bridge_models <- fit_bridge_models(
      outer_train, msdc2_train_lp, inner$score
    )
    outer_micro_model <- fit_microbiome_model(
      outer_train, abundance, features,
      make_seed(seed, "outer_micro_fit", fold)
    )
    msdc2_valid_lp <- predict_msdc2_lp(msdc2_model, outer_valid)
    micro_valid_lp <- predict_microbiome(
      outer_micro_model, outer_valid, abundance, "link"
    )
    probs <- predict_bridge_models(bridge_models, msdc2_valid_lp, micro_valid_lp)

    prediction_rows[[fold]] <- tibble(
      task = task_name,
      outer_fold = fold,
      ID = outer_valid$ID,
      Sequence_ID = outer_valid$Sequence_ID,
      Group = outer_valid$Sub_Group,
      outcome = outer_valid$outcome,
      msdc2_lp = msdc2_valid_lp,
      micro_lp = micro_valid_lp,
      mSDC2 = probs$mSDC2,
      Microbiome = probs$Microbiome,
      Combined_offset = probs$Combined_offset,
      Combined_free_sensitivity = probs$Combined_free_sensitivity
    )
    fold_rows[[fold]] <- tibble(
      task = task_name,
      outer_fold = fold,
      n_train = nrow(outer_train),
      n_valid = nrow(outer_valid),
      positives_train = sum(outer_train$outcome),
      positives_valid = sum(outer_valid$outcome),
      inner_folds_used = inner$nfolds,
      ridge_tuning_folds = outer_micro_model$tuning_folds,
      bridge_gamma = coef_or(bridge_models$combined_offset, "micro_lp", 0)
    )
  }
  predictions <- bind_rows(prediction_rows)
  assert_true(nrow(predictions) == nrow(bridge_task),
              "外层OOF预测数与任务样本数不一致。")
  list(
    predictions = predictions,
    fold_audit = bind_rows(fold_rows),
    outer_folds_used = attr(outer_foldid, "nfolds")
  )
}

fit_locked_task <- function(task_name, source_meta, bridge_meta, abundance,
                            feature_table, seed) {
  task_def <- TASKS[[task_name]]
  source_task <- task_subset(source_meta, task_def, group_col = "Sub_Group")
  bridge_task <- task_subset(bridge_meta, task_def, group_col = "Sub_Group")
  features <- features_for_task(task_def, feature_table)
  msdc2_model <- fit_msdc2_model(source_task)
  inner <- inner_oof_microbiome(
    bridge_task, abundance, features, make_seed(seed, "locked_inner_oof")
  )
  msdc2_lp <- predict_msdc2_lp(msdc2_model, bridge_task)
  bridge_models <- fit_bridge_models(bridge_task, msdc2_lp, inner$score)
  micro_model <- fit_microbiome_model(
    bridge_task, abundance, features, make_seed(seed, "locked_micro_fit")
  )
  list(
    task_name = task_name,
    task_def = task_def,
    source_task = source_task,
    bridge_task = bridge_task,
    msdc2 = msdc2_model,
    microbiome = micro_model,
    bridge = bridge_models,
    bridge_training_micro_oof = inner$score
  )
}

predict_locked_task <- function(model, new_meta, abundance) {
  msdc2_lp <- predict_msdc2_lp(model$msdc2, new_meta)
  micro_lp <- predict_microbiome(model$microbiome, new_meta, abundance, "link")
  list(
    msdc2_lp = msdc2_lp,
    micro_lp = micro_lp,
    probabilities = predict_bridge_models(model$bridge, msdc2_lp, micro_lp)
  )
}

average_precision <- function(y, p) {
  ord <- order(p, decreasing = TRUE)
  yy <- as.integer(y)[ord]
  if (sum(yy == 1L) == 0L) return(NA_real_)
  precision <- cumsum(yy == 1L) / seq_along(yy)
  mean(precision[yy == 1L])
}

threshold_for_minimum_specificity <- function(negative_scores, specificity = 0.95) {
  negative_scores <- as.numeric(negative_scores)
  assert_true(length(negative_scores) > 0L && all(is.finite(negative_scores)),
              "特异度阈值计算需要有限的阴性预测值。")
  values <- sort(unique(negative_scores))
  thresholds <- if (length(values) == 1L) {
    c(-Inf, Inf)
  } else {
    c(-Inf, values[-length(values)] + diff(values) / 2, Inf)
  }
  achieved <- vapply(
    thresholds, function(threshold) mean(negative_scores < threshold),
    numeric(1)
  )
  valid <- which(achieved >= specificity)
  index <- valid[[1]]
  list(
    threshold = thresholds[[index]],
    achieved_specificity = achieved[[index]]
  )
}

sensitivity_at_specificity <- function(y, p, specificity = 0.95) {
  neg <- p[y == 0L]
  pos <- p[y == 1L]
  if (length(neg) == 0L || length(pos) == 0L) return(NA_real_)
  cutoff <- threshold_for_minimum_specificity(neg, specificity)
  mean(pos >= cutoff$threshold)
}

calibration_stats <- function(y, p) {
  dat <- data.frame(y = as.integer(y), lp = qlogis(clip_prob(p)))
  intercept_fit <- try(fit_bias_reduced_logistic(y ~ 1 + offset(lp), dat), silent = TRUE)
  slope_fit <- try(fit_bias_reduced_logistic(y ~ lp, dat), silent = TRUE)
  c(
    cal_intercept = if (inherits(intercept_fit, "try-error")) NA_real_ else coef(intercept_fit)[[1]],
    cal_slope = if (inherits(slope_fit, "try-error")) NA_real_ else coef_or(slope_fit, "lp")
  )
}

calc_metrics <- function(y, p) {
  y <- as.integer(y)
  p <- clip_prob(p)
  if (length(unique(y)) < 2L) {
    return(tibble(
      AUROC = NA_real_, AUPRC_AP = NA_real_, Sens_at_Spec95 = NA_real_,
      Brier = NA_real_, cal_intercept = NA_real_, cal_slope = NA_real_
    ))
  }
  cal <- calibration_stats(y, p)
  tibble(
    AUROC = as.numeric(pROC::auc(y, p, levels = c(0, 1), direction = "<", quiet = TRUE)),
    AUPRC_AP = average_precision(y, p),
    Sens_at_Spec95 = sensitivity_at_specificity(y, p),
    Brier = mean((y - p)^2),
    cal_intercept = unname(cal[["cal_intercept"]]),
    cal_slope = unname(cal[["cal_slope"]])
  )
}

MODEL_NAMES <- c("mSDC2", "Microbiome", "Combined_offset", "Combined_free_sensitivity")

metrics_from_predictions <- function(predictions, sample_type) {
  predictions %>%
    group_split(task) %>%
    map_dfr(function(dat) {
      map_dfr(MODEL_NAMES, function(model_name) {
        calc_metrics(dat$outcome, dat[[model_name]]) %>%
          mutate(
            task = unique(dat$task), model = model_name,
            sample_type = sample_type, .before = 1
          )
      })
    })
}

subgroup_sensitivity_at_specificity <- function(
    predictions, sample_type, specificity = 0.95) {
  predictions %>%
    group_split(task) %>%
    map_dfr(function(dat) {
      task_def <- TASKS[[unique(dat$task)]]
      positive_subgroups = intersect(c("NACL", "APL", "CRC"), task_def$positive)
      map_dfr(MODEL_NAMES, function(model_name) {
        negative_scores <- dat[[model_name]][dat$outcome == 0L]
        assert_true(length(negative_scores) > 0L,
                    "亚组敏感度计算缺少阴性样本。")
        cutoff <- threshold_for_minimum_specificity(
          negative_scores, specificity
        )
        threshold <- cutoff$threshold
        achieved_specificity <- cutoff$achieved_specificity
        map_dfr(positive_subgroups, function(subgroup_name) {
          subgroup_scores <- dat[[model_name]][dat$Group == subgroup_name]
          tibble(
            task = unique(dat$task),
            model = model_name,
            sample_type = sample_type,
            subgroup = subgroup_name,
            subgroup_n = length(subgroup_scores),
            target_specificity = specificity,
            threshold = threshold,
            achieved_specificity = achieved_specificity,
            sensitivity = if (length(subgroup_scores) == 0L) {
              NA_real_
            } else {
              mean(subgroup_scores >= threshold)
            }
          )
        })
      })
    })
}

roc_grid_one <- function(y, p, grid = CONFIG$roc_grid) {
  roc_obj <- pROC::roc(y, p, levels = c(0, 1), direction = "<", quiet = TRUE)
  raw <- tibble(
    fpr = 1 - as.numeric(roc_obj$specificities),
    sensitivity = as.numeric(roc_obj$sensitivities)
  ) %>%
    group_by(fpr) %>% summarise(sensitivity = max(sensitivity), .groups = "drop") %>%
    arrange(fpr)
  tibble(
    fpr = grid,
    sensitivity = approx(
      raw$fpr, raw$sensitivity, xout = grid,
      method = "linear", ties = max, rule = 2
    )$y
  )
}

roc_grid_from_predictions <- function(predictions) {
  predictions %>%
    group_split(task) %>%
    map_dfr(function(dat) {
      map_dfr(MODEL_NAMES, function(model_name) {
        roc_grid_one(dat$outcome, dat[[model_name]]) %>%
          mutate(task = unique(dat$task), model = model_name, .before = 1)
      })
    })
}

# ------------------------------- Read and audit -------------------------------

for (path in c(CONFIG$nfyy_file, CONFIG$mgs_meta_file,
               CONFIG$abundance_file, CONFIG$feature_file)) {
  assert_true(file.exists(path), "找不到输入文件: %s", path)
}

nfyy_all <- fread(CONFIG$nfyy_file, sep = "\t", data.table = FALSE, check.names = FALSE)
mgs_meta <- fread(CONFIG$mgs_meta_file, sep = "\t", data.table = FALSE, check.names = FALSE)
abundance_raw <- fread(CONFIG$abundance_file, sep = "\t", data.table = FALSE, check.names = FALSE)
feature_table <- fread(CONFIG$feature_file, sep = "\t", data.table = FALSE, check.names = FALSE)

assert_columns(
  nfyy_all,
  c("ID", "Cohort", "Group_All", "SDC2_Category"),
  "NF_Cohort_1元数据"
)
assert_columns(mgs_meta, c("Sequence_ID", "ID", "Sub_Group", "SDC2_Category"), "MGS元数据")
mgs_meta <- mgs_meta %>% mutate(ID = as.character(ID), Sequence_ID = trimws(as.character(Sequence_ID)))
assert_columns(abundance_raw, "ID", "物种丰度表")
assert_columns(feature_table, c("Species", "Model"), "固定物种表")
assert_true(all(feature_table$Model %in% c("AP", "CRC")),
            "固定物种表Model字段只能包含AP或CRC。")
assert_true(!anyDuplicated(mgs_meta$ID), "NF_Cohort2元数据患者ID存在重复。")
assert_true(!anyDuplicated(mgs_meta$Sequence_ID), "NF_Cohort2元数据Sequence_ID存在重复。")
assert_true(!anyNA(mgs_meta$ID) && all(nzchar(trimws(as.character(mgs_meta$ID)))),
            "NF_Cohort2元数据ID存在缺失或空值。")
assert_true(!anyNA(mgs_meta$Sequence_ID) &&
              all(nzchar(trimws(as.character(mgs_meta$Sequence_ID)))),
            "NF_Cohort2元数据Sequence_ID存在缺失或空值。")
assert_true(!anyDuplicated(abundance_raw$ID), "物种丰度表物种ID存在重复。")
assert_true(all(mgs_meta$SDC2_Category %in% c("mSDC2(-)", "mSDC2(+)")),
            "MGS存在非预期mSDC2编码。")

nfyy_all <- nfyy_all %>%
  mutate(
    Sub_Group = recode(
      Group_All,
      "Normal Control" = "NC",
      "Non-Advanced Colorectal Lsions" = "NACL",
      "Advanced Precancerous Lesions" = "APL",
      "Colorectal Cancer" = "CRC",
      "Non-Colorectal Malignancies" = "NCRM",
      "Asymptomatic Screening Population" = "ASP",
      "Colorectal Inflammatory Diseases" = "CRID",
      "Pathology-unconfirmed Colorectal Polyps" = "PUCP",
      "Upper Gastrointestinal Diseases" = "UGID",
      "Comorbid Screening Population" = "CSP",
      .default = NA_character_
    ),
    msdc2_bin = as.integer(SDC2_Category == "mSDC2(+)")
  )

nfyy <- nfyy_all %>%
  filter(Cohort == CONFIG$nfyy_source_cohort)

assert_true(nrow(nfyy) == CONFIG$expected_nfyy_source_n,
            "%s样本数应为%d，实际为%d。",
            CONFIG$nfyy_source_cohort, CONFIG$expected_nfyy_source_n, nrow(nfyy))
assert_true(!anyDuplicated(nfyy$ID), "%s中NFYY ID存在重复。",
            CONFIG$nfyy_source_cohort)
assert_true(all(nfyy$SDC2_Category %in% c("mSDC2(-)", "mSDC2(+)")),
            "%s存在非预期mSDC2编码。", CONFIG$nfyy_source_cohort)
assert_true(all(nfyy$Sub_Group %in% c("NC", "NACL", "APL", "CRC")),
            "%s存在无法映射到NC/NACL/APL/CRC的样本。",
            CONFIG$nfyy_source_cohort)
mgs_meta <- mgs_meta %>% mutate(msdc2_bin = as.integer(SDC2_Category == "mSDC2(+)"))

## 丰度表：行是物种，列是样本
abundance_sample_ids <- setdiff(colnames(abundance_raw), "ID")

## 提取MGS元数据与丰度表共有的样本，顺序以mgs_meta为准
common_sample_ids <- intersect(as.character(mgs_meta$Sequence_ID), abundance_sample_ids)
assert_true(length(common_sample_ids) > 0L,
            "NF_Cohort2元数据Sequence_ID与物种丰度表样本列之间没有共有样本。")

message(sprintf(
  "MGS元数据样本数：%d；丰度表样本数：%d；共有样本数：%d。",
  nrow(mgs_meta), length(abundance_sample_ids), length(common_sample_ids)
))

## 同步筛选元数据，并保持原元数据中的样本顺序
mgs_meta <- mgs_meta %>%
  filter(as.character(Sequence_ID) %in% common_sample_ids)

## 按筛选后的mgs_meta顺序提取丰度表样本
common_sample_ids <- as.character(mgs_meta$Sequence_ID)
abundance_matrix <- abundance_raw %>%
  select(ID, all_of(common_sample_ids)) %>%
  tibble::column_to_rownames("ID") %>%
  as.matrix() %>%
  t()

storage.mode(abundance_matrix) <- "double"

## 交集筛选后的完整性和顺序检查
assert_true(identical(rownames(abundance_matrix), as.character(mgs_meta$Sequence_ID)),
            "共有样本筛选后，丰度矩阵样本顺序与NF_Cohort2元数据Sequence_ID不一致。")
assert_true(!anyNA(abundance_matrix) &&
              all(is.finite(abundance_matrix)) &&
              all(abundance_matrix >= 0),
            "物种丰度矩阵包含NA、Inf或负值。")
assert_true(all(abs(rowSums(abundance_matrix) - CONFIG$abundance_total) < 0.05),
            "丰度总和不接近100，请确认输入单位。")
assert_true(length(intersect(as.character(nfyy$ID), as.character(mgs_meta$ID))) == 0L,
            "NFYY与筛选后的MGS元数据存在患者ID重叠。")

for (task_name in names(TASKS)) {
  invisible(features_for_task(TASKS[[task_name]], feature_table))
}

config_table <- tibble(
  parameter = c("input_dir", "output_dir", "nfyy_source_cohort",
                "nfyy_source_n", "seed", "bootstrap_replicates",
                "outer_folds", "inner_folds", "lambda_rule", "tasks"),
  value = c(INPUT_DIR, CONFIG$output_dir, CONFIG$nfyy_source_cohort,
            nrow(nfyy), CONFIG$seed, CONFIG$b_boot,
            CONFIG$outer_folds, CONFIG$inner_folds, CONFIG$lambda_rule,
            paste(names(TASKS), collapse = ","))
)
write_csv(config_table, "00_run_configuration.csv")

task_definitions <- imap_dfr(TASKS, function(task_def, task_name) {
  source_task <- task_subset(nfyy, task_def, group_col = "Sub_Group")
  tibble(
    task = task_name,
    source_cohort = CONFIG$nfyy_source_cohort,
    source_n = nrow(source_task),
    source_negative_n = sum(source_task$outcome == 0L),
    source_positive_n = sum(source_task$outcome == 1L),
    negative_groups = paste(task_def$negative, collapse = " + "),
    positive_groups = paste(task_def$positive, collapse = " + "),
    feature_panel = task_def$feature_panel,
    feature_count = length(features_for_task(task_def, feature_table))
  )
})
write_csv(task_definitions, "00b_task_definitions.csv")

group_audit <- bind_rows(
  nfyy %>% count(dataset = "NF_Cohort_1", Group = Sub_Group,
                 msdc2_bin, name = "n"),
  mgs_meta %>% count(dataset = "NF_Cohort2", Group = Sub_Group, msdc2_bin, name = "n")
)
write_csv(group_audit, "01_group_audit.csv")

feature_audit <- feature_table %>%
  distinct(Model, Species) %>%
  rowwise() %>%
  mutate(
    prevalence_all = mean(abundance_matrix[, Species] > 0),
    median_abundance = median(abundance_matrix[, Species]),
    max_abundance = max(abundance_matrix[, Species])
  ) %>% ungroup()
write_csv(feature_audit, "02_feature_detection_audit.csv")

# -------------------------- Original-data nested OOF --------------------------

message("开始生成原始数据的外层OOF预测……")
message(
  "注意：MGS阳性亚组仅15例APL和14例CRC；",
  "APL/CRC亚组敏感度及其Bootstrap区间可能较宽。"
)
central_crossfit <- imap(TASKS, function(task_def, task_name) {
  crossfit_task(
    task_name, nfyy, mgs_meta, abundance_matrix, feature_table,
    make_seed(CONFIG$seed, "central", task_name)
  )
})

oof_predictions <- map_dfr(central_crossfit, "predictions")
outer_fold_audit <- map_dfr(central_crossfit, "fold_audit")
oof_metrics <- metrics_from_predictions(oof_predictions, "outer_oof_internal_validation")
oof_roc_grid <- roc_grid_from_predictions(oof_predictions)
oof_subgroup_sensitivity <- subgroup_sensitivity_at_specificity(
  oof_predictions, "outer_oof_internal_validation"
)

write_csv(oof_predictions, "03_outer_oof_predictions.csv")
write_csv(outer_fold_audit, "04_outer_fold_audit.csv")
write_csv(oof_metrics, "05_internal_validation_metrics.csv")
write_csv(oof_roc_grid, "06_internal_validation_roc_grid.csv")
write_csv(
  oof_subgroup_sensitivity,
  "06a_positive_subgroup_sensitivity_at_spec95.csv"
)

# ------------------------------- Locked models -------------------------------

message("拟合五个最终锁定模型（桥接系数使用全MGS的OOF菌群评分）……")
final_models <- imap(TASKS, function(task_def, task_name) {
  fit_locked_task(
    task_name, nfyy, mgs_meta, abundance_matrix, feature_table,
    make_seed(CONFIG$seed, "final_locked", task_name)
  )
})

locked_apparent_predictions <- imap_dfr(final_models, function(model, task_name) {
  pred <- predict_locked_task(model, model$bridge_task, abundance_matrix)
  tibble(
    task = task_name,
    ID = model$bridge_task$ID,
    Sequence_ID = model$bridge_task$Sequence_ID,
    Group = model$bridge_task$Sub_Group,
    outcome = model$bridge_task$outcome,
    msdc2_lp = pred$msdc2_lp,
    micro_lp = pred$micro_lp,
    mSDC2 = pred$probabilities$mSDC2,
    Microbiome = pred$probabilities$Microbiome,
    Combined_offset = pred$probabilities$Combined_offset,
    Combined_free_sensitivity = pred$probabilities$Combined_free_sensitivity
  )
})

locked_micro_coef <- imap_dfr(final_models, function(model, task_name) {
  extract_microbiome_coefficients(model$microbiome) %>%
    mutate(task = task_name, .before = 1)
})
locked_bridge_coef <- imap_dfr(final_models, function(model, task_name) {
  extract_bridge_coefficients(model$bridge) %>%
    mutate(task = task_name, .before = 1)
})

locked_msdc2_coef <- imap_dfr(final_models, function(model, task_name) {
  task_def <- TASKS[[task_name]]
  coefficients <- coef(model$msdc2$fit)
  tibble(
    task = task_name,
    source_cohort = CONFIG$nfyy_source_cohort,
    source_n = nrow(model$source_task),
    source_negative_n = sum(model$source_task$outcome == 0L),
    source_positive_n = sum(model$source_task$outcome == 1L),
    negative_groups = paste(task_def$negative, collapse = " + "),
    positive_groups = paste(task_def$positive, collapse = " + "),
    intercept = unname(coefficients[["(Intercept)"]]),
    mSDC2_source_coefficient = unname(coefficients[["msdc2_bin"]]),
    logit_expression = sprintf(
      "logit(mSDC2) = %.10f + %.10f * I(mSDC2(+))",
      intercept, mSDC2_source_coefficient
    )
  )
})

write_csv(locked_apparent_predictions, "07_locked_model_apparent_predictions.csv")
write_csv(locked_micro_coef, "08_locked_microbiome_coefficients.csv")
write_csv(locked_bridge_coef, "09_locked_bridge_coefficients.csv")
write_csv(locked_msdc2_coef, "09a_locked_mSDC2_source_coefficients.csv")
saveRDS(final_models, file.path(CONFIG$output_dir, "rds", "final_locked_models_nested_oof.rds"))

# --------------------------- Full-workflow bootstrap --------------------------

bootstrap_one_task <- function(task_name, replicate) {
  task_def <- TASKS[[task_name]]
  source_task <- task_subset(nfyy, task_def, group_col = "Sub_Group")
  bridge_task <- task_subset(mgs_meta, task_def, group_col = "Sub_Group")
  set.seed(make_seed(
    CONFIG$seed, "bootstrap_resample", task_name, replicate
  ))
  source_boot <- source_task[stratified_bootstrap_indices(source_task$outcome), , drop = FALSE]
  bridge_boot <- bridge_task[stratified_bootstrap_indices(bridge_task$outcome), , drop = FALSE]
  seed_b <- make_seed(
    CONFIG$seed, "bootstrap_workflow", task_name, replicate
  )

  cv <- crossfit_task(
    task_name, source_boot, bridge_boot, abundance_matrix, feature_table, seed_b
  )
  metrics <- metrics_from_predictions(cv$predictions, "bootstrap_full_workflow_oof") %>%
    mutate(replicate = replicate, .before = 1)
  subgroup_sensitivity <- subgroup_sensitivity_at_specificity(
    cv$predictions, "bootstrap_full_workflow_oof"
  ) %>% mutate(replicate = replicate, .before = 1)
  curves <- roc_grid_from_predictions(cv$predictions) %>%
    mutate(replicate = replicate, .before = 1)
  locked <- fit_locked_task(
    task_name, source_boot, bridge_boot, abundance_matrix, feature_table,
      make_seed(seed_b, "bootstrap_locked")
  )
  micro_coef <- extract_microbiome_coefficients(locked$microbiome) %>%
    mutate(replicate = replicate, task = task_name, .before = 1)
  bridge_coef <- extract_bridge_coefficients(locked$bridge) %>%
    mutate(replicate = replicate, task = task_name, .before = 1)
  list(
    metrics = metrics,
    subgroup_sensitivity = subgroup_sensitivity,
    curves = curves,
    micro_coef = micro_coef,
    bridge_coef = bridge_coef
  )
}

bootstrap_results <- list()
failure_schema <- tibble(task = character(), replicate = integer(), error = character())
bootstrap_failures <- list()

for (task_name in names(TASKS)) {
  message("完整流程Bootstrap任务 ", task_name, "：", CONFIG$b_boot, " 次")
  task_results <- vector("list", CONFIG$b_boot)
  task_failures <- vector("list", CONFIG$b_boot)
  for (b in seq_len(CONFIG$b_boot)) {
    if (b == 1L || b %% 10L == 0L || b == CONFIG$b_boot) {
      message("  ", task_name, " ", b, "/", CONFIG$b_boot)
    }
    result <- tryCatch(
      bootstrap_one_task(task_name, b),
      error = function(e) e
    )
    if (inherits(result, "error")) {
      task_failures[[b]] <- tibble(
        task = task_name, replicate = b, error = conditionMessage(result)
      )
    } else {
      task_results[[b]] <- result
    }
  }
  bootstrap_results[[task_name]] <- task_results
  bootstrap_failures[[task_name]] <- bind_rows(task_failures)
}

successful <- unlist(bootstrap_results, recursive = FALSE)
bootstrap_metrics <- map_dfr(successful, "metrics")
bootstrap_subgroup_sensitivity <- map_dfr(successful, "subgroup_sensitivity")
bootstrap_roc_grid <- map_dfr(successful, "curves")
bootstrap_micro_coef <- map_dfr(successful, "micro_coef")
bootstrap_bridge_coef <- map_dfr(successful, "bridge_coef")
bootstrap_failure_table <- bind_rows(failure_schema, bind_rows(bootstrap_failures))

write_csv(bootstrap_metrics, "10_bootstrap_full_workflow_metrics.csv")
write_csv(
  bootstrap_subgroup_sensitivity,
  "10a_bootstrap_positive_subgroup_sensitivity_at_spec95.csv"
)
write_csv(bootstrap_roc_grid, "11_bootstrap_full_workflow_roc_grid.csv")
write_csv(bootstrap_micro_coef, "12_bootstrap_microbiome_coefficients.csv")
write_csv(bootstrap_bridge_coef, "13_bootstrap_bridge_coefficients.csv")
write_csv(bootstrap_failure_table, "14_bootstrap_failures.csv")

success_rate <- tibble(task = names(TASKS)) %>%
  left_join(
    bootstrap_metrics %>% distinct(task, replicate) %>%
      count(task, name = "successful_replicates"),
    by = "task"
  ) %>%
  mutate(
    successful_replicates = coalesce(successful_replicates, 0L),
    requested_replicates = CONFIG$b_boot,
    success_rate = successful_replicates / requested_replicates
  )
write_csv(success_rate, "15_bootstrap_success_rate.csv")
assert_true(
  all(success_rate$success_rate >= CONFIG$min_boot_success_rate),
  "至少一个任务的Bootstrap成功率低于%.1f%%，请检查14_bootstrap_failures.csv。",
  100 * CONFIG$min_boot_success_rate
)

metric_names <- c("AUROC", "AUPRC_AP", "Sens_at_Spec95", "Brier",
                  "cal_intercept", "cal_slope")
central_long <- oof_metrics %>%
  pivot_longer(all_of(metric_names), names_to = "metric", values_to = "estimate") %>%
  select(task, model, metric, estimate)
bootstrap_long <- bootstrap_metrics %>%
  pivot_longer(all_of(metric_names), names_to = "metric", values_to = "value")

performance_summary <- bootstrap_long %>%
  group_by(task, model, metric) %>%
  summarise(
    bootstrap_mean = mean(value, na.rm = TRUE),
    ci_low = quantile(value, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(value, 0.975, na.rm = TRUE, names = FALSE),
    successful_replicates = sum(is.finite(value)),
    .groups = "drop"
  ) %>%
  left_join(central_long, by = c("task", "model", "metric")) %>%
  select(task, model, metric, estimate, bootstrap_mean, ci_low, ci_high,
         successful_replicates)
write_csv(performance_summary, "16_internal_validation_performance_summary.csv")

paired_delta <- bootstrap_long %>%
  filter(model %in% c("mSDC2", "Microbiome", "Combined_offset")) %>%
  select(replicate, task, metric, model, value) %>%
  pivot_wider(names_from = model, values_from = value) %>%
  pivot_longer(c(mSDC2, Microbiome), names_to = "reference_model",
               values_to = "reference_value") %>%
  mutate(delta = Combined_offset - reference_value) %>%
  group_by(task, metric, reference_model) %>%
  summarise(
    delta_mean = mean(delta, na.rm = TRUE),
    ci_low = quantile(delta, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(delta, 0.975, na.rm = TRUE, names = FALSE),
    successful_replicates = sum(is.finite(delta)),
    .groups = "drop"
  )
write_csv(paired_delta, "17_paired_delta_combined_vs_single_models.csv")

roc_band_summary <- bootstrap_roc_grid %>%
  group_by(task, model, fpr) %>%
  summarise(
    sensitivity_median = median(sensitivity, na.rm = TRUE),
    ci_low = quantile(sensitivity, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(sensitivity, 0.975, na.rm = TRUE, names = FALSE),
    successful_replicates = sum(is.finite(sensitivity)),
    .groups = "drop"
  )
write_csv(roc_band_summary, "18_bootstrap_roc_pointwise_bands.csv")

subgroup_sensitivity_summary <- bootstrap_subgroup_sensitivity %>%
  group_by(task, model, subgroup, target_specificity) %>%
  summarise(
    bootstrap_mean = mean(sensitivity, na.rm = TRUE),
    ci_low = quantile(sensitivity, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(sensitivity, 0.975, na.rm = TRUE, names = FALSE),
    successful_replicates = sum(is.finite(sensitivity)),
    .groups = "drop"
  ) %>%
  left_join(
    oof_subgroup_sensitivity %>%
      select(
        task, model, subgroup, target_specificity,
        subgroup_n, threshold, achieved_specificity,
        estimate = sensitivity
      ),
    by = c("task", "model", "subgroup", "target_specificity")
  ) %>%
  select(
    task, model, subgroup, subgroup_n, target_specificity,
    threshold, achieved_specificity, estimate,
    bootstrap_mean, ci_low, ci_high, successful_replicates
  )
write_csv(
  subgroup_sensitivity_summary,
  "18a_positive_subgroup_sensitivity_summary.csv"
)

micro_coef_summary <- bootstrap_micro_coef %>%
  filter(term != "(Intercept)") %>%
  group_by(task, term) %>%
  summarise(
    coefficient_median = median(coefficient, na.rm = TRUE),
    coefficient_ci_low = quantile(coefficient, 0.025, na.rm = TRUE, names = FALSE),
    coefficient_ci_high = quantile(coefficient, 0.975, na.rm = TRUE, names = FALSE),
    standardized_median = median(standardized_coefficient, na.rm = TRUE),
    standardized_ci_low = quantile(standardized_coefficient, 0.025, na.rm = TRUE, names = FALSE),
    standardized_ci_high = quantile(standardized_coefficient, 0.975, na.rm = TRUE, names = FALSE),
    positive_fraction = mean(coefficient > 0, na.rm = TRUE),
    successful_replicates = n_distinct(replicate),
    .groups = "drop"
  ) %>%
  left_join(
    locked_micro_coef %>%
      filter(term != "(Intercept)") %>%
      select(task, term, locked_coefficient = coefficient,
             locked_standardized_coefficient = standardized_coefficient),
    by = c("task", "term")
  )
write_csv(micro_coef_summary, "19_microbiome_coefficient_summary.csv")

bridge_coef_summary <- bootstrap_bridge_coef %>%
  group_by(task, bridge_model, term) %>%
  summarise(
    coefficient_median = median(coefficient, na.rm = TRUE),
    ci_low = quantile(coefficient, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(coefficient, 0.975, na.rm = TRUE, names = FALSE),
    successful_replicates = n_distinct(replicate),
    .groups = "drop"
  ) %>%
  left_join(
    locked_bridge_coef %>%
      select(task, bridge_model, term, locked_coefficient = coefficient),
    by = c("task", "bridge_model", "term")
  )
write_csv(bridge_coef_summary, "20_bridge_coefficient_summary.csv")

# ---------------------- Downstream performance-evaluation RDS ----------------

performance_evaluation_bundle <- list(
  schema_version = "1.0",
  primary_validation = "pooled_outer_fold_oof",
  primary_combined_model = "Combined_offset",
  sensitivity_combined_model = "Combined_free_sensitivity",
  task_definitions = TASKS,
  model_names = MODEL_NAMES,
  outer_oof_predictions = oof_predictions,
  outer_fold_audit = outer_fold_audit,
  locked_model_apparent_predictions = locked_apparent_predictions,
  bootstrap_metrics = bootstrap_metrics,
  performance_summary = performance_summary,
  paired_model_differences = paired_delta,
  bootstrap_roc_bands = roc_band_summary,
  subgroup_sensitivity_summary = subgroup_sensitivity_summary,
  locked_models_rds = file.path(CONFIG$output_dir, "rds", "final_locked_models_nested_oof.rds"),
  configuration = CONFIG
)
saveRDS(
  performance_evaluation_bundle,
  file.path(CONFIG$output_dir, "rds", "performance_evaluation_nested_oof.rds"),
  compress = "xz"
)

# -------------------------- Challenge-set predictions -------------------------

nfyy_challenge <- nfyy_all %>% filter(Sub_Group %in% CHALLENGE_GROUPS)
nfyy_challenge_results <- imap_dfr(final_models, function(model, task_name) {
  if (nrow(nfyy_challenge) == 0L) return(tibble())
  tibble(
    task = task_name, ID = nfyy_challenge$ID,
    Group = nfyy_challenge$Sub_Group,
    msdc2_bin = nfyy_challenge$msdc2_bin,
    source_msdc2_probability = plogis(predict_msdc2_lp(model$msdc2, nfyy_challenge))
  )
})
write_csv(nfyy_challenge_results, "21_nfyy_msdc2_challenge.csv")

mgs_challenge <- mgs_meta %>% filter(Sub_Group %in% CHALLENGE_GROUPS)
mgs_challenge_results <- imap_dfr(final_models, function(model, task_name) {
  if (nrow(mgs_challenge) == 0L) return(tibble())
  pred <- predict_locked_task(model, mgs_challenge, abundance_matrix)
  tibble(
    task = task_name, ID = mgs_challenge$ID,
    Sequence_ID = mgs_challenge$Sequence_ID,
    Group = mgs_challenge$Sub_Group,
    mSDC2 = pred$probabilities$mSDC2,
    Microbiome = pred$probabilities$Microbiome,
    Combined_offset = pred$probabilities$Combined_offset,
    Combined_free_sensitivity = pred$probabilities$Combined_free_sensitivity
  )
})
write_csv(mgs_challenge_results, "22_mgs_locked_model_challenge.csv")

writeLines(
  capture.output(sessionInfo()),
  file.path(CONFIG$output_dir, "sessionInfo.txt"), useBytes = TRUE
)
message("分析完成。结果目录: ", normalizePath(CONFIG$output_dir, winslash = "/"))
