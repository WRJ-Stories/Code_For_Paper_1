#!/usr/bin/env Rscript

# Incremental performance evaluation for the nested OOF mSDC2-microbiome models.
# Primary analyses compare Combined_offset with mSDC2 and Microbiome.
# Combined_free_sensitivity is reported as a supplementary sensitivity analysis.

source(file.path("config", "project_paths.R"))

env_or <- function(name, default) {
  value <- Sys.getenv(name, unset = "")
  if (nzchar(value)) value else default
}

env_int <- function(name, default) {
  value <- suppressWarnings(as.integer(Sys.getenv(name, unset = "")))
  if (length(value) == 1L && is.finite(value) && value >= 1L) value else as.integer(default)
}

env_num <- function(name, default) {
  value <- suppressWarnings(as.numeric(Sys.getenv(name, unset = "")))
  if (length(value) == 1L && is.finite(value)) value else as.numeric(default)
}

required_packages <- c("dplyr", "tidyr", "purrr", "tibble", "brglm2")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Missing R packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(tibble)
})

clip_prob <- function(p, eps = 1e-6) pmin(pmax(as.numeric(p), eps), 1 - eps)

make_seed <- function(...) {
  key <- paste(vapply(list(...), function(x) paste(as.character(x), collapse = ","), character(1)), collapse = "|")
  hash <- 0
  for (byte in utf8ToInt(enc2utf8(key))) hash <- (hash * 131 + as.double(byte)) %% (.Machine$integer.max - 1)
  as.integer(hash + 1)
}

assert_columns <- function(x, columns, object_name) {
  missing <- setdiff(columns, names(x))
  if (length(missing) > 0L) stop(object_name, " is missing columns: ", paste(missing, collapse = ", "), call. = FALSE)
}

existing_directory <- function(path) {
  path <- gsub("\\\\", "/", path)
  if (!dir.exists(path)) stop("Directory does not exist: ", path, call. = FALSE)
  path
}

stratified_patient_indices <- function(y) {
  unlist(lapply(split(seq_along(y), as.integer(y)), function(index) sample(index, length(index), replace = TRUE)), use.names = FALSE)
}

continuous_nri <- function(y, new_risk, old_risk) {
  y <- as.integer(y)
  change <- sign(as.numeric(new_risk) - as.numeric(old_risk))
  if (!all(y %in% c(0L, 1L)) || length(unique(y)) != 2L) stop("NRI requires binary outcomes containing both classes.", call. = FALSE)
  event_component <- mean(change[y == 1L] > 0) - mean(change[y == 1L] < 0)
  nonevent_component <- mean(change[y == 0L] < 0) - mean(change[y == 0L] > 0)
  c(nri_events = event_component, nri_nonevents = nonevent_component,
    nri_total = event_component + nonevent_component)
}

bootstrap_continuous_nri <- function(y, new_risk, old_risk, b = 1000L, seed = 20260819L) {
  y <- as.integer(y)
  estimate <- continuous_nri(y, new_risk, old_risk)
  set.seed(seed)
  boot <- t(replicate(b, {
    index <- stratified_patient_indices(y)
    continuous_nri(y[index], new_risk[index], old_risk[index])
  }))
  boot <- as.data.frame(boot, check.names = FALSE)
  summary <- tibble(
    component = names(estimate), estimate = as.numeric(estimate),
    ci_low = vapply(boot, quantile, numeric(1), probs = 0.025, na.rm = TRUE, names = FALSE),
    ci_high = vapply(boot, quantile, numeric(1), probs = 0.975, na.rm = TRUE, names = FALSE),
    bootstrap_se = vapply(boot, sd, numeric(1), na.rm = TRUE)
  ) %>% mutate(p_value = ifelse(bootstrap_se > 0, 2 * pnorm(-abs(estimate / bootstrap_se)),
                                ifelse(estimate == 0, 1, 0)))
  list(summary = summary, replicates = as_tibble(boot))
}

safe_brglm <- function(formula, data) {
  fit <- suppressWarnings(try(glm(
    formula, data = data, family = binomial(), method = brglm2::brglmFit,
    type = "AS_mean", control = brglm2::brglm_control(maxit = 1000, epsilon = 1e-8)
  ), silent = TRUE))
  if (inherits(fit, "try-error") || !isTRUE(fit$converged)) NULL else fit
}

fit_bias_reduced_calibration <- function(y, p, flexible = TRUE) {
  dat <- data.frame(y = as.integer(y), lp = qlogis(clip_prob(p)))
  unique_p <- length(unique(round(p, 12)))
  if (flexible && unique_p >= 4L) {
    degrees <- min(3L, unique_p - 1L)
    fit <- safe_brglm(y ~ splines::ns(lp, df = degrees), dat)
    if (!is.null(fit)) return(fit)
  }
  safe_brglm(y ~ lp, dat)
}

calibration_curve <- function(y, p, grid = seq(min(p), max(p), length.out = 101L)) {
  fit <- fit_bias_reduced_calibration(y, p, flexible = TRUE)
  if (is.null(fit)) return(tibble(predicted = as.numeric(grid), observed = rep(mean(y), length(grid))))
  tibble(predicted = as.numeric(grid), observed = as.numeric(predict(
    fit, newdata = data.frame(lp = qlogis(clip_prob(grid))), type = "response"
  )))
}

calibration_groups <- function(y, p, groups = 5L) {
  y <- as.integer(y)
  p <- as.numeric(p)
  unique_p <- length(unique(round(p, 12)))
  group_id <- if (unique_p <= groups) match(round(p, 12), sort(unique(round(p, 12)))) else
    dplyr::ntile(rank(p, ties.method = "average"), groups)
  split(seq_along(y), group_id) %>% map_dfr(function(index) {
    interval <- binom.test(sum(y[index]), length(index))$conf.int
    tibble(n = length(index), predicted = mean(p[index]), observed = mean(y[index]),
           ci_low = interval[[1]], ci_high = interval[[2]])
  })
}

calibration_statistics <- function(y, p) {
  dat <- data.frame(y = as.integer(y), lp = qlogis(clip_prob(p)))
  intercept_fit <- safe_brglm(y ~ 1 + offset(lp), dat)
  slope_fit <- safe_brglm(y ~ lp, dat)
  c(
    intercept = if (is.null(intercept_fit)) NA_real_ else unname(coef(intercept_fit)[[1]]),
    slope = if (is.null(slope_fit)) NA_real_ else unname(coef(slope_fit)[["lp"]])
  )
}

bootstrap_calibration <- function(y, p, b = 1000L, seed = 20260819L, groups = 5L) {
  y <- as.integer(y)
  p <- clip_prob(p)
  grid_limits <- quantile(p, c(0.025, 0.975), names = FALSE)
  grid <- seq(grid_limits[[1]], grid_limits[[2]], length.out = 101L)
  central_curve <- calibration_curve(y, p, grid)
  central_groups <- calibration_groups(y, p, groups)
  central_stats <- calibration_statistics(y, p)
  set.seed(seed)
  curve_boot <- matrix(NA_real_, nrow = b, ncol = length(grid))
  stats_boot <- matrix(NA_real_, nrow = b, ncol = 2L, dimnames = list(NULL, c("intercept", "slope")))
  for (i in seq_len(b)) {
    index <- stratified_patient_indices(y)
    curve_boot[i, ] <- calibration_curve(y[index], p[index], grid)$observed
    stats_boot[i, ] <- calibration_statistics(y[index], p[index])
  }
  curve <- central_curve %>% mutate(
    ci_low = apply(curve_boot, 2L, quantile, probs = 0.025, na.rm = TRUE, names = FALSE),
    ci_high = apply(curve_boot, 2L, quantile, probs = 0.975, na.rm = TRUE, names = FALSE)
  )
  statistics <- tibble(
    metric = names(central_stats), estimate = as.numeric(central_stats),
    ci_low = apply(stats_boot, 2L, quantile, probs = 0.025, na.rm = TRUE, names = FALSE),
    ci_high = apply(stats_boot, 2L, quantile, probs = 0.975, na.rm = TRUE, names = FALSE)
  )
  list(curve = curve, groups = central_groups, statistics = statistics)
}

decision_curve_one <- function(y, p, thresholds, model) {
  y <- as.integer(y)
  p <- as.numeric(p)
  n <- length(y)
  prevalence <- mean(y)
  model_nb <- vapply(thresholds, function(pt) {
    predicted_positive <- p >= pt
    sum(predicted_positive & y == 1L) / n - sum(predicted_positive & y == 0L) / n * pt / (1 - pt)
  }, numeric(1))
  bind_rows(
    tibble(threshold = thresholds, strategy = model, net_benefit = model_nb),
    tibble(threshold = thresholds, strategy = "Treat all",
           net_benefit = prevalence - (1 - prevalence) * thresholds / (1 - thresholds)),
    tibble(threshold = thresholds, strategy = "Treat none", net_benefit = 0)
  )
}

decision_curves <- function(y, probabilities, thresholds) {
  model_rows <- imap_dfr(probabilities, function(p, model) {
    decision_curve_one(y, p, thresholds, model) %>% filter(strategy == model)
  })
  references <- decision_curve_one(y, probabilities[[1]], thresholds, names(probabilities)[[1]]) %>%
    filter(strategy %in% c("Treat all", "Treat none"))
  bind_rows(model_rows, references)
}

bootstrap_decision_curves <- function(y, probabilities, thresholds, b = 1000L, seed = 20260819L) {
  central <- decision_curves(y, probabilities, thresholds)
  model_names <- names(probabilities)
  set.seed(seed)
  replicate_rows <- vector("list", b)
  for (i in seq_len(b)) {
    index <- stratified_patient_indices(y)
    replicate_rows[[i]] <- decision_curves(y[index], lapply(probabilities, `[`, index), thresholds) %>%
      filter(strategy %in% model_names) %>% mutate(replicate = i)
  }
  bands <- bind_rows(replicate_rows) %>% group_by(strategy, threshold) %>% summarise(
    ci_low = quantile(net_benefit, 0.025, na.rm = TRUE, names = FALSE),
    ci_high = quantile(net_benefit, 0.975, na.rm = TRUE, names = FALSE), .groups = "drop"
  )
  central %>% left_join(bands, by = c("strategy", "threshold")) %>%
    mutate(ci_low = ifelse(strategy == "Treat none", 0, ci_low),
           ci_high = ifelse(strategy == "Treat none", 0, ci_high))
}

dominant_threshold_intervals <- function(dca_data, combined_model = "Combined_offset", min_consecutive = 3L) {
  if ("task" %in% names(dca_data) && length(unique(dca_data$task)) > 1L) {
    return(dca_data %>% group_split(task) %>%
             map_dfr(~ dominant_threshold_intervals(.x, combined_model, min_consecutive)))
  }
  task_name <- if ("task" %in% names(dca_data)) unique(dca_data$task)[[1]] else NA_character_
  wide <- dca_data %>% select(threshold, strategy, net_benefit) %>% distinct() %>%
    pivot_wider(names_from = strategy, values_from = net_benefit)
  if (!combined_model %in% names(wide)) return(tibble())
  comparators <- setdiff(names(wide), c("threshold", combined_model))
  comparator_max <- apply(wide[, comparators, drop = FALSE], 1L, max, na.rm = TRUE)
  advantage <- wide[[combined_model]] - comparator_max
  keep <- which(is.finite(advantage) & advantage > 0)
  if (length(keep) == 0L) return(tibble())
  step <- median(diff(sort(unique(wide$threshold))))
  run_id <- cumsum(c(TRUE, diff(wide$threshold[keep]) > step * 1.5))
  tibble(index = keep, run_id = run_id) %>% group_by(run_id) %>% summarise(
    task = task_name, combined_model = combined_model,
    threshold_low = min(wide$threshold[index]), threshold_high = max(wide$threshold[index]),
    min_net_benefit_advantage = min(advantage[index]),
    max_net_benefit_advantage = max(advantage[index]),
    thresholds_in_interval = n(), .groups = "drop"
  ) %>% filter(thresholds_in_interval >= min_consecutive) %>% mutate(
    fp_to_fn_harm_weight_low = threshold_low / (1 - threshold_low),
    fp_to_fn_harm_weight_high = threshold_high / (1 - threshold_high),
    false_positives_per_missed_case_low = (1 - threshold_low) / threshold_low,
    false_positives_per_missed_case_high = (1 - threshold_high) / threshold_high,
    interpretation = "Exploratory interval where Combined_offset has higher OOF net benefit than both single models and treat-all/treat-none; external validation is required before deployment."
  )
}

load_evaluation_bundle <- function(results_dir) {
  bundle_path <- file.path(results_dir, "rds", "performance_evaluation_nested_oof.rds")
  locked_path <- file.path(results_dir, "rds", "final_locked_models_nested_oof.rds")
  prediction_path <- file.path(results_dir, "tables", "03_outer_oof_predictions.csv")
  if (!file.exists(locked_path)) stop("Missing locked-model RDS: ", locked_path, call. = FALSE)
  locked_models <- readRDS(locked_path)
  if (file.exists(bundle_path)) {
    bundle <- readRDS(bundle_path)
    source <- "performance_evaluation_nested_oof.rds"
  } else {
    if (!file.exists(prediction_path)) stop("Missing OOF predictions: ", prediction_path, call. = FALSE)
    bundle <- list(
      schema_version = "1.0", primary_validation = "pooled_outer_fold_oof",
      primary_combined_model = "Combined_offset",
      sensitivity_combined_model = "Combined_free_sensitivity",
      task_definitions = lapply(locked_models, `[[`, "task_def"),
      outer_oof_predictions = read.csv(prediction_path, check.names = FALSE, stringsAsFactors = FALSE,
                                       fileEncoding = "UTF-8")
    )
    source <- "03_outer_oof_predictions.csv + final_locked_models_nested_oof.rds"
  }
  list(bundle = bundle, locked_models = locked_models, source = source)
}

run_performance_analysis <- function() {
  results_dir <- existing_directory(env_or("SDC2_RESULTS_DIR", RESULTS$classification))
  output_dir <- env_or("SDC2_PERFORMANCE_OUTPUT_DIR", RESULTS$performance)
  table_dir <- file.path(output_dir, "tables")
  rds_dir <- file.path(output_dir, "rds")
  for (path in c(table_dir, rds_dir)) dir.create(path, recursive = TRUE, showWarnings = FALSE)

  seed <- env_int("SDC2_PERFORMANCE_SEED", 20260819L)
  b_nri <- env_int("SDC2_NRI_BOOT", 2000L)
  b_cal <- env_int("SDC2_CALIBRATION_BOOT", 1000L)
  b_dca <- env_int("SDC2_DCA_BOOT", 1000L)
  dca_min <- env_num("SDC2_DCA_MIN", 0.01)
  dca_max <- env_num("SDC2_DCA_MAX", 0.50)
  dca_step <- env_num("SDC2_DCA_STEP", 0.01)
  if (!(dca_min > 0 && dca_max < 1 && dca_min < dca_max && dca_step > 0)) {
    stop("DCA thresholds must satisfy 0 < min < max < 1 and step > 0.", call. = FALSE)
  }
  thresholds <- seq(dca_min, dca_max, by = dca_step)

  loaded <- load_evaluation_bundle(results_dir)
  bundle <- loaded$bundle
  saveRDS(bundle, file.path(rds_dir, "performance_evaluation_input_bundle.rds"), compress = "xz")
  predictions <- as_tibble(bundle$outer_oof_predictions)
  required <- c("task", "ID", "Sequence_ID", "outcome", "mSDC2", "Microbiome", "Combined_offset", "Combined_free_sensitivity")
  assert_columns(predictions, required, "outer_oof_predictions")
  probability_columns <- c("mSDC2", "Microbiome", "Combined_offset", "Combined_free_sensitivity")
  if (anyDuplicated(predictions[c("task", "ID")])) stop("Each patient ID must appear once per task in OOF predictions.", call. = FALSE)
  if (anyDuplicated(predictions[c("task", "Sequence_ID")])) stop("Each sequencing sample must appear once per task in OOF predictions.", call. = FALSE)
  if (!all(predictions$outcome %in% c(0L, 1L))) stop("Outcome must be coded 0/1.", call. = FALSE)
  if (!all(vapply(predictions[probability_columns], function(x) all(is.finite(x) & x >= 0 & x <= 1), logical(1)))) {
    stop("All model probabilities must be finite and lie in [0, 1].", call. = FALSE)
  }
  tasks <- unique(predictions$task)
  audit <- predictions %>% group_by(task) %>% summarise(
    n = n(), unique_patients = n_distinct(ID), events = sum(outcome == 1L),
    nonevents = sum(outcome == 0L), observed_prevalence = mean(outcome), .groups = "drop"
  ) %>% mutate(input_source = loaded$source)
  write.csv(audit, file.path(table_dir, "00_performance_input_audit.csv"), row.names = FALSE, fileEncoding = "UTF-8")

  comparisons <- tribble(
    ~analysis_set, ~new_model, ~reference_model,
    "Primary", "Combined_offset", "mSDC2",
    "Primary", "Combined_offset", "Microbiome",
    "Sensitivity", "Combined_free_sensitivity", "mSDC2",
    "Sensitivity", "Combined_free_sensitivity", "Microbiome"
  )
  nri_objects <- list()
  nri_summary <- predictions %>% group_split(task) %>% map_dfr(function(dat) {
    task_name <- unique(dat$task)
    comparisons %>% pmap_dfr(function(analysis_set, new_model, reference_model) {
      result <- bootstrap_continuous_nri(
        dat$outcome, dat[[new_model]], dat[[reference_model]], b_nri,
        make_seed(seed, "nri", task_name, new_model, reference_model)
      )
      nri_objects[[paste(task_name, new_model, reference_model, sep = "|")]] <<- result$replicates
      result$summary %>% mutate(task = task_name, analysis_set = analysis_set,
                                new_model = new_model, reference_model = reference_model, .before = 1)
    })
  }) %>% group_by(analysis_set, component) %>% mutate(p_holm = p.adjust(p_value, method = "holm")) %>% ungroup()
  write.csv(nri_summary, file.path(table_dir, "01_continuous_NRI_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  saveRDS(nri_objects, file.path(rds_dir, "continuous_NRI_bootstrap_replicates.rds"), compress = "xz")

  calibration_objects <- list()
  calibration_curve_data <- list()
  calibration_group_data <- list()
  calibration_stats <- list()
  for (task_name in tasks) {
    dat <- predictions %>% filter(task == task_name)
    for (model_name in probability_columns) {
      result <- bootstrap_calibration(
        dat$outcome, dat[[model_name]], b_cal,
        make_seed(seed, "calibration", task_name, model_name)
      )
      key <- paste(task_name, model_name, sep = "|")
      calibration_objects[[key]] <- result
      calibration_curve_data[[key]] <- result$curve %>% mutate(task = task_name, model = model_name, .before = 1)
      calibration_group_data[[key]] <- result$groups %>% mutate(task = task_name, model = model_name, .before = 1)
      calibration_stats[[key]] <- result$statistics %>% mutate(task = task_name, model = model_name, .before = 1)
    }
  }
  calibration_curves <- bind_rows(calibration_curve_data)
  calibration_points <- bind_rows(calibration_group_data)
  calibration_statistics_table <- bind_rows(calibration_stats)
  write.csv(calibration_curves, file.path(table_dir, "02_calibration_curves_bootstrap_CI.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(calibration_points, file.path(table_dir, "03_calibration_grouped_points.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(calibration_statistics_table, file.path(table_dir, "04_calibration_intercept_slope.csv"), row.names = FALSE, fileEncoding = "UTF-8")

  dca_data <- predictions %>% group_split(task) %>% map_dfr(function(dat) {
    task_name <- unique(dat$task)
    probabilities <- as.list(dat[probability_columns])
    bootstrap_decision_curves(dat$outcome, probabilities, thresholds, b_dca,
                              make_seed(seed, "dca", task_name)) %>% mutate(task = task_name, .before = 1)
  })
  dca_intervals <- dca_data %>% filter(strategy %in% c("Combined_offset", "mSDC2", "Microbiome", "Treat all", "Treat none")) %>%
    group_split(task) %>% map_dfr(~ dominant_threshold_intervals(.x, "Combined_offset"))
  write.csv(dca_data, file.path(table_dir, "05_decision_curve_net_benefit.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(dca_intervals, file.path(table_dir, "06_DCA_candidate_threshold_intervals.csv"), row.names = FALSE, fileEncoding = "UTF-8")

  analysis_bundle <- list(
    schema_version = "1.0", generated_at = format(Sys.time(), tz = "Asia/Shanghai"),
    input_source = loaded$source,
    configuration = list(seed = seed, nri_bootstrap = b_nri, calibration_bootstrap = b_cal,
                         dca_bootstrap = b_dca, dca_thresholds = thresholds),
    input_audit = audit, continuous_nri = nri_summary,
    calibration_curves = calibration_curves, calibration_grouped_points = calibration_points,
    calibration_statistics = calibration_statistics_table,
    decision_curves = dca_data, dca_candidate_threshold_intervals = dca_intervals
  )
  saveRDS(analysis_bundle, file.path(rds_dir, "performance_improvement_results.rds"), compress = "xz")
  writeLines(c(
    "Continuous NRI compares paired OOF probabilities. Ties contribute zero.",
    "Confidence intervals use task-specific outcome-stratified patient-level bootstrap resampling.",
    "NRI P values use the bootstrap standard error with a two-sided normal approximation; Holm-adjusted values control multiplicity across the five tasks and two reference models within each analysis set.",
    "Calibration curves use bias-reduced logistic calibration with a natural spline when supported by the number of unique predictions; grouped points use exact binomial 95% confidence intervals.",
    "DCA uses the observed task-specific prevalence because MGS contains all eligible events during 2020-2026. The threshold probability encodes the false-positive:false-negative harm weight pt/(1-pt).",
    "Reported DCA intervals require at least three consecutive grid points with higher net benefit and are exploratory ranges, not deployment cutoffs. Thresholds must be prespecified and externally validated before clinical use.",
    "Continuous NRI can be sensitive when a model with near-continuous probabilities is compared with a discrete test such as binary mSDC2; event and nonevent components and tie patterns should be interpreted alongside total NRI.",
    "All primary performance estimates use pooled outer-fold OOF predictions; locked-model apparent predictions are not used."
  ), file.path(output_dir, "METHODS_AND_INTERPRETATION_NOTES.txt"), useBytes = TRUE)
  capture.output(sessionInfo(), file = file.path(output_dir, "sessionInfo.txt"))
  message("Performance improvement analysis completed: ", normalizePath(output_dir, winslash = "/"))
  invisible(analysis_bundle)
}

if (!identical(Sys.getenv("SDC2_PERFORMANCE_FUNCTIONS_ONLY", unset = "0"), "1")) {
  run_performance_analysis()
}
