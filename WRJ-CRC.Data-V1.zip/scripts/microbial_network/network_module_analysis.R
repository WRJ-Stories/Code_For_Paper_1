#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
source(file.path("config", "project_paths.R"))

# Direct-run defaults; all paths are relative to the repository project.
NETWORK_RUN_CONFIG <- list(
  project_dir = CLINICAL_DATA_DIR,
  output_root = RESULTS$network,
  validate_only = FALSE,
  quick = FALSE,
  skip_network_permutations = FALSE,
  skip_bootstrap = FALSE
)

filter_species_prevalence <- function(abundance, threshold = 0.10) {
  abundance <- as.matrix(abundance)
  if (!is.numeric(abundance) || any(!is.finite(abundance)) || any(abundance < 0)) {
    stop("abundance must be a finite, non-negative numeric matrix")
  }
  if (!is.numeric(threshold) || length(threshold) != 1L || threshold < 0 || threshold > 1) {
    stop("threshold must be a single number between 0 and 1")
  }
  colnames(abundance)[colMeans(abundance > 0) >= threshold]
}

close_composition <- function(x) {
  x <- as.matrix(x)
  totals <- rowSums(x)
  if (any(!is.finite(x)) || any(x < 0) || any(totals <= 0)) {
    stop("Each composition must contain finite non-negative values with a positive row sum")
  }
  x / totals
}

replace_compositional_zeros <- function(x) {
  x <- close_composition(x)
  if (!any(x == 0)) return(x)
  if (!requireNamespace("zCompositions", quietly = TRUE)) {
    stop("Package 'zCompositions' is required for zero replacement")
  }
  original_dim <- dim(x)
  original_dimnames <- dimnames(x)
  replaced <- as.matrix(zCompositions::cmultRepl(
    x,
    label = 0,
    method = "CZM",
    output = "prop",
    z.delete = FALSE,
    z.warning = 1,
    suppress.print = TRUE
  ))
  if (!identical(dim(replaced), original_dim)) {
    stop("Zero replacement changed matrix dimensions; no sample or feature deletion is allowed")
  }
  dimnames(replaced) <- original_dimnames
  if (any(!is.finite(replaced)) || any(replaced <= 0)) {
    stop("Zero replacement did not return a finite, strictly positive matrix")
  }
  replaced
}

clr_transform <- function(x) {
  x <- replace_compositional_zeros(x)
  lx <- log(x)
  lx - rowMeans(lx)
}

module_clr_scores <- function(abundance, membership) {
  abundance <- as.matrix(abundance)
  if (is.null(colnames(abundance))) stop("abundance must have species column names")
  if (is.null(names(membership))) stop("membership must be a named vector")
  missing_species <- setdiff(colnames(abundance), names(membership))
  if (length(missing_species)) {
    stop("membership is missing species: ", paste(missing_species, collapse = ", "))
  }
  membership <- as.character(membership[colnames(abundance)])
  module_ids <- sort(setdiff(unique(membership), "Unassigned"))
  if (!length(module_ids)) stop("No inferential modules remain after excluding Unassigned")
  module_abundance <- vapply(
    module_ids,
    function(module_id) rowSums(abundance[, membership == module_id, drop = FALSE]),
    numeric(nrow(abundance))
  )
  if (is.null(dim(module_abundance))) {
    module_abundance <- matrix(module_abundance, ncol = 1L)
  }
  rownames(module_abundance) <- rownames(abundance)
  colnames(module_abundance) <- module_ids
  clr_transform(module_abundance)
}

module_eigenscores <- function(species_clr, membership, hub_species = NULL) {
  species_clr <- as.matrix(species_clr)
  if (is.null(colnames(species_clr))) stop("species_clr must have species column names")
  if (is.null(names(membership))) stop("membership must be a named vector")
  membership <- as.character(membership[colnames(species_clr)])
  if (anyNA(membership)) stop("membership is missing one or more species")
  module_ids <- sort(setdiff(unique(membership), "Unassigned"))
  if (!length(module_ids)) stop("No inferential modules remain after excluding Unassigned")
  scores <- matrix(
    NA_real_, nrow = nrow(species_clr), ncol = length(module_ids),
    dimnames = list(rownames(species_clr), module_ids)
  )
  loadings <- matrix(
    NA_real_, nrow = ncol(species_clr), ncol = length(module_ids),
    dimnames = list(colnames(species_clr), module_ids)
  )
  explained <- setNames(numeric(length(module_ids)), module_ids)

  for (module_id in module_ids) {
    species <- colnames(species_clr)[membership == module_id]
    x <- species_clr[, species, drop = FALSE]
    variable <- apply(x, 2L, stats::sd, na.rm = TRUE) > 0
    if (!all(variable)) {
      stop("PC1 cannot retain every species because zero-variance species were found in ", module_id)
    }
    fit <- stats::prcomp(x, center = TRUE, scale. = TRUE)
    score <- fit$x[, 1L]
    loading <- fit$rotation[, 1L]
    explained[[module_id]] <- fit$sdev[1L]^2 / sum(fit$sdev^2)
    names(loading) <- colnames(x)
    hub <- if (!is.null(hub_species) && module_id %in% names(hub_species)) hub_species[[module_id]] else names(loading)[which.max(abs(loading))]
    orient_value <- if (hub %in% names(loading)) loading[[hub]] else sum(loading)
    if (is.finite(orient_value) && orient_value < 0) {
      score <- -score
      loading <- -loading
    }
    scores[, module_id] <- score
    loadings[names(loading), module_id] <- loading
  }

  list(scores = scores, loadings = loadings, explained_variance = explained)
}

collapse_small_modules <- function(membership, minimum_size = 4L) {
  if (is.null(names(membership))) stop("membership must be a named vector")
  sizes <- table(membership)
  out <- as.character(membership)
  out[sizes[as.character(membership)] < minimum_size] <- "Unassigned"
  stats::setNames(out, names(membership))
}

summarize_score_concordance <- function(module_clr, eigenscore, eig) {
  module_clr <- as.matrix(module_clr)
  eigenscore <- as.matrix(eigenscore)
  if (!identical(rownames(module_clr), rownames(eigenscore))) {
    stop("CLR and PC1 scores must contain the same samples in the same order")
  }
  module_ids <- intersect(colnames(module_clr), colnames(eigenscore))
  out <- do.call(rbind, lapply(module_ids, function(module_id) {
    loading <- eig$loadings[, module_id]
    loading <- loading[is.finite(loading)]
    data.frame(
      Module = module_id,
      PC1ExplainedVariance = unname(eig$explained_variance[[module_id]]),
      SpeciesWithLoadings = length(loading),
      PositiveLoadings = sum(loading > 0),
      NegativeLoadings = sum(loading < 0),
      DominantLoadingSignFraction = max(sum(loading > 0), sum(loading < 0)) / length(loading),
      AllLoadingsSameSign = sum(loading > 0) == 0L || sum(loading < 0) == 0L,
      MeanAbsoluteLoading = mean(abs(loading)),
      PearsonCorrelation = suppressWarnings(stats::cor(module_clr[, module_id], eigenscore[, module_id], method = "pearson")),
      SpearmanCorrelation = suppressWarnings(stats::cor(module_clr[, module_id], eigenscore[, module_id], method = "spearman")),
      stringsAsFactors = FALSE
    )
  }))
  data.table::as.data.table(out)
}

add_within_module_fdr <- function(results) {
  results$Q_Global <- stats::p.adjust(results$P_Value, method = "BH")
  results$Q_WithinModule <- ave(
    results$P_Value,
    results$Module,
    FUN = function(x) stats::p.adjust(x, method = "BH")
  )
  results$Q_Value <- results$Q_Global
  results
}

parse_level4ec_feature <- function(feature) {
  feature <- as.character(feature)
  stratified <- grepl("|", feature, fixed = TRUE)
  ec <- sub("\\|.*$", "", feature)
  species <- rep(NA_character_, length(feature))
  species[stratified] <- sub("^.*(s__[^|]+)$", "\\1", feature[stratified])
  eligible <- stratified & !is.na(species) & grepl("^[0-9-]+(\\.[0-9-]+){3}$", ec)
  data.frame(EC = ec, Species = species, Stratified = stratified, Eligible = eligible, stringsAsFactors = FALSE)
}

adjusted_rand_index <- function(reference, candidate) {
  keep <- intersect(names(reference), names(candidate))
  if (length(keep) < 2L) return(NA_real_)
  tab <- table(reference[keep], candidate[keep])
  choose2 <- function(x) x * (x - 1) / 2
  index <- sum(choose2(tab))
  row_sum <- sum(choose2(rowSums(tab)))
  col_sum <- sum(choose2(colSums(tab)))
  total <- choose2(sum(tab))
  expected <- row_sum * col_sum / total
  denominator <- 0.5 * (row_sum + col_sum) - expected
  if (denominator == 0) return(if (index == expected) 1 else 0)
  (index - expected) / denominator
}

summarize_bootstrap_memberships <- function(reference, bootstrap_memberships) {
  if (is.null(names(reference))) stop("reference membership must be named")
  reference_names <- names(reference)
  reference <- as.character(reference)
  names(reference) <- reference_names
  ref_modules <- sort(unique(reference[reference != "Unassigned"]))
  replicate_rows <- list()
  module_rows <- list()
  species_rows <- list()
  for (i in seq_along(bootstrap_memberships)) {
    candidate <- bootstrap_memberships[[i]]
    keep <- intersect(names(reference), names(candidate))
    candidate <- stats::setNames(as.character(candidate[keep]), keep)
    ref <- reference[keep]
    ari_keep <- keep[ref != "Unassigned"]
    replicate_rows[[i]] <- data.frame(
      Replicate = i,
      ARI = adjusted_rand_index(reference[ari_keep], candidate[ari_keep])
    )
    for (module_id in ref_modules) {
      ref_species <- keep[ref == module_id]
      candidate_modules <- unique(candidate)
      jaccard <- vapply(candidate_modules, function(x) {
        candidate_species <- keep[candidate == x]
        length(intersect(ref_species, candidate_species)) / length(union(ref_species, candidate_species))
      }, numeric(1L))
      pairs <- utils::combn(ref_species, 2L)
      coassigned <- if (ncol(pairs)) mean(candidate[pairs[1L, ]] == candidate[pairs[2L, ]]) else NA_real_
      module_rows[[length(module_rows) + 1L]] <- data.frame(
        Replicate = i, Module = module_id, BestJaccard = max(jaccard), PairCoassignment = coassigned
      )
      for (species in ref_species) {
        peers <- setdiff(ref_species, species)
        stability <- if (length(peers)) mean(candidate[peers] == candidate[[species]]) else NA_real_
        species_rows[[length(species_rows) + 1L]] <- data.frame(
          Replicate = i, Species = species, ReferenceModule = module_id, MembershipStability = stability
        )
      }
    }
  }
  replicate_detail <- do.call(rbind, replicate_rows)
  module_detail <- do.call(rbind, module_rows)
  species_detail <- do.call(rbind, species_rows)
  module_summary <- do.call(rbind, lapply(split(module_detail, module_detail$Module), function(x) {
    data.frame(
      Module = x$Module[1L], MeanBestJaccard = mean(x$BestJaccard),
      MedianBestJaccard = stats::median(x$BestJaccard),
      JaccardLower95 = stats::quantile(x$BestJaccard, 0.025, names = FALSE),
      JaccardUpper95 = stats::quantile(x$BestJaccard, 0.975, names = FALSE),
      MeanPairCoassignment = mean(x$PairCoassignment, na.rm = TRUE)
    )
  }))
  species_summary <- do.call(rbind, lapply(split(species_detail, species_detail$Species), function(x) {
    data.frame(
      Species = x$Species[1L], ReferenceModule = x$ReferenceModule[1L],
      MeanMembershipStability = mean(x$MembershipStability, na.rm = TRUE)
    )
  }))
  list(
    replicate_summary = data.table::as.data.table(replicate_detail),
    replicate_detail = data.table::as.data.table(replicate_detail),
    module_detail = data.table::as.data.table(module_detail),
    module_summary = data.table::as.data.table(module_summary),
    species_detail = data.table::as.data.table(species_detail),
    species_summary = data.table::as.data.table(species_summary)
  )
}

cosine_similarity <- function(x, y) {
  x <- as.numeric(x)
  y <- as.numeric(y)
  denom <- sqrt(sum(x^2)) * sqrt(sum(y^2))
  if (!is.finite(denom) || denom == 0) return(NA_real_)
  sum(x * y) / denom
}

perm_p_two_sided <- function(observed, null, center = 0) {
  null <- null[is.finite(null)]
  if (!length(null) || !is.finite(observed) || !is.finite(center)) return(NA_real_)
  (1 + sum(abs(null - center) >= abs(observed - center))) / (length(null) + 1)
}

association_direction <- function(beta, q_value, alpha = 0.05) {
  if (!is.finite(beta) || !is.finite(q_value) || q_value >= alpha) return("Not_significant")
  if (beta > 0) "mSDC2(+)" else if (beta < 0) "mSDC2(-)" else "Not_significant"
}

global_efficiency_safe <- function(graph) {
  n <- igraph::vcount(graph)
  if (n < 2L || igraph::ecount(graph) == 0L) return(0)
  d <- igraph::distances(graph, mode = "all", weights = NA)
  inv_d <- 1 / d[upper.tri(d)]
  inv_d[!is.finite(inv_d)] <- 0
  mean(inv_d)
}

module_connectivity <- function(graph, membership) {
  membership_names <- names(membership)
  membership <- stats::setNames(as.character(membership), membership_names)
  if (is.null(names(membership))) stop("membership must be named by graph vertex")
  membership <- membership[igraph::V(graph)$name]
  if (anyNA(membership)) stop("membership does not cover every graph vertex")
  module_ids <- sort(setdiff(unique(membership), "Unassigned"))
  out <- setNames(numeric(length(module_ids)), module_ids)
  for (module_id in module_ids) {
    vertices <- names(membership)[membership == module_id]
    n <- length(vertices)
    if (n < 2L) {
      out[[module_id]] <- 0
      next
    }
    subgraph <- igraph::induced_subgraph(graph, vertices)
    strength <- if (igraph::ecount(subgraph)) {
      if (!is.null(igraph::edge_attr(subgraph, "association"))) {
        sum(abs(igraph::E(subgraph)$association))
      } else if (!is.null(igraph::edge_attr(subgraph, "weight"))) {
        sum(abs(igraph::E(subgraph)$weight))
      } else {
        igraph::ecount(subgraph)
      }
    } else 0
    out[[module_id]] <- strength / choose(n, 2L)
  }
  out
}

fit_limma_association <- function(features, metadata, include_clinical_group = FALSE) {
  if (!requireNamespace("limma", quietly = TRUE)) stop("Package 'limma' is required")
  if (!requireNamespace("data.table", quietly = TRUE)) stop("Package 'data.table' is required")
  features <- as.matrix(features)
  if (is.null(rownames(features)) || is.null(colnames(features))) {
    stop("features must have sample row names and feature column names")
  }
  required <- c("Sequence_ID", "SDC2_Category", "Age", "Gender")
  if (include_clinical_group) required <- c(required, "Group")
  missing_columns <- setdiff(required, names(metadata))
  if (length(missing_columns)) stop("metadata is missing: ", paste(missing_columns, collapse = ", "))
  metadata <- metadata[match(rownames(features), metadata$Sequence_ID), , drop = FALSE]
  if (anyNA(metadata$Sequence_ID)) stop("metadata does not cover every feature sample")
  if (any(!is.finite(features))) stop("features contain non-finite values")
  metadata$SDC2_Group <- factor(metadata$SDC2_Category, levels = c("mSDC2(-)", "mSDC2(+)"))
  metadata$Age_z <- as.numeric(scale(as.numeric(metadata$Age)))
  metadata$Gender <- factor(metadata$Gender)
  if (include_clinical_group) metadata$Clinical_Group <- factor(metadata$Group)
  formula <- if (include_clinical_group) {
    ~ SDC2_Group + Age_z + Gender + Clinical_Group
  } else {
    ~ SDC2_Group + Age_z + Gender
  }
  design <- stats::model.matrix(formula, data = metadata)
  if (qr(design)$rank < ncol(design)) {
    stop("The requested association design matrix is rank deficient")
  }
  coef_name <- "SDC2_GroupmSDC2(+)"
  if (!coef_name %in% colnames(design)) stop("Could not identify the mSDC2 contrast")
  fit <- limma::eBayes(limma::lmFit(t(features), design), trend = TRUE, robust = TRUE)
  tab <- limma::topTable(fit, coef = coef_name, number = Inf, sort.by = "none", confint = TRUE)
  tab$Feature <- rownames(tab)
  out <- data.table::as.data.table(tab)[, .(
    Feature,
    Beta = logFC,
    CI_Lower = CI.L,
    CI_Upper = CI.R,
    T = t,
    P_Value = P.Value,
    Q_Value = adj.P.Val
  )]
  out[, Association := mapply(association_direction, Beta, Q_Value)]
  out[]
}

`%||%` <- function(x, y) if (is.null(x)) y else x

preserve_cli_path <- function(path) {
  chartr("\\", "/", path.expand(path))
}

get_script_dir <- function() {
  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (length(file_arg)) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[[1L]]), winslash = "/", mustWork = FALSE)))
  }
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
}

parse_cli <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_of <- function(prefix, default = NULL) {
    hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
    if (!length(hit)) return(default)
    sub(paste0("^", prefix, "="), "", hit[[1L]])
  }
  list(
    project_dir = value_of("--project-dir", CLINICAL_DATA_DIR),
    output_root = value_of("--output-root", RESULTS$network),
    validate_only = "--validate-only" %in% args,
    quick = "--quick" %in% args,
    skip_network_permutations = "--skip-network-permutations" %in% args,
    skip_bootstrap = "--skip-bootstrap" %in% args
  )
}

make_config <- function(quick = FALSE) {
  config <- list(
    seed = 20261003L,
    prevalence_threshold = 0.10,
    minimum_module_size = 4L,
    functional_prevalence_threshold = 0.10,
    spiec_method = "mb",
    lambda_min_ratio = 1e-2,
    nlambda = 50L,
    stars_repetitions = 50L,
    stars_threshold = 0.05,
    modularity_permutations = 999L,
    functional_permutations = 999L,
    network_permutations = 999L,
    bootstrap_repetitions = 100L,
    bootstrap_chunk_size = 5L,
    bootstrap_workers = max(1L, min(2L, parallel::detectCores(logical = FALSE) - 1L)),
    permutation_chunk_size = 25L,
    workers = max(1L, min(4L, parallel::detectCores(logical = FALSE) - 1L))
  )
  if (quick) {
    config$nlambda <- 10L
    config$stars_repetitions <- 5L
    config$modularity_permutations <- 9L
    config$functional_permutations <- 9L
    config$network_permutations <- 9L
    config$bootstrap_repetitions <- 3L
    config$bootstrap_chunk_size <- 1L
    config$bootstrap_workers <- 1L
    config$permutation_chunk_size <- 3L
    config$workers <- 1L
  }
  config
}

required_analysis_packages <- function() {
  c("data.table", "SpiecEasi", "igraph", "zCompositions", "limma", "future", "future.apply")
}

check_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1L), quietly = TRUE)]
  if (length(missing)) {
    stop(
      "Missing required R packages: ", paste(missing, collapse = ", "),
      ". Install them before running the full analysis."
    )
  }
}

create_output_dirs <- function(output_root) {
  result_subdirs <- c(
    "01_qc", "02_pooled_network", "03_modules", "04_module_association",
    "05_module_function", "06_group_network_comparison", "07_module_stability",
    "08_evidence_chain"
  )
  result_dirs <- file.path(output_root, result_subdirs)
  invisible(lapply(result_dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
  list(
    results_root = output_root,
    results = stats::setNames(result_dirs, result_subdirs)
  )
}

write_tsv <- function(x, path) {
  data.table::fwrite(data.table::as.data.table(x), path, sep = "\t", quote = FALSE, na = "NA")
}

read_and_validate_inputs <- function(project_dir, dirs, config) {
  metadata_path <- file.path(project_dir, "NF_Cohort2.txt")
  taxonomy_path <- file.path(project_dir, "taxonomy_Species.txt")
  pathway_path <- file.path(project_dir, "pathabundance_relab3_stratified.tsv")
  ec_path <- file.path(project_dir, "level4ec_relab_stratified.tsv")
  input_paths <- c(metadata_path, taxonomy_path, pathway_path, ec_path)
  missing_files <- input_paths[!file.exists(input_paths)]
  if (length(missing_files)) stop("Missing input files: ", paste(missing_files, collapse = ", "))

  metadata <- data.table::fread(metadata_path, sep = "\t", data.table = FALSE, check.names = FALSE)
  required_meta <- c("Sequence_ID", "SDC2_Category", "Age", "Gender", "Group")
  missing_meta <- setdiff(required_meta, names(metadata))
  if (length(missing_meta)) stop("Metadata is missing columns: ", paste(missing_meta, collapse = ", "))
  metadata$Sequence_ID <- trimws(as.character(metadata$Sequence_ID))
  if (anyDuplicated(metadata$Sequence_ID)) stop("Metadata Sequence_ID values must be unique")
  if (anyNA(metadata$Sequence_ID) || any(trimws(metadata$Sequence_ID) == "")) {
    stop("Metadata Sequence_ID values must be non-missing and non-blank")
  }
  if (anyNA(metadata[, required_meta]) || any(trimws(as.character(metadata$Sequence_ID)) == "")) {
    stop("Required metadata columns contain missing or blank values")
  }
  if (!setequal(unique(metadata$SDC2_Category), c("mSDC2(-)", "mSDC2(+)"))) {
    stop("SDC2_Category must contain exactly mSDC2(-) and mSDC2(+)")
  }
  metadata$Age <- as.numeric(metadata$Age)
  if (any(!is.finite(metadata$Age))) stop("Age must be numeric and finite")

  taxonomy <- data.table::fread(taxonomy_path, sep = "\t", data.table = FALSE, check.names = FALSE)
  if (!"ID" %in% names(taxonomy)) stop("taxonomy_Species.txt must contain an ID column")
  if (anyDuplicated(taxonomy$ID)) stop("Taxonomy species IDs must be unique")
  taxonomy_samples <- setdiff(names(taxonomy), "ID")
  pathway_header <- names(data.table::fread(pathway_path, sep = "\t", nrows = 0L, check.names = FALSE))
  required_pathway <- c("PathwayID", "Pathway", "Genus", "Species")
  if (!all(required_pathway %in% pathway_header)) {
    stop("HUMAnN3 table must begin with PathwayID, Pathway, Genus, and Species columns")
  }
  pathway_samples <- setdiff(pathway_header, required_pathway)
  ec_header <- names(data.table::fread(ec_path, sep = "\t", nrows = 0L, check.names = FALSE))
  if (!"# Gene Family" %in% ec_header) stop("level4ec table must contain a '# Gene Family' column")
  ec_samples <- setdiff(ec_header, "# Gene Family")
  common_samples <- metadata$Sequence_ID[
    metadata$Sequence_ID %in% taxonomy_samples &
      metadata$Sequence_ID %in% pathway_samples &
      metadata$Sequence_ID %in% ec_samples
  ]
  if (!length(common_samples)) stop("No Sequence_ID is shared by NF_Cohort2 metadata, taxonomy, pathway, and EC tables")
  abundance <- t(as.matrix(taxonomy[, common_samples, drop = FALSE]))
  storage.mode(abundance) <- "double"
  rownames(abundance) <- common_samples
  colnames(abundance) <- taxonomy$ID
  if (any(!is.finite(abundance)) || any(abundance < 0)) stop("Taxonomy abundance contains invalid values")
  retained_species <- filter_species_prevalence(abundance, config$prevalence_threshold)
  abundance_filtered <- abundance[, retained_species, drop = FALSE]
  if (ncol(abundance_filtered) < 2L) stop("Prevalence filtering retained fewer than two species")
  functional_samples <- common_samples

  sample_exclusions <- data.table::rbindlist(list(
    data.table::data.table(Source = "taxonomy", Sample = setdiff(taxonomy_samples, metadata$Sequence_ID), Reason = "No metadata"),
    data.table::data.table(Source = "taxonomy", Sample = setdiff(metadata$Sequence_ID, taxonomy_samples), Reason = "No taxonomy profile; excluded from full intersection"),
    data.table::data.table(Source = "HUMAnN3", Sample = setdiff(pathway_samples, metadata$Sequence_ID), Reason = "No metadata"),
    data.table::data.table(Source = "HUMAnN3", Sample = setdiff(metadata$Sequence_ID, pathway_samples), Reason = "No pathway profile; excluded from full intersection"),
    data.table::data.table(Source = "HUMAnN3_EC", Sample = setdiff(ec_samples, metadata$Sequence_ID), Reason = "No metadata"),
    data.table::data.table(Source = "HUMAnN3_EC", Sample = setdiff(metadata$Sequence_ID, ec_samples), Reason = "No EC profile; excluded from full intersection")
  ), use.names = TRUE)
  metadata_common <- metadata[match(common_samples, metadata$Sequence_ID), , drop = FALSE]
  group_counts <- data.table::as.data.table(metadata_common)[, .N, by = SDC2_Category][order(SDC2_Category)]
  qc_summary <- data.table::data.table(
    Metric = c(
      "Metadata samples", "Full-intersection samples", "Taxonomy analysis samples", "Functional analysis samples",
      "Species before filtering", "Species after global prevalence filtering",
      "Taxonomy sample-sum minimum", "Taxonomy sample-sum median", "Taxonomy sample-sum maximum"
    ),
    Value = c(
      nrow(metadata), length(common_samples), nrow(abundance), length(functional_samples), ncol(abundance),
      ncol(abundance_filtered), min(rowSums(abundance)), median(rowSums(abundance)), max(rowSums(abundance))
    )
  )
  prevalence <- data.table::data.table(
    Species = colnames(abundance),
    Prevalence = colMeans(abundance > 0),
    Retained = colnames(abundance) %in% retained_species
  )
  write_tsv(qc_summary, file.path(dirs$results[["01_qc"]], "qc_summary.tsv"))
  write_tsv(group_counts, file.path(dirs$results[["01_qc"]], "group_counts.tsv"))
  write_tsv(sample_exclusions, file.path(dirs$results[["01_qc"]], "sample_exclusions.tsv"))
  write_tsv(prevalence, file.path(dirs$results[["01_qc"]], "species_prevalence.tsv"))

  metadata_taxonomy <- metadata_common
  metadata_function <- metadata_common
  list(
    metadata = metadata_taxonomy,
    metadata_function = metadata_function,
    abundance = abundance_filtered,
    pathway_path = pathway_path,
    ec_path = ec_path,
    functional_samples = functional_samples,
    qc_summary = qc_summary,
    sample_exclusions = sample_exclusions
  )
}

safe_eigenvector <- function(graph) {
  if (igraph::ecount(graph) == 0L) return(stats::setNames(rep(0, igraph::vcount(graph)), igraph::V(graph)$name))
  suppressWarnings(igraph::eigen_centrality(graph, directed = FALSE, weights = igraph::E(graph)$weight, scale = TRUE)$vector)
}

attach_graph_statistics <- function(graph, abundance) {
  species <- igraph::V(graph)$name
  igraph::V(graph)$mean_abundance <- colMeans(abundance)[species]
  igraph::V(graph)$prevalence <- colMeans(abundance > 0)[species]
  igraph::V(graph)$degree <- igraph::degree(graph, mode = "all")
  igraph::V(graph)$degree_normalized <- if (igraph::vcount(graph) > 1L) igraph::V(graph)$degree / (igraph::vcount(graph) - 1L) else 0
  igraph::V(graph)$betweenness <- if (igraph::ecount(graph)) igraph::betweenness(graph, directed = FALSE, weights = NA, normalized = TRUE) else 0
  igraph::V(graph)$eigenvector <- safe_eigenvector(graph)[species]
  graph
}

fit_spiec_graph <- function(abundance, config, seed) {
  abundance <- as.matrix(abundance)
  if (!"package:SpiecEasi" %in% search()) {
    suppressPackageStartupMessages(library("SpiecEasi", character.only = TRUE))
  }
  if (any(apply(abundance, 2L, stats::sd) == 0)) stop("SPIEC-EASI input contains zero-variance species")
  set.seed(seed)
  model <- SpiecEasi::spiec.easi(
    abundance,
    method = config$spiec_method,
    lambda.min.ratio = config$lambda_min_ratio,
    nlambda = config$nlambda,
    pulsar.params = list(rep.num = config$stars_repetitions, thresh = config$stars_threshold)
  )
  adjacency <- as.matrix(SpiecEasi::getRefit(model))
  beta <- as.matrix(SpiecEasi::symBeta(SpiecEasi::getOptBeta(model), mode = "maxabs"))
  rownames(adjacency) <- colnames(adjacency) <- colnames(abundance)
  rownames(beta) <- colnames(beta) <- colnames(abundance)
  graph <- igraph::graph_from_adjacency_matrix(adjacency, mode = "undirected", diag = FALSE)
  if (igraph::ecount(graph)) {
    endpoints <- igraph::ends(graph, igraph::E(graph), names = TRUE)
    association <- beta[cbind(endpoints[, 1L], endpoints[, 2L])]
    igraph::E(graph)$association <- association
    igraph::E(graph)$weight <- abs(association)
    igraph::E(graph)$sign <- ifelse(association > 0, "positive", "negative")
  }
  graph <- attach_graph_statistics(graph, abundance)
  list(model = model, graph = graph, adjacency = adjacency, beta = beta)
}

relabel_membership <- function(raw_membership, species_names) {
  tab <- data.table::data.table(Species = species_names, Raw = as.character(raw_membership))
  order_tab <- tab[, .(Size = .N, FirstSpecies = min(Species)), by = Raw][order(-Size, FirstSpecies)]
  map <- stats::setNames(sprintf("M%02d", seq_len(nrow(order_tab))), order_tab$Raw)
  stats::setNames(unname(map[tab$Raw]), tab$Species)
}

detect_association_modules <- function(graph) {
  if (igraph::ecount(graph) == 0L) {
    membership <- stats::setNames(sprintf("M%02d", seq_len(igraph::vcount(graph))), igraph::V(graph)$name)
    igraph::V(graph)$module <- membership[igraph::V(graph)$name]
    return(list(graph = graph, membership = membership, modularity = 0, communities = NULL))
  }
  communities <- igraph::cluster_leiden(
    graph,
    objective_function = "modularity",
    weights = igraph::E(graph)$weight,
    resolution = 1,
    n_iterations = -1L
  )
  membership <- relabel_membership(igraph::membership(communities), igraph::V(graph)$name)
  igraph::V(graph)$module <- membership[igraph::V(graph)$name]
  q <- igraph::modularity(graph, membership = as.integer(factor(membership)), weights = igraph::E(graph)$weight)
  list(graph = graph, membership = membership, modularity = q, communities = communities)
}

edge_table <- function(graph, membership = NULL, original_membership = membership) {
  if (!igraph::ecount(graph)) {
    return(data.table::data.table(
      From = character(), To = character(), Association = numeric(), Weight = numeric(),
      Sign = character(), FromModule = character(), ToModule = character(), WithinModule = logical()
    ))
  }
  endpoints <- igraph::ends(graph, igraph::E(graph), names = TRUE)
  out <- data.table::data.table(
    From = endpoints[, 1L],
    To = endpoints[, 2L],
    Association = igraph::E(graph)$association,
    Weight = igraph::E(graph)$weight,
    Sign = igraph::E(graph)$sign
  )
  if (!is.null(membership)) {
    out[, FromModule := membership[From]]
    out[, ToModule := membership[To]]
    out[, FromOriginalModule := original_membership[From]]
    out[, ToOriginalModule := original_membership[To]]
    out[, WithinModule := FromModule == ToModule & FromModule != "Unassigned"]
  } else {
    out[, `:=`(FromModule = NA_character_, ToModule = NA_character_, WithinModule = NA)]
  }
  out[]
}

node_and_module_tables <- function(graph, membership, abundance, original_membership = membership) {
  species <- igraph::V(graph)$name
  nodes <- data.table::data.table(
    Species = species,
    Module = unname(membership[species]),
    OriginalModule = unname(original_membership[species]),
    MeanAbundance = igraph::V(graph)$mean_abundance,
    Prevalence = igraph::V(graph)$prevalence,
    Degree = igraph::V(graph)$degree,
    DegreeNormalized = igraph::V(graph)$degree_normalized,
    Betweenness = igraph::V(graph)$betweenness,
    Eigenvector = igraph::V(graph)$eigenvector
  )
  nodes[, WithinModuleDegree := vapply(
    Species,
    function(species_id) {
      neighbors <- names(igraph::neighbors(graph, species_id))
      sum(original_membership[neighbors] == original_membership[[species_id]])
    },
    integer(1L)
  )]
  nodes[, Hub := WithinModuleDegree == max(WithinModuleDegree), by = OriginalModule]
  nodes[Module == "Unassigned", Hub := FALSE]
  edges <- edge_table(graph, membership, original_membership)
  internal <- edges[WithinModule == TRUE, .(
    InternalEdges = .N,
    PositiveEdges = sum(Sign == "positive"),
    NegativeEdges = sum(Sign == "negative"),
    PositiveStrength = sum(Weight[Sign == "positive"]),
    NegativeStrength = sum(Weight[Sign == "negative"])
  ), by = .(Module = FromModule)]
  modules <- nodes[, .(
    SpeciesCount = .N,
    MeanRelativeAbundance = sum(MeanAbundance),
    MeanSpeciesPrevalence = mean(Prevalence),
    HubSpecies = paste(Species[Hub], collapse = ";"),
    OriginalCommunityCount = data.table::uniqueN(OriginalModule)
  ), by = Module]
  modules <- merge(modules, internal, by = "Module", all.x = TRUE)
  count_columns <- c("InternalEdges", "PositiveEdges", "NegativeEdges", "PositiveStrength", "NegativeStrength")
  for (column in count_columns) data.table::set(modules, which(is.na(modules[[column]])), column, 0)
  modules[, PossibleInternalEdges := SpeciesCount * (SpeciesCount - 1) / 2]
  modules[, InternalEdgeDensity := data.table::fifelse(PossibleInternalEdges > 0, InternalEdges / PossibleInternalEdges, 0)]
  modules[, NormalizedInternalConnectivity := data.table::fifelse(
    PossibleInternalEdges > 0, (PositiveStrength + NegativeStrength) / PossibleInternalEdges, 0
  )]
  modules[, NegativeEdgeFraction := data.table::fifelse(InternalEdges > 0, NegativeEdges / InternalEdges, NA_real_)]
  modules[, EligibleForInference := Module != "Unassigned" & SpeciesCount >= 4L]
  data.table::setorder(modules, Module)
  list(nodes = nodes, modules = modules, edges = edges)
}

modularity_null_test <- function(graph, observed_modularity, n_perm, seed) {
  if (n_perm < 1L || igraph::ecount(graph) == 0L) {
    return(list(observed = observed_modularity, null = numeric(), p_value = NA_real_))
  }
  null <- numeric(n_perm)
  n_rewire <- max(100L, 10L * igraph::ecount(graph))
  for (i in seq_len(n_perm)) {
    set.seed(seed + i)
    rewired <- igraph::rewire(graph, with = igraph::keeping_degseq(niter = n_rewire, loops = FALSE))
    communities <- igraph::cluster_leiden(
      rewired,
      objective_function = "modularity",
      weights = igraph::E(rewired)$weight,
      resolution = 1,
      n_iterations = -1L
    )
    null[[i]] <- igraph::modularity(
      rewired,
      membership = igraph::membership(communities),
      weights = igraph::E(rewired)$weight
    )
  }
  list(
    observed = observed_modularity,
    null = null,
    p_value = (1 + sum(null >= observed_modularity)) / (n_perm + 1)
  )
}

apply_module_eligibility <- function(result, module_table, alpha = 0.05) {
  result <- data.table::copy(data.table::as.data.table(result))
  eligibility <- module_table[, .(Feature = Module, EligibleForInference)]
  result[, Q_Value := NULL]
  result <- merge(result, eligibility, by = "Feature", all.x = TRUE)
  result[, Q_Value := NA_real_]
  result[EligibleForInference == TRUE, Q_Value := stats::p.adjust(P_Value, method = "BH")]
  result[, Association := mapply(association_direction, Beta, Q_Value, MoreArgs = list(alpha = alpha))]
  data.table::setorder(result, Feature)
  result[]
}

calculate_module_scores <- function(abundance, membership, node_table) {
  primary <- module_clr_scores(abundance, membership)
  species_clr <- clr_transform(abundance)
  if (!identical(dim(species_clr), dim(abundance)) ||
      !identical(dimnames(species_clr), dimnames(abundance))) {
    stop("Species CLR dimensions or dimnames differ from the prevalence-filtered abundance matrix")
  }
  hubs <- node_table[Hub == TRUE & Module != "Unassigned"][order(Module, -WithinModuleDegree, -Degree), .SD[1L], by = Module]
  hub_species <- stats::setNames(hubs$Species, hubs$Module)
  eig <- module_eigenscores(species_clr, membership, hub_species)
  if (!identical(rownames(primary), rownames(eig$scores))) {
    stop("Module CLR and PC1 scores do not contain exactly the same samples in the same order")
  }
  explained <- summarize_score_concordance(primary, eig$scores, eig)
  explained[, OrientationHub := unname(hub_species[Module])]
  list(
    module_clr = primary,
    species_clr = species_clr,
    eigenscore = eig$scores,
    eigenloadings = eig$loadings,
    eigenscore_summary = explained
  )
}

run_module_associations <- function(scores, metadata, module_table) {
  primary <- apply_module_eligibility(
    fit_limma_association(scores$module_clr, metadata, include_clinical_group = FALSE),
    module_table
  )
  primary[, ScoreType := "Module_abundance_CLR"]
  primary_sensitivity <- apply_module_eligibility(
    fit_limma_association(scores$module_clr, metadata, include_clinical_group = TRUE),
    module_table
  )
  primary_sensitivity[, ScoreType := "Module_abundance_CLR"]
  eig <- apply_module_eligibility(
    fit_limma_association(scores$eigenscore, metadata, include_clinical_group = FALSE),
    module_table
  )
  eig[, ScoreType := "Module_eigenscore_PC1"]
  eig_sensitivity <- apply_module_eligibility(
    fit_limma_association(scores$eigenscore, metadata, include_clinical_group = TRUE),
    module_table
  )
  eig_sensitivity[, ScoreType := "Module_eigenscore_PC1"]
  list(
    primary = data.table::rbindlist(list(primary, eig), use.names = TRUE),
    sensitivity = data.table::rbindlist(list(primary_sensitivity, eig_sensitivity), use.names = TRUE)
  )
}

aggregate_humann_by_module <- function(pathway_path, functional_samples, metadata, membership, config) {
  pathway <- data.table::fread(pathway_path, sep = "\t", check.names = FALSE)
  annotation_columns <- c("PathwayID", "Pathway", "Genus", "Species")
  missing_samples <- setdiff(functional_samples, names(pathway))
  if (length(missing_samples)) stop("HUMAnN3 data is missing expected samples: ", paste(missing_samples, collapse = ", "))
  pathway[, Module := unname(membership[Species])]
  pathway <- pathway[!is.na(Module) & Module != "Unassigned"]
  if (!nrow(pathway)) stop("No HUMAnN3 species matched the network species")
  values <- as.matrix(pathway[, ..functional_samples])
  storage.mode(values) <- "double"
  if (any(!is.finite(values)) || any(values < 0)) stop("HUMAnN3 abundance contains invalid values")
  pathway[, MeanContribution := rowMeans(values)]

  module_sizes <- data.table::data.table(Species = names(membership), Module = unname(membership))[
    Module != "Unassigned", .(ModuleSpecies = .N), by = Module
  ]
  integrated_rows <- which(pathway$PathwayID != "UNINTEGRATED" & nzchar(pathway$PathwayID))
  integrated <- pathway[integrated_rows]
  integrated_values <- values[integrated_rows, , drop = FALSE]
  mapped_species <- integrated[, unique(Species)]
  coverage <- integrated[, .(MappedFunctionalSpecies = data.table::uniqueN(Species)), by = Module]
  coverage <- merge(module_sizes, coverage, by = "Module", all.x = TRUE)
  coverage[is.na(MappedFunctionalSpecies), MappedFunctionalSpecies := 0L]
  coverage[, FunctionalCoverage := MappedFunctionalSpecies / ModuleSpecies]

  integrated[, Feature := paste(Module, PathwayID, sep = "||")]
  aggregate_matrix <- rowsum(integrated_values, group = integrated$Feature, reorder = FALSE)
  contribution <- t(aggregate_matrix)
  rownames(contribution) <- functional_samples
  feature_annotation <- unique(integrated[, .(Feature, Module, PathwayID, Pathway)])
  if (anyDuplicated(feature_annotation$Feature)) {
    feature_annotation <- feature_annotation[, .(Pathway = Pathway[1L]), by = .(Feature, Module, PathwayID)]
  }
  prevalence <- colMeans(contribution > 0)
  tested_features <- names(prevalence)[prevalence >= config$functional_prevalence_threshold]
  contribution_tested <- contribution[, tested_features, drop = FALSE]
  positive_values <- contribution_tested[contribution_tested > 0]
  if (!length(positive_values)) stop("No module-pathway contribution passed the prevalence filter")
  pseudocount <- min(positive_values) / 2
  log_contribution <- log2(contribution_tested + pseudocount)

  primary <- fit_limma_association(log_contribution, metadata, include_clinical_group = FALSE)
  sensitivity <- fit_limma_association(log_contribution, metadata, include_clinical_group = TRUE)
  primary <- merge(primary, feature_annotation, by = "Feature", all.x = TRUE)
  sensitivity <- merge(sensitivity, feature_annotation, by = "Feature", all.x = TRUE)
  primary[, DetectionPrevalence := prevalence[Feature]]
  sensitivity[, DetectionPrevalence := prevalence[Feature]]
  primary[, FoldChangeApprox := 2^Beta]
  sensitivity[, FoldChangeApprox := 2^Beta]

  contributor <- integrated[, .(
    MeanContribution = sum(MeanContribution)
  ), by = .(Feature, Module, PathwayID, Pathway, Species)]
  contributor[, TotalFeatureContribution := sum(MeanContribution), by = Feature]
  contributor[, MeanContributionFraction := data.table::fifelse(
    TotalFeatureContribution > 0, MeanContribution / TotalFeatureContribution, 0
  )]
  data.table::setorder(contributor, Feature, -MeanContribution)
  contributor_summary <- contributor[, .(
    ContributingSpeciesCount = .N,
    ContributingSpecies = paste(Species, collapse = ";"),
    LeadingSpecies = Species[1L],
    LeadingSpeciesFraction = MeanContributionFraction[1L]
  ), by = .(Feature, Module, PathwayID, Pathway)]
  primary <- merge(primary, contributor_summary, by = c("Feature", "Module", "PathwayID", "Pathway"), all.x = TRUE)
  sensitivity <- merge(sensitivity, contributor_summary, by = c("Feature", "Module", "PathwayID", "Pathway"), all.x = TRUE)
  primary <- add_within_module_fdr(primary)
  sensitivity <- add_within_module_fdr(sensitivity)

  unintegrated_rows <- which(pathway$PathwayID == "UNINTEGRATED")
  if (length(unintegrated_rows)) {
    unintegrated_matrix <- t(rowsum(values[unintegrated_rows, , drop = FALSE], group = pathway$Module[unintegrated_rows], reorder = FALSE))
    rownames(unintegrated_matrix) <- functional_samples
  } else {
    unintegrated_matrix <- matrix(numeric(), nrow = length(functional_samples), ncol = 0L, dimnames = list(functional_samples, character()))
  }

  list(
    contribution = contribution,
    tested_contribution = contribution_tested,
    log_tested_contribution = log_contribution,
    feature_annotation = feature_annotation,
    prevalence = data.table::data.table(Feature = names(prevalence), DetectionPrevalence = as.numeric(prevalence)),
    primary_association = primary,
    sensitivity_association = sensitivity,
    contributors = contributor,
    contributor_summary = contributor_summary,
    module_coverage = coverage,
    unintegrated = unintegrated_matrix,
    pseudocount = pseudocount,
    integrated = integrated[, c(annotation_columns, "Module", "MeanContribution"), with = FALSE],
    mapped_species = mapped_species
  )
}

aggregate_humann_ec_by_module <- function(ec_path, functional_samples, metadata, membership, config) {
  ec_table <- data.table::fread(ec_path, sep = "\t", check.names = FALSE)
  feature_column <- "# Gene Family"
  missing_samples <- setdiff(functional_samples, names(ec_table))
  if (length(missing_samples)) stop("HUMAnN EC data is missing expected samples: ", paste(missing_samples, collapse = ", "))
  parsed <- parse_level4ec_feature(ec_table[[feature_column]])
  ec_table[, `:=`(EC = parsed$EC, Species = parsed$Species, EligibleEC = parsed$Eligible)]
  ec_table[, Module := unname(membership[Species])]
  ec_table <- ec_table[EligibleEC == TRUE & !is.na(Module) & Module != "Unassigned"]
  if (!nrow(ec_table)) stop("No stratified EC rows matched inferential network modules")

  values <- as.matrix(ec_table[, ..functional_samples])
  storage.mode(values) <- "double"
  if (any(!is.finite(values)) || any(values < 0)) stop("HUMAnN EC abundance contains invalid values")
  ec_table[, MeanContribution := rowMeans(values)]
  ec_table[, Feature := paste(Module, EC, sep = "||")]
  aggregate_matrix <- rowsum(values, group = ec_table$Feature, reorder = FALSE)
  contribution <- t(aggregate_matrix)
  rownames(contribution) <- functional_samples
  annotation <- unique(ec_table[, .(Feature, Module, EC)])
  prevalence <- colMeans(contribution > 0)
  tested_features <- names(prevalence)[prevalence >= config$functional_prevalence_threshold]
  contribution_tested <- contribution[, tested_features, drop = FALSE]
  positive_values <- contribution_tested[contribution_tested > 0]
  if (!length(positive_values)) stop("No module-EC contribution passed the prevalence filter")
  pseudocount <- min(positive_values) / 2
  log_contribution <- log2(contribution_tested + pseudocount)

  primary <- merge(
    fit_limma_association(log_contribution, metadata, include_clinical_group = FALSE),
    annotation, by = "Feature", all.x = TRUE
  )
  sensitivity <- merge(
    fit_limma_association(log_contribution, metadata, include_clinical_group = TRUE),
    annotation, by = "Feature", all.x = TRUE
  )
  primary[, `:=`(DetectionPrevalence = prevalence[Feature], FoldChangeApprox = 2^Beta)]
  sensitivity[, `:=`(DetectionPrevalence = prevalence[Feature], FoldChangeApprox = 2^Beta)]

  contributors <- ec_table[, .(MeanContribution = sum(MeanContribution)), by = .(Feature, Module, EC, Species)]
  contributors[, TotalFeatureContribution := sum(MeanContribution), by = Feature]
  contributors[, MeanContributionFraction := data.table::fifelse(
    TotalFeatureContribution > 0, MeanContribution / TotalFeatureContribution, 0
  )]
  data.table::setorder(contributors, Feature, -MeanContribution)
  contributor_summary <- contributors[, .(
    ContributingSpeciesCount = .N,
    ContributingSpecies = paste(Species, collapse = ";"),
    LeadingSpecies = Species[1L],
    LeadingSpeciesFraction = MeanContributionFraction[1L]
  ), by = .(Feature, Module, EC)]
  primary <- add_within_module_fdr(merge(primary, contributor_summary, by = c("Feature", "Module", "EC"), all.x = TRUE))
  sensitivity <- add_within_module_fdr(merge(sensitivity, contributor_summary, by = c("Feature", "Module", "EC"), all.x = TRUE))

  module_sizes <- data.table::data.table(Species = names(membership), Module = unname(membership))[
    Module != "Unassigned", .(ModuleSpecies = .N), by = Module
  ]
  coverage <- ec_table[, .(MappedECSpecies = data.table::uniqueN(Species)), by = Module]
  coverage <- merge(module_sizes, coverage, by = "Module", all.x = TRUE)
  coverage[is.na(MappedECSpecies), MappedECSpecies := 0L]
  coverage[, ECCoverage := MappedECSpecies / ModuleSpecies]

  list(
    contribution = contribution,
    tested_contribution = contribution_tested,
    log_tested_contribution = log_contribution,
    primary_association = primary,
    sensitivity_association = sensitivity,
    contributors = contributors,
    contributor_summary = contributor_summary,
    module_coverage = coverage,
    prevalence = data.table::data.table(Feature = names(prevalence), DetectionPrevalence = as.numeric(prevalence)),
    pseudocount = pseudocount
  )
}

select_function_features <- function(association, modules, n_fallback = 10L) {
  association <- data.table::as.data.table(association)[Module %in% modules]
  association[, SelectedReason := data.table::fifelse(Q_WithinModule < 0.05, "Within_module_FDR_lt_0.05", "")]
  data.table::rbindlist(lapply(split(association, association$Module), function(x) {
    significant <- x[Q_WithinModule < 0.05]
    if (nrow(significant)) return(significant)
    out <- x[order(P_Value)][seq_len(min(n_fallback, .N))]
    out[, SelectedReason := "Top_nominal_association_fallback"]
    out
  }), use.names = TRUE, fill = TRUE)
}

build_pathway_ec_species_links <- function(pathway, ec, significant_modules) {
  if (!length(significant_modules)) return(data.table::data.table())
  selected_pathways <- select_function_features(pathway$primary_association, significant_modules, 10L)
  selected_ec <- select_function_features(ec$primary_association, significant_modules, 20L)
  pathway_species <- pathway$contributors[Feature %in% selected_pathways$Feature, .(
    Module, PathwayFeature = Feature, PathwayID, Pathway, Species,
    PathwaySpeciesFraction = MeanContributionFraction
  )]
  ec_species <- ec$contributors[Feature %in% selected_ec$Feature, .(
    Module, ECFeature = Feature, EC, Species, ECSpeciesFraction = MeanContributionFraction
  )]
  links <- merge(pathway_species, ec_species, by = c("Module", "Species"), allow.cartesian = TRUE)
  if (!nrow(links)) return(data.table::data.table())
  links <- links[, .(
    SharedContributingSpecies = paste(sort(unique(Species)), collapse = ";"),
    SharedSpeciesCount = data.table::uniqueN(Species),
    MaxPathwaySpeciesFraction = max(PathwaySpeciesFraction),
    MaxECSpeciesFraction = max(ECSpeciesFraction)
  ), by = .(Module, PathwayFeature, PathwayID, Pathway, ECFeature, EC)]
  common_samples <- intersect(rownames(pathway$tested_contribution), rownames(ec$tested_contribution))
  links[, SampleSpearmanCorrelation := vapply(seq_len(.N), function(i) {
    p_feature <- PathwayFeature[[i]]
    e_feature <- ECFeature[[i]]
    if (!p_feature %in% colnames(pathway$tested_contribution) ||
        !e_feature %in% colnames(ec$tested_contribution)) return(NA_real_)
    suppressWarnings(stats::cor(
      pathway$tested_contribution[common_samples, p_feature],
      ec$tested_contribution[common_samples, e_feature], method = "spearman"
    ))
  }, numeric(1L))]
  links <- merge(
    links,
    selected_pathways[, .(PathwayFeature = Feature, PathwayBeta = Beta, PathwayP = P_Value,
                          PathwayQGlobal = Q_Global, PathwayQWithinModule = Q_WithinModule,
                          PathwaySelectionReason = SelectedReason)],
    by = "PathwayFeature", all.x = TRUE
  )
  links <- merge(
    links,
    selected_ec[, .(ECFeature = Feature, ECBeta = Beta, ECP = P_Value,
                    ECQGlobal = Q_Global, ECQWithinModule = Q_WithinModule,
                    ECSelectionReason = SelectedReason)],
    by = "ECFeature", all.x = TRUE
  )
  links[, `:=`(
    LinkEvidence = "Shared_contributing_species_plus_sample_correlation",
    CuratedBiochemicalMapping = FALSE
  )]
  links[, AbsoluteSampleCorrelation := abs(SampleSpearmanCorrelation)]
  data.table::setorder(links, Module, PathwayP, ECP, -AbsoluteSampleCorrelation)
  links[]
}

build_species_module_evidence <- function(nodes, scores, species_primary, species_sensitivity,
                                          module_primary, pathway, ec) {
  significant_modules <- unique(module_primary[is.finite(Q_Value) & Q_Value < 0.05, Feature])
  if (!length(significant_modules)) return(data.table::data.table())
  loadings <- data.table::melt(
    data.table::as.data.table(scores$eigenloadings, keep.rownames = "Species"),
    id.vars = "Species", variable.name = "Module", value.name = "PC1Loading", na.rm = TRUE
  )
  loadings[, AbsoluteLoadingRank := data.table::frank(-abs(PC1Loading), ties.method = "min"), by = Module]
  out <- merge(nodes[Module %in% significant_modules], loadings, by = c("Species", "Module"), all.x = TRUE)
  out <- merge(out, species_primary[, .(Species = Feature, SpeciesBeta = Beta, SpeciesP = P_Value,
                                        SpeciesQ = Q_Value, SpeciesAssociation = Association)], by = "Species", all.x = TRUE)
  out <- merge(out, species_sensitivity[, .(Species = Feature, SpeciesSensitivityBeta = Beta,
                                            SpeciesSensitivityP = P_Value, SpeciesSensitivityQ = Q_Value)],
               by = "Species", all.x = TRUE)
  module_wide <- data.table::dcast(
    module_primary[Feature %in% significant_modules], Feature ~ ScoreType,
    value.var = c("Beta", "P_Value", "Q_Value")
  )
  data.table::setnames(module_wide, "Feature", "Module")
  out <- merge(out, module_wide, by = "Module", all.x = TRUE)
  pathway_sig <- pathway$primary_association[Q_WithinModule < 0.05]
  pathway_evidence <- merge(
    pathway$contributors, pathway_sig[, .(Feature, Q_WithinModule)], by = "Feature"
  )[, .(SignificantPathwayCount = data.table::uniqueN(PathwayID),
        TopPathways = paste(head(unique(PathwayID[order(-MeanContributionFraction)]), 5L), collapse = ";")),
    by = .(Module, Species)]
  ec_sig <- ec$primary_association[Q_WithinModule < 0.05]
  ec_evidence <- merge(
    ec$contributors, ec_sig[, .(Feature, Q_WithinModule)], by = "Feature"
  )[, .(SignificantECCount = data.table::uniqueN(EC),
        TopECs = paste(head(unique(EC[order(-MeanContributionFraction)]), 5L), collapse = ";")),
    by = .(Module, Species)]
  out <- merge(out, pathway_evidence, by = c("Module", "Species"), all.x = TRUE)
  out <- merge(out, ec_evidence, by = c("Module", "Species"), all.x = TRUE)
  out[is.na(SignificantPathwayCount), SignificantPathwayCount := 0L]
  out[is.na(SignificantECCount), SignificantECCount := 0L]
  out[, SpeciesFDRSignificant := is.finite(SpeciesQ) & SpeciesQ < 0.05]
  out[, ModuleCLRSignificant := is.finite(get("Q_Value_Module_abundance_CLR")) &
        get("Q_Value_Module_abundance_CLR") < 0.05]
  out[, ModulePC1Significant := is.finite(get("Q_Value_Module_eigenscore_PC1")) &
        get("Q_Value_Module_eigenscore_PC1") < 0.05]
  out[, SpeciesModuleDirectionConcordant := SpeciesFDRSignificant & (
    (ModuleCLRSignificant & sign(SpeciesBeta) == sign(get("Beta_Module_abundance_CLR"))) |
    (ModulePC1Significant & sign(SpeciesBeta) == sign(get("Beta_Module_eigenscore_PC1")))
  )]
  out[, HasWithinModuleFunctionalEvidence := SignificantPathwayCount > 0L | SignificantECCount > 0L]
  out[, EvidenceLevel := data.table::fcase(
    SpeciesModuleDirectionConcordant & HasWithinModuleFunctionalEvidence, "Species_module_function",
    SpeciesFDRSignificant & HasWithinModuleFunctionalEvidence, "Species_and_function_with_module",
    SpeciesFDRSignificant, "Species_and_module",
    HasWithinModuleFunctionalEvidence, "Module_and_function",
    default = "Module_only"
  )]
  data.table::setorder(out, Module, AbsoluteLoadingRank, -Degree)
  out[]
}

cosine_matrix <- function(x) {
  x <- as.matrix(x)
  norms <- sqrt(rowSums(x^2))
  sim <- tcrossprod(x)
  denom <- outer(norms, norms)
  sim <- sim / denom
  sim[!is.finite(sim)] <- NA_real_
  diag(sim) <- 1
  sim
}

functional_similarity_analysis <- function(functional, pooled_edges, membership, config) {
  contributor <- functional$contributors
  profile_wide <- data.table::dcast(
    contributor,
    Species ~ PathwayID,
    value.var = "MeanContribution",
    fun.aggregate = sum,
    fill = 0
  )
  species <- profile_wide$Species
  profiles <- as.matrix(profile_wide[, setdiff(names(profile_wide), "Species"), with = FALSE])
  rownames(profiles) <- species
  similarity <- cosine_matrix(profiles)
  mapped_membership <- membership[species]

  pair_key <- function(a, b) paste(pmin(a, b), pmax(a, b), sep = "||")
  edge_pairs <- pooled_edges[From %in% species & To %in% species]
  edge_pairs[, PairKey := pair_key(From, To)]
  edge_pairs[, Similarity := similarity[cbind(From, To)]]
  pair_table <- edge_pairs[, .(Species1 = From, Species2 = To, Module1 = FromModule, Module2 = ToModule, PairType = Sign, Similarity)]

  unconnected <- data.table::rbindlist(lapply(sort(unique(mapped_membership)), function(module_id) {
    module_species <- names(mapped_membership)[mapped_membership == module_id]
    if (length(module_species) < 2L) return(NULL)
    pairs <- utils::combn(module_species, 2L)
    out <- data.table::data.table(
      Species1 = pairs[1L, ], Species2 = pairs[2L, ],
      Module1 = module_id, Module2 = module_id,
      PairType = "unconnected_within_module"
    )
    out[, PairKey := pair_key(Species1, Species2)]
    out <- out[!PairKey %in% edge_pairs$PairKey]
    out[, Similarity := similarity[cbind(Species1, Species2)]]
    out[, PairKey := NULL]
    out
  }), use.names = TRUE, fill = TRUE)
  pair_table <- data.table::rbindlist(list(pair_table, unconnected), use.names = TRUE, fill = TRUE)
  pair_summary <- pair_table[is.finite(Similarity), .(
    PairCount = .N,
    MeanSimilarity = mean(Similarity),
    MedianSimilarity = stats::median(Similarity)
  ), by = PairType]

  module_ids <- sort(unique(mapped_membership))
  module_coherence <- data.table::rbindlist(lapply(seq_along(module_ids), function(index) {
    module_id <- module_ids[[index]]
    module_species <- names(mapped_membership)[mapped_membership == module_id]
    n <- length(module_species)
    if (n < 2L) {
      return(data.table::data.table(Module = module_id, MappedSpecies = n, MeanCosine = NA_real_, P_Value = NA_real_))
    }
    observed <- mean(similarity[module_species, module_species][upper.tri(similarity[module_species, module_species])], na.rm = TRUE)
    set.seed(config$seed + 20000L + index)
    null <- replicate(config$functional_permutations, {
      sampled <- sample(species, n, replace = FALSE)
      mean(similarity[sampled, sampled][upper.tri(similarity[sampled, sampled])], na.rm = TRUE)
    })
    p_value <- (1 + sum(null >= observed, na.rm = TRUE)) / (sum(is.finite(null)) + 1)
    data.table::data.table(Module = module_id, MappedSpecies = n, MeanCosine = observed, P_Value = p_value)
  }))
  module_coherence[, Q_Value := stats::p.adjust(P_Value, method = "BH")]

  signed_edges <- edge_pairs[Sign %in% c("positive", "negative") & is.finite(Similarity)]
  observed_signed_difference <- if (all(c("positive", "negative") %in% signed_edges$Sign)) {
    mean(signed_edges[Sign == "negative", Similarity]) - mean(signed_edges[Sign == "positive", Similarity])
  } else NA_real_
  signed_null <- rep(NA_real_, config$functional_permutations)
  if (is.finite(observed_signed_difference)) {
    set.seed(config$seed + 30000L)
    signed_null <- replicate(config$functional_permutations, {
      shuffled <- stats::setNames(sample(species), species)
      values <- similarity[cbind(shuffled[signed_edges$From], shuffled[signed_edges$To])]
      mean(values[signed_edges$Sign == "negative"], na.rm = TRUE) -
        mean(values[signed_edges$Sign == "positive"], na.rm = TRUE)
    })
  }
  signed_test <- data.table::data.table(
    Contrast = "Negative_minus_positive_edge_cosine",
    ObservedDifference = observed_signed_difference,
    P_Value = perm_p_two_sided(observed_signed_difference, signed_null),
    PositivePairs = sum(signed_edges$Sign == "positive"),
    NegativePairs = sum(signed_edges$Sign == "negative")
  )
  list(
    profiles = profiles,
    similarity = similarity,
    pair_table = pair_table,
    pair_summary = pair_summary,
    module_coherence = module_coherence,
    signed_test = signed_test,
    signed_null = signed_null
  )
}

network_global_metrics <- function(graph, pooled_membership) {
  transitivity <- if (igraph::ecount(graph)) igraph::transitivity(graph, type = "global") else 0
  if (!is.finite(transitivity)) transitivity <- 0
  modularity_value <- if (igraph::ecount(graph)) {
    igraph::modularity(
      graph,
      membership = as.integer(factor(pooled_membership[igraph::V(graph)$name], levels = sort(unique(pooled_membership)))),
      weights = igraph::E(graph)$weight
    )
  } else 0
  c(
    Density = igraph::edge_density(graph, loops = FALSE),
    GlobalTransitivity = transitivity,
    GlobalEfficiency = global_efficiency_safe(graph),
    PositiveEdgeFraction = if (igraph::ecount(graph)) mean(igraph::E(graph)$sign == "positive") else 0,
    PooledPartitionModularity = modularity_value
  )
}

network_node_metrics <- function(graph) {
  data.table::data.table(
    Species = igraph::V(graph)$name,
    DegreeNormalized = igraph::V(graph)$degree_normalized,
    Betweenness = igraph::V(graph)$betweenness,
    Eigenvector = igraph::V(graph)$eigenvector
  )
}

compare_networks <- function(positive_graph, negative_graph, pooled_membership, original_membership = pooled_membership) {
  global_positive <- network_global_metrics(positive_graph, original_membership)
  global_negative <- network_global_metrics(negative_graph, original_membership)
  module_positive <- module_connectivity(positive_graph, pooled_membership)
  module_negative <- module_connectivity(negative_graph, pooled_membership)
  node_positive <- network_node_metrics(positive_graph)
  node_negative <- network_node_metrics(negative_graph)
  node <- merge(node_positive, node_negative, by = "Species", suffixes = c("_Positive", "_Negative"))
  metrics <- c("DegreeNormalized", "Betweenness", "Eigenvector")
  node_diff <- as.matrix(node[, paste0(metrics, "_Positive"), with = FALSE]) -
    as.matrix(node[, paste0(metrics, "_Negative"), with = FALSE])
  rownames(node_diff) <- node$Species
  colnames(node_diff) <- metrics
  list(
    global_positive = global_positive,
    global_negative = global_negative,
    global_difference = global_positive - global_negative,
    module_positive = module_positive,
    module_negative = module_negative,
    module_difference = module_positive - module_negative,
    node_positive = node_positive,
    node_negative = node_negative,
    node_difference = node_diff
  )
}

permutation_table <- function(observed, null_matrix, family) {
  common_features <- intersect(names(observed), colnames(null_matrix))
  if (!length(common_features)) stop("Observed and checkpoint permutation features do not overlap")
  observed <- observed[common_features]
  null_matrix <- null_matrix[, common_features, drop = FALSE]
  p_values <- vapply(seq_along(observed), function(index) {
    perm_p_two_sided(observed[[index]], null_matrix[, index])
  }, numeric(1L))
  data.table::data.table(
    Family = family,
    Feature = names(observed),
    Difference_PositiveMinusNegative = as.numeric(observed),
    P_Value = p_values,
    Q_Value = stats::p.adjust(p_values, method = "BH")
  )
}

run_label_permutations <- function(abundance, metadata, pooled_membership, original_membership,
                                   observed, config, checkpoint_dir) {
  n_perm <- config$network_permutations
  checkpoint_path <- file.path(
    checkpoint_dir,
    sprintf(
      "network_permutation_checkpoint_n%d_seed%d_samples%d_species%d.rds",
      n_perm, config$seed, nrow(abundance), ncol(abundance)
    )
  )
  signature <- list(
    n_perm = n_perm,
    seed = config$seed,
    species = colnames(abundance),
    group_counts = table(factor(
      metadata$SDC2_Category,
      levels = c("mSDC2(-)", "mSDC2(+)")
    )),
    network = unlist(config[c("spiec_method", "lambda_min_ratio", "nlambda", "stars_repetitions", "stars_threshold")])
  )
  records <- list()
  if (file.exists(checkpoint_path)) {
    checkpoint <- readRDS(checkpoint_path)
    if (!identical(checkpoint$signature, signature)) {
      stop("Existing network permutation checkpoint does not match the current configuration: ", checkpoint_path)
    }
    records <- checkpoint$records
    message("Resuming network permutations from ", length(records), " completed iterations")
  }
  remaining <- setdiff(seq_len(n_perm), seq_along(records))
  if (length(remaining)) {
    old_plan <- future::plan()
    on.exit(future::plan(old_plan), add = TRUE)
    future::plan(future::multisession, workers = config$workers)
    options(future.globals.maxSize = max(getOption("future.globals.maxSize", 500 * 1024^2), 4 * 1024^3))
    chunks <- split(remaining, ceiling(seq_along(remaining) / config$permutation_chunk_size))
    for (chunk in chunks) {
      message("Network permutation iterations ", min(chunk), "-", max(chunk), " of ", n_perm)
      chunk_records <- future.apply::future_lapply(chunk, function(i) {
        set.seed(config$seed + 100000L + i)
        labels <- sample(metadata$SDC2_Category, replace = FALSE)
        positive_abundance <- abundance[labels == "mSDC2(+)", , drop = FALSE]
        negative_abundance <- abundance[labels == "mSDC2(-)", , drop = FALSE]
        positive_fit <- fit_spiec_graph(positive_abundance, config, config$seed + 200000L + i)
        negative_fit <- fit_spiec_graph(negative_abundance, config, config$seed + 300000L + i)
        comparison <- compare_networks(
          positive_fit$graph, negative_fit$graph, pooled_membership, original_membership
        )
        list(
          group_counts = c(Positive = nrow(positive_abundance), Negative = nrow(negative_abundance)),
          global = comparison$global_difference,
          module = comparison$module_difference,
          node = comparison$node_difference
        )
      }, future.seed = TRUE)
      records <- c(records, chunk_records)
      saveRDS(list(signature = signature, records = records), checkpoint_path)
    }
  }
  global_null <- do.call(rbind, lapply(records, `[[`, "global"))
  module_null <- do.call(rbind, lapply(records, `[[`, "module"))
  node_metrics <- colnames(observed$node_difference)
  node_null <- stats::setNames(lapply(node_metrics, function(metric) {
    do.call(rbind, lapply(records, function(record) record$node[, metric]))
  }), node_metrics)
  for (metric in node_metrics) colnames(node_null[[metric]]) <- rownames(observed$node_difference)

  global_results <- permutation_table(observed$global_difference, global_null, "Global_network")
  module_results <- permutation_table(observed$module_difference, module_null, "Module_connectivity")
  node_results <- data.table::rbindlist(lapply(node_metrics, function(metric) {
    tab <- permutation_table(observed$node_difference[, metric], node_null[[metric]], metric)
    data.table::setnames(tab, "Feature", "Species")
    tab
  }), use.names = TRUE)
  list(
    global_results = global_results,
    module_results = module_results,
    node_results = node_results,
    global_null = global_null,
    module_null = module_null,
    node_null = node_null,
    checkpoint_path = checkpoint_path
  )
}

run_bootstrap_module_stability <- function(abundance, reference_membership, config, checkpoint_dir) {
  n_boot <- config$bootstrap_repetitions
  checkpoint_path <- file.path(
    checkpoint_dir,
    sprintf(
      "module_bootstrap_checkpoint_n%d_seed%d_samples%d_species%d.rds",
      n_boot, config$seed, nrow(abundance), ncol(abundance)
    )
  )
  signature <- list(
    n_boot = n_boot, seed = config$seed, samples = rownames(abundance), species = colnames(abundance),
    network = unlist(config[c("spiec_method", "lambda_min_ratio", "nlambda", "stars_repetitions", "stars_threshold")])
  )
  records <- list()
  if (file.exists(checkpoint_path)) {
    checkpoint <- readRDS(checkpoint_path)
    if (!identical(checkpoint$signature, signature)) {
      stop("Existing bootstrap checkpoint does not match the current configuration: ", checkpoint_path)
    }
    records <- checkpoint$records
    message("Resuming module bootstrap from ", length(records), " completed iterations")
  }
  remaining <- setdiff(seq_len(n_boot), seq_along(records))
  if (length(remaining)) {
    old_plan <- future::plan()
    on.exit(future::plan(old_plan), add = TRUE)
    future::plan(future::multisession, workers = config$bootstrap_workers)
    options(future.globals.maxSize = max(getOption("future.globals.maxSize", 500 * 1024^2), 4 * 1024^3))
    chunks <- split(remaining, ceiling(seq_along(remaining) / config$bootstrap_chunk_size))
    for (chunk in chunks) {
      message("Module bootstrap iterations ", min(chunk), "-", max(chunk), " of ", n_boot)
      chunk_records <- future.apply::future_lapply(chunk, function(i) {
        set.seed(config$seed + 400000L + i)
        index <- sample.int(nrow(abundance), nrow(abundance), replace = TRUE)
        boot_abundance <- abundance[index, , drop = FALSE]
        rownames(boot_abundance) <- paste0("bootstrap_", i, "_", seq_len(nrow(boot_abundance)))
        tryCatch({
          fit <- fit_spiec_graph(boot_abundance, config, config$seed + 500000L + i)
          modules <- detect_association_modules(fit$graph)
          list(Success = TRUE, Membership = modules$membership, Error = NA_character_)
        }, error = function(e) {
          list(Success = FALSE, Membership = NULL, Error = conditionMessage(e))
        })
      }, future.seed = TRUE)
      records <- c(records, chunk_records)
      saveRDS(list(signature = signature, records = records), checkpoint_path)
    }
  }
  successful_indices <- which(vapply(records, `[[`, logical(1L), "Success"))
  successful <- lapply(records[successful_indices], `[[`, "Membership")
  if (!length(successful)) stop("All module bootstrap network fits failed")
  summary <- summarize_bootstrap_memberships(reference_membership, successful)
  summary$replicate_summary[, Replicate := successful_indices[Replicate]]
  summary$replicate_detail[, Replicate := successful_indices[Replicate]]
  summary$module_detail[, Replicate := successful_indices[Replicate]]
  summary$species_detail[, Replicate := successful_indices[Replicate]]
  failures <- data.table::data.table(
    Replicate = seq_along(records),
    Success = vapply(records, `[[`, logical(1L), "Success"),
    Error = vapply(records, function(x) x$Error %||% NA_character_, character(1L))
  )
  summary$fit_status <- failures
  summary$checkpoint_path <- checkpoint_path
  summary
}

save_matrix_tsv <- function(x, path, row_name = "Sequence_ID") {
  out <- data.table::as.data.table(x, keep.rownames = row_name)
  write_tsv(out, path)
}

run_analysis <- function(cli) {
  config <- make_config(cli$quick)
  project_dir <- preserve_cli_path(cli$project_dir)
  if (!dir.exists(project_dir)) {
    required_in_working_directory <- c(
      "NF_Cohort2.txt", "taxonomy_Species.txt",
      "pathabundance_relab3_stratified.tsv", "level4ec_relab_stratified.tsv"
    )
    if (all(file.exists(required_in_working_directory))) {
      project_dir <- "."
      message("Using the current working directory because the absolute project path is not representable in the active R locale")
    } else {
      stop("Project directory does not exist: ", project_dir)
    }
  }
  output_root <- preserve_cli_path(cli$output_root %||% project_dir)
  dirs <- create_output_dirs(output_root)
  check_packages("data.table")
  inputs <- read_and_validate_inputs(project_dir, dirs, config)

  config_table <- data.table::data.table(Parameter = names(unlist(config)), Value = as.character(unlist(config)))
  write_tsv(config_table, file.path(dirs$results[["01_qc"]], "analysis_parameters.tsv"))
  writeLines(capture.output(sessionInfo()), file.path(dirs$results[["01_qc"]], "session_info.txt"))
  if (cli$validate_only) {
    message("Validation complete: ", nrow(inputs$abundance), " taxonomy samples; ",
            length(inputs$functional_samples), " functional samples; ",
            ncol(inputs$abundance), " species retained at prevalence >= ", config$prevalence_threshold)
    return(invisible(inputs))
  }

  check_packages(required_analysis_packages())
  message("Fitting pooled SPIEC-EASI network")
  pooled_fit <- fit_spiec_graph(inputs$abundance, config, config$seed)
  pooled_modules <- detect_association_modules(pooled_fit$graph)
  pooled_graph <- pooled_modules$graph
  original_membership <- pooled_modules$membership
  membership <- collapse_small_modules(original_membership, config$minimum_module_size)
  igraph::V(pooled_graph)$original_module <- original_membership[igraph::V(pooled_graph)$name]
  igraph::V(pooled_graph)$module <- membership[igraph::V(pooled_graph)$name]
  pooled_tables <- node_and_module_tables(
    pooled_graph, membership, inputs$abundance, original_membership = original_membership
  )
  modularity_test <- modularity_null_test(
    pooled_graph, pooled_modules$modularity, config$modularity_permutations, config$seed + 10000L
  )
  module_test_table <- data.table::data.table(
    ObservedModularity = modularity_test$observed,
    Permutations = length(modularity_test$null),
    P_Value = modularity_test$p_value
  )
  write_tsv(pooled_tables$nodes, file.path(dirs$results[["02_pooled_network"]], "pooled_network_nodes.tsv"))
  write_tsv(pooled_tables$edges, file.path(dirs$results[["02_pooled_network"]], "pooled_network_edges.tsv"))
  write_tsv(pooled_tables$modules, file.path(dirs$results[["03_modules"]], "module_summary.tsv"))
  write_tsv(module_test_table, file.path(dirs$results[["03_modules"]], "module_modularity_permutation.tsv"))
  write_tsv(data.table::data.table(NullModularity = modularity_test$null), file.path(dirs$results[["03_modules"]], "module_modularity_null.tsv"))
  saveRDS(pooled_fit$model, file.path(dirs$results[["02_pooled_network"]], "pooled_spieceasi_model.rds"))
  saveRDS(pooled_graph, file.path(dirs$results[["02_pooled_network"]], "pooled_signed_graph.rds"))

  message("Calculating module scores and associations")
  scores <- calculate_module_scores(inputs$abundance, membership, pooled_tables$nodes)
  if (nrow(scores$module_clr) != nrow(inputs$abundance) || nrow(scores$eigenscore) != nrow(inputs$abundance)) {
    stop("CLR or PC1 scoring changed the sample count")
  }
  expected_loading_count <- sum(membership != "Unassigned")
  observed_loading_count <- sum(is.finite(scores$eigenloadings))
  if (observed_loading_count != expected_loading_count) {
    stop("PC1 loading output does not contain every species from every inferential module")
  }
  module_associations <- run_module_associations(scores, inputs$metadata, pooled_tables$modules)
  species_primary <- fit_limma_association(scores$species_clr, inputs$metadata, include_clinical_group = FALSE)
  species_sensitivity <- fit_limma_association(scores$species_clr, inputs$metadata, include_clinical_group = TRUE)
  write_tsv(module_associations$primary, file.path(dirs$results[["04_module_association"]], "module_association_primary.tsv"))
  write_tsv(module_associations$sensitivity, file.path(dirs$results[["04_module_association"]], "module_association_clinical_group_sensitivity.tsv"))
  write_tsv(scores$eigenscore_summary, file.path(dirs$results[["04_module_association"]], "module_eigenscore_summary.tsv"))
  save_matrix_tsv(scores$module_clr, file.path(dirs$results[["04_module_association"]], "module_abundance_clr_scores.tsv"))
  save_matrix_tsv(scores$eigenscore, file.path(dirs$results[["04_module_association"]], "module_eigenscores.tsv"))
  save_matrix_tsv(scores$eigenloadings, file.path(dirs$results[["04_module_association"]], "module_eigenloadings.tsv"), row_name = "Species")
  write_tsv(species_primary, file.path(dirs$results[["04_module_association"]], "species_association_primary.tsv"))
  write_tsv(species_sensitivity, file.path(dirs$results[["04_module_association"]], "species_association_clinical_group_sensitivity.tsv"))
  loading_long <- data.table::melt(
    data.table::as.data.table(scores$eigenloadings, keep.rownames = "Species"),
    id.vars = "Species", variable.name = "Module", value.name = "PC1Loading", na.rm = TRUE
  )
  loading_centrality <- merge(
    pooled_tables$nodes[Module != "Unassigned"], loading_long,
    by = c("Species", "Module"), all.x = TRUE
  )
  loading_centrality[, AbsoluteLoadingRank := data.table::frank(-abs(PC1Loading), ties.method = "min"), by = Module]
  write_tsv(loading_centrality, file.path(dirs$results[["04_module_association"]], "module_species_loading_centrality.tsv"))

  bootstrap_stability <- NULL
  if (!cli$skip_bootstrap) {
    message("Running sample bootstrap for module stability")
    bootstrap_stability <- run_bootstrap_module_stability(
      inputs$abundance, membership, config, dirs$results[["07_module_stability"]]
    )
    write_tsv(bootstrap_stability$fit_status, file.path(dirs$results[["07_module_stability"]], "bootstrap_fit_status.tsv"))
    write_tsv(bootstrap_stability$replicate_summary, file.path(dirs$results[["07_module_stability"]], "bootstrap_partition_ari.tsv"))
    write_tsv(bootstrap_stability$module_detail, file.path(dirs$results[["07_module_stability"]], "bootstrap_module_detail.tsv"))
    write_tsv(bootstrap_stability$module_summary, file.path(dirs$results[["07_module_stability"]], "bootstrap_module_summary.tsv"))
    write_tsv(bootstrap_stability$species_summary, file.path(dirs$results[["07_module_stability"]], "bootstrap_species_membership_stability.tsv"))
  }

  message("Aggregating HUMAnN3 module-pathway contributions")
  functional <- aggregate_humann_by_module(
    inputs$pathway_path, inputs$functional_samples, inputs$metadata_function, membership, config
  )
  write_tsv(functional$module_coverage, file.path(dirs$results[["05_module_function"]], "module_functional_coverage.tsv"))
  write_tsv(functional$primary_association, file.path(dirs$results[["05_module_function"]], "module_pathway_association_primary.tsv"))
  write_tsv(functional$sensitivity_association, file.path(dirs$results[["05_module_function"]], "module_pathway_association_clinical_group_sensitivity.tsv"))
  write_tsv(functional$contributor_summary, file.path(dirs$results[["05_module_function"]], "module_pathway_contributor_summary.tsv"))
  write_tsv(functional$contributors, file.path(dirs$results[["05_module_function"]], "module_pathway_species_contributions.tsv"))
  save_matrix_tsv(functional$tested_contribution, file.path(dirs$results[["05_module_function"]], "module_pathway_contribution_matrix.tsv"))
  save_matrix_tsv(functional$unintegrated, file.path(dirs$results[["05_module_function"]], "module_unintegrated_qc.tsv"))

  message("Aggregating HUMAnN3 module-EC contributions")
  ec_functional <- aggregate_humann_ec_by_module(
    inputs$ec_path, inputs$functional_samples, inputs$metadata_function, membership, config
  )
  write_tsv(ec_functional$module_coverage, file.path(dirs$results[["05_module_function"]], "module_ec_coverage.tsv"))
  write_tsv(ec_functional$primary_association, file.path(dirs$results[["05_module_function"]], "module_ec_association_primary.tsv"))
  write_tsv(ec_functional$sensitivity_association, file.path(dirs$results[["05_module_function"]], "module_ec_association_clinical_group_sensitivity.tsv"))
  write_tsv(ec_functional$contributor_summary, file.path(dirs$results[["05_module_function"]], "module_ec_contributor_summary.tsv"))
  write_tsv(ec_functional$contributors, file.path(dirs$results[["05_module_function"]], "module_ec_species_contributions.tsv"))
  save_matrix_tsv(ec_functional$tested_contribution, file.path(dirs$results[["05_module_function"]], "module_ec_contribution_matrix.tsv"))

  significant_modules <- unique(module_associations$primary[is.finite(Q_Value) & Q_Value < 0.05, Feature])
  pathway_ec_links <- build_pathway_ec_species_links(functional, ec_functional, significant_modules)
  evidence_chain <- build_species_module_evidence(
    pooled_tables$nodes, scores, species_primary, species_sensitivity,
    module_associations$primary, functional, ec_functional
  )
  write_tsv(pathway_ec_links, file.path(dirs$results[["08_evidence_chain"]], "module_pathway_ec_species_links.tsv"))
  write_tsv(evidence_chain, file.path(dirs$results[["08_evidence_chain"]], "species_module_function_evidence_chain.tsv"))

  message("Testing functional similarity of positive and negative associations")
  functional_similarity <- functional_similarity_analysis(functional, pooled_tables$edges, membership, config)
  write_tsv(functional_similarity$pair_table, file.path(dirs$results[["05_module_function"]], "signed_edge_functional_similarity_pairs.tsv"))
  write_tsv(functional_similarity$pair_summary, file.path(dirs$results[["05_module_function"]], "signed_edge_functional_similarity_summary.tsv"))
  write_tsv(functional_similarity$module_coherence, file.path(dirs$results[["05_module_function"]], "module_functional_coherence_permutation.tsv"))
  write_tsv(functional_similarity$signed_test, file.path(dirs$results[["05_module_function"]], "negative_vs_positive_functional_similarity_permutation.tsv"))

  message("Fitting observed mSDC2 group networks")
  positive_abundance <- inputs$abundance[inputs$metadata$SDC2_Category == "mSDC2(+)", , drop = FALSE]
  negative_abundance <- inputs$abundance[inputs$metadata$SDC2_Category == "mSDC2(-)", , drop = FALSE]
  positive_fit <- fit_spiec_graph(positive_abundance, config, config$seed + 1L)
  negative_fit <- fit_spiec_graph(negative_abundance, config, config$seed + 2L)
  positive_tables <- node_and_module_tables(positive_fit$graph, membership, positive_abundance, original_membership)
  negative_tables <- node_and_module_tables(negative_fit$graph, membership, negative_abundance, original_membership)
  observed_comparison <- compare_networks(positive_fit$graph, negative_fit$graph, membership, original_membership)
  write_tsv(edge_table(positive_fit$graph, membership, original_membership), file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_positive_edges.tsv"))
  write_tsv(edge_table(negative_fit$graph, membership, original_membership), file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_negative_edges.tsv"))
  write_tsv(positive_tables$nodes, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_positive_nodes.tsv"))
  write_tsv(negative_tables$nodes, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_negative_nodes.tsv"))
  saveRDS(positive_fit$model, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_positive_spieceasi_model.rds"))
  saveRDS(negative_fit$model, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_negative_spieceasi_model.rds"))
  saveRDS(positive_fit$graph, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_positive_graph.rds"))
  saveRDS(negative_fit$graph, file.path(dirs$results[["06_group_network_comparison"]], "mSDC2_negative_graph.rds"))

  permutation_results <- NULL
  if (!cli$skip_network_permutations) {
    message("Running group-label network permutations; this is the longest step")
    permutation_results <- run_label_permutations(
      inputs$abundance, inputs$metadata, membership, original_membership,
      observed_comparison, config,
      dirs$results[["06_group_network_comparison"]]
    )
    write_tsv(permutation_results$global_results, file.path(dirs$results[["06_group_network_comparison"]], "global_network_permutation_results.tsv"))
    write_tsv(permutation_results$module_results, file.path(dirs$results[["06_group_network_comparison"]], "module_connectivity_permutation_results.tsv"))
    write_tsv(permutation_results$node_results, file.path(dirs$results[["06_group_network_comparison"]], "node_centrality_permutation_results.tsv"))
    saveRDS(
      permutation_results[c("global_null", "module_null", "node_null")],
      file.path(dirs$results[["06_group_network_comparison"]], "network_permutation_null_distributions.rds")
    )
  }

  results_bundle <- list(
    config = config,
    metadata = inputs$metadata,
    pooled_graph = pooled_graph,
    positive_graph = positive_fit$graph,
    negative_graph = negative_fit$graph,
    membership = membership,
    original_membership = original_membership,
    pooled_tables = pooled_tables,
    modularity_test = modularity_test,
    module_scores = scores,
    module_associations = module_associations,
    species_associations = list(primary = species_primary, sensitivity = species_sensitivity),
    bootstrap_stability = bootstrap_stability,
    functional = functional[c(
      "feature_annotation", "prevalence", "primary_association", "sensitivity_association",
      "contributors", "contributor_summary", "module_coverage", "pseudocount"
    )],
    ec_functional = ec_functional[c(
      "primary_association", "sensitivity_association", "contributors",
      "contributor_summary", "module_coverage", "prevalence", "pseudocount"
    )],
    pathway_ec_species_links = pathway_ec_links,
    evidence_chain = evidence_chain,
    functional_similarity = functional_similarity,
    observed_network_comparison = observed_comparison,
    permutation_results = permutation_results
  )
  saveRDS(results_bundle, file.path(dirs$results_root, "analysis_results.rds"), compress = "xz")
  writeLines(format(Sys.time(), "%Y-%m-%d %H:%M:%S"), file.path(dirs$results_root, "ANALYSIS_COMPLETE.txt"))
  message("Analysis complete. Results: ", dirs$results_root)
  invisible(results_bundle)
}

if (sys.nframe() == 0L && !interactive()) {
  run_analysis(parse_cli())
} else if (interactive() && identical(environment(), globalenv())) {
  run_analysis(NETWORK_RUN_CONFIG)
}
