#!/usr/bin/env Rscript
# MaAsLin 3 differential-abundance analysis; plotting is disabled for the code-only release.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(maaslin3)
  library(dplyr)
})

input_files <- c(
  abundance = file.path(PUBLIC_DATA_DIR, "taxonomy_species.txt"),
  metadata = file.path(PUBLIC_DATA_DIR, "metadata_filtered.txt")
)
assert_files_exist(input_files, "MaAsLin 3 input")
taxonomy <- read.delim(input_files[["abundance"]], row.names = 1, check.names = FALSE)
metadata <- read.delim(input_files[["metadata"]], check.names = FALSE)
if (!"Sample_ID" %in% names(metadata)) {
  metadata$Sample_ID <- rownames(metadata)
}
metadata$Sample_ID <- as.character(metadata$Sample_ID)
names(metadata) <- gsub(" ", "_", names(metadata))
metadata$Age[as.character(metadata$Age) == "NA"] <- NA
metadata$BMI[as.character(metadata$BMI) == "NA"] <- NA
metadata$Age <- suppressWarnings(as.numeric(as.character(metadata$Age)))
metadata$BMI <- suppressWarnings(as.numeric(as.character(metadata$BMI)))
metadata$Group <- as.character(metadata$Group)
metadata$Gender <- factor(metadata$Gender, levels = c("female", "male"))
metadata$Country <- factor(metadata$Country)
rownames(metadata) <- metadata$Sample_ID

common_samples <- intersect(metadata$Sample_ID, colnames(taxonomy))
if (!length(common_samples)) stop("No shared samples between MaAsLin 3 metadata and abundance.")
metadata <- metadata[common_samples, , drop = FALSE]
taxonomy <- taxonomy[, common_samples, drop = FALSE]
prevalence <- rowMeans(taxonomy > 0, na.rm = TRUE)
taxonomy_filtered <- taxonomy[prevalence > 0.025, , drop = FALSE]
abundance_samples_by_features <- as.data.frame(t(taxonomy_filtered), check.names = FALSE) / 100

run_maaslin_task <- function(target_group, output_name) {
  sample_ids <- metadata$Sample_ID[metadata$Group %in% c(GROUP_HC, target_group)]
  task_metadata <- metadata[match(sample_ids, metadata$Sample_ID), , drop = FALSE]
  task_data <- abundance_samples_by_features[sample_ids, , drop = FALSE]
  task_metadata$Group <- factor(task_metadata$Group, levels = c(GROUP_HC, target_group))
  task_metadata$Gender <- factor(task_metadata$Gender, levels = c("female", "male"))
  task_metadata$Age <- as.numeric(task_metadata$Age)
  task_metadata$BMI <- as.numeric(task_metadata$BMI)
  if (nrow(task_metadata) != nrow(task_data) || !identical(rownames(task_data), task_metadata$Sample_ID)) {
    stop("Sample order mismatch in MaAsLin 3 task: ", output_name)
  }
  out_dir <- file.path(RESULTS$maaslin3, output_name)
  ensure_dir(out_dir)
  maaslin3::maaslin3(
    input_data = task_data, input_metadata = task_metadata, output = out_dir,
    fixed_effects = c("Group", "Gender", "Age", "BMI"),
    random_effects = c("Country"), reference = c(GROUP_HC, "female"),
    min_abundance = 0, min_prevalence = 0.000001, min_variance = 0.001,
    normalization = "none", transform = "LOG", correction = "BH",
    standardize = TRUE, plot_summary_plot = FALSE, plot_associations = FALSE,
    max_pngs = 0, save_plots_rds = FALSE
  )
  invisible(out_dir)
}

run_maaslin_task(GROUP_AP, "AP_vs_HC")
run_maaslin_task(GROUP_CRC, "CRC_vs_HC")

writeLines(capture.output(sessionInfo()), file.path(RESULTS$maaslin3, "sessionInfo.txt"), useBytes = TRUE)
