#!/usr/bin/env Rscript
# Cohort-stratified LEfSe analysis for CRC and subgroup-adjusted LEfSe for AP.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(microeco)
  library(dplyr)
})

input_files <- c(
  metadata = file.path(PUBLIC_DATA_DIR, "metadata_filtered.txt"),
  taxonomy = file.path(PUBLIC_DATA_DIR, "taxonomy_species.txt")
)
assert_files_exist(input_files, "LEfSe input")
metadata <- read.delim(input_files[["metadata"]], row.names = 1, check.names = FALSE)
taxonomy <- read.delim(input_files[["taxonomy"]], row.names = 1, check.names = FALSE)
common_samples <- intersect(rownames(metadata), colnames(taxonomy))
if (!length(common_samples)) stop("No shared samples between LEfSe metadata and abundance matrix.")
metadata <- metadata[common_samples, , drop = FALSE]
taxonomy <- taxonomy[, common_samples, drop = FALSE]
prevalence <- rowMeans(taxonomy > 0, na.rm = TRUE)
taxonomy_filtered <- taxonomy[prevalence > 0.025, , drop = FALSE]
tax_table <- data.frame(Species = rownames(taxonomy_filtered),
                        row.names = rownames(taxonomy_filtered),
                        stringsAsFactors = FALSE)
dataset <- microtable$new(sample_table = metadata, otu_table = taxonomy_filtered,
                          tax_table = tax_table)
dataset$tidy_dataset()
dataset$cal_abund()
ensure_dir(RESULTS$lefse)

# CRC: run LEfSe independently in each cohort, then retain directionally recurrent taxa.
dataset_CRC <- dataset$clone()
dataset_CRC$sample_table <- subset(dataset_CRC$sample_table,
                                   Group %in% c(GROUP_HC, GROUP_CRC))
dataset_CRC$tidy_dataset()
cohorts <- sort(unique(dataset_CRC$sample_table$Cohort))
crc_results <- list()
for (cohort in cohorts) {
  cohort_dataset <- dataset_CRC$clone()
  cohort_dataset$sample_table <- subset(cohort_dataset$sample_table, Cohort == cohort)
  cohort_dataset$tidy_dataset()
  if (length(unique(cohort_dataset$sample_table$Group)) < 2L ||
      nrow(cohort_dataset$sample_table) < 10L) next
  cohort_dataset$cal_abund()
  fit <- tryCatch(
    trans_diff$new(dataset = cohort_dataset, method = "lefse", group = "Group",
                   alpha = 0.05, p_adjust_method = "fdr"),
    error = function(e) {
      message("LEfSe failed for cohort ", cohort, ": ", conditionMessage(e))
      NULL
    }
  )
  if (!is.null(fit) && !is.null(fit$res_diff) && nrow(fit$res_diff)) {
    fit$res_diff$Cohort <- cohort
    crc_results[[cohort]] <- fit$res_diff
  }
}
if (!length(crc_results)) stop("No CRC cohort produced LEfSe results.")
crc_detailed_results <- bind_rows(crc_results)
write.table(crc_detailed_results,
            file.path(RESULTS$lefse, "CRC_all_cohorts_LEfSe.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
crc_significant <- crc_detailed_results %>% filter(P.adj < 0.05, LDA > 2.5)
crc_recurrent <- crc_significant %>% group_by(Taxa, Group) %>%
  summarise(Cohort_Count = n_distinct(Cohort), .groups = "drop") %>%
  filter(Cohort_Count >= 3L) %>% rename(Species = Taxa) %>%
  arrange(desc(Cohort_Count))
write.table(crc_recurrent,
            file.path(RESULTS$lefse, "Robust_CRC_Species.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

# AP: global LEfSe with Country specified as the subgroup variable.
dataset_AP <- dataset$clone()
dataset_AP$sample_table <- subset(dataset_AP$sample_table,
                                  Group %in% c(GROUP_HC, GROUP_AP))
dataset_AP$tidy_dataset()
dataset_AP$cal_abund()
fit_AP <- trans_diff$new(
  dataset = dataset_AP, method = "lefse", group = "Group",
  lefse_subgroup = "Country", alpha = 0.05, p_adjust_method = "fdr",
  lda_cutoff = 2
)
ap_results <- fit_AP$res_diff
write.table(ap_results,
            file.path(RESULTS$lefse, "Adenoma_Subclass_LEfSe.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

writeLines(capture.output(sessionInfo()), file.path(RESULTS$lefse, "sessionInfo.txt"), useBytes = TRUE)
