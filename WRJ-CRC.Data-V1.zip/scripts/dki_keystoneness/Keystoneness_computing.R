library(ggplot2)
library(scales)
library(ggpubr)
library(gridExtra)
library(ggExtra)
library(dplyr)


## read the data 
# 读取映射表
mapping <- read.csv("HC/HC_Perturbation_Mapping.csv")
species_id = read.table(file = paste('HC/Species_id.csv',sep = ''), header = F, sep=",")
sample_id = read.table(file = paste('HC/Sample_id.csv',sep = ''), header = F, sep=",")
Ptrain = read.table(file = paste('HC/Ptrain.csv',sep = ''), header = F, sep=",")

## read the prediction of cNODE2
qtst = read.table(file = paste('HC/qtst.csv',sep = ''), header = F, sep=",")
qtrn = read.table(file = paste('HC/qtrn.csv',sep = ''), header = F, sep=",")

## calculate keystoneness
n <- nrow(qtst)
res_sample_id <- numeric(n)
res_species_id <- numeric(n)
res_keystoneness <- numeric(n)

for (i in 1:n){
  # predicted null composition
  q_i = qtrn[sample_id$V1[i],]
  q_i_null = q_i
  q_i_null[species_id$V1[i]] = 0
  q_i_null = q_i_null/sum(q_i_null)
  
  # impact to the community (保持您的原始公式)
  BC_pred=sum(abs(q_i_null-qtst[i,]))/sum(abs(q_i_null+qtst[i,]))
  
  p_is = Ptrain[species_id$V1[i],sample_id$V1[i]] 
  
  # structural keystoneness
  keystone_predicted = BC_pred*(1-p_is)
  
  res_sample_id[i] <- sample_id$V1[i]
  res_species_id[i]<- species_id$V1[i]
  res_keystoneness[i] <-keystone_predicted
}

results <- data.frame(SampleID = res_sample_id,
                      Species_ID = res_species_id,
                      Keystoness = res_keystoneness)

matched_results <- results %>%
  left_join(mapping, by = c("SampleID" = "sample_id", "Species_ID" = "species_id")) %>%
  select(SampleID, Species_ID, species_name, sample_name, Keystoness)

write.table(matched_results,'HC_keystoness_results.txt',sep = '\t',row.names = F)


