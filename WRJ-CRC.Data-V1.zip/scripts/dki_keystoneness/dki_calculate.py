import torch
import numpy as np
import sys, copy, math, time
import os
import random
import argparse
from torchdiffeq import odeint

parser = argparse.ArgumentParser(description='cnode')
parser.add_argument('--data-name', default=None, help='data name')
parser.add_argument('--epochs', type=int, default=2000, help='number of epochs to train')
args = parser.parse_args()
dataset = args.data_name

# 定义全局变量（与DKI.py完全一致）
batch_time = 100
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
t = torch.arange(0.0, batch_time, 0.01, device=device)

print(f"Using device: {device}")
if device.type == 'cuda':
    print(f"GPU: {torch.cuda.get_device_name(0)}")

def get_batch(ztrn, ptrn, mb_size):
    """获取批数据 - 与DKI.py完全一致"""
    indices = torch.randperm(ptrn.size(0))[:mb_size]
    batch_p = ztrn[indices]
    batch_q = ptrn[indices]
    batch_t = t[:batch_time]
    return batch_p, batch_q, batch_t

def loss_bc(p_i, q_i):
    """计算损失函数 - 与DKI.py完全一致"""
    return torch.sum(torch.abs(p_i - q_i)) / torch.sum(torch.abs(p_i + q_i))

def process_data(P):
    """处理数据 - 与DKI.py完全一致"""
    Z = P.copy()
    Z[Z > 0] = 1
    P = P / P.sum(axis=0)[np.newaxis, :]
    Z = Z / Z.sum(axis=0)[np.newaxis, :]
    
    P = P.astype(np.float32)
    Z = Z.astype(np.float32)

    P = torch.from_numpy(P.T).to(device)
    Z = torch.from_numpy(Z.T).to(device)
    return P, Z

class ODEFunc(torch.nn.Module):
    def __init__(self, input_dim):
        """初始化ODE函数 - 与DKI.py完全一致"""
        super(ODEFunc, self).__init__()
        self.input_dim = input_dim
        # 与DKI.py完全一致：两层线性层，无激活函数
        self.fcc1 = torch.nn.Linear(input_dim, input_dim)
        self.fcc2 = torch.nn.Linear(input_dim, input_dim)
        # 移除特殊初始化，使用默认初始化
        
    def forward(self, t, y):
        """前向传播 - 与DKI.py完全一致的计算逻辑"""
        # 处理输入维度
        if y.dim() == 1:
            y = y.unsqueeze(0)  # 转换为 (1, N)
        
        out = self.fcc1(y)
        out = self.fcc2(out)  # 无激活函数，与DKI.py一致
        
        # 计算f，与DKI.py完全一致
        # DKI.py中的计算：f = torch.matmul(torch.matmul(torch.ones(y.size(dim=1),1),y),torch.transpose(out,0,1))
        
        batch_size = y.size(0)
        N = y.size(1)
        
        dy_dt_list = []
        for i in range(batch_size):
            y_i = y[i].unsqueeze(0)  # (1, N)
            out_i = out[i].unsqueeze(0)  # (1, N)
            
            # 与DKI.py完全一致的计算
            ones_matrix = torch.ones(N, 1).to(y_i.device)  # (N, 1)
            intermediate = torch.matmul(ones_matrix, y_i)  # (N, 1) @ (1, N) -> (N, N)
            f = torch.matmul(intermediate, torch.transpose(out_i, 0, 1))  # (N, N) @ (N, 1) -> (N, 1)
            dy_dt_i = torch.mul(y_i, out_i - torch.transpose(f, 0, 1))  # (1, N)
            dy_dt_list.append(dy_dt_i)
        
        dy_dt = torch.cat(dy_dt_list, dim=0)  # (batch_size, N)
        return dy_dt

def train_reptile(max_epochs, mb, LR, ztrn, ptrn, ztst, ptst, zval, pval, zall, pall, input_dim):
    """训练模型 - 与DKI.py完全一致的训练逻辑"""
    loss_train = []
    loss_val = []
    
    # 初始化模型
    func = ODEFunc(input_dim).to(device)
    optimizer = torch.optim.Adam(func.parameters(), lr=LR)  # 移除weight_decay
    
    # 确保数据在正确的设备上
    ztrn = ztrn.to(device)
    ptrn = ptrn.to(device)
    zval = zval.to(device)
    pval = pval.to(device)
    zall = zall.to(device)
    pall = pall.to(device)
    ztst = ztst.to(device) if ztst is not None else None
    ptst = ptst.to(device) if ptst is not None else None
    
    print(f"Model input dimension: {input_dim}")
    print(f"Training data shape: {ztrn.shape}")
    print(f"Validation data shape: {zval.shape}")
    
    Loss_opt = float('inf')
    best_model_state = None
    batch_t = t[:batch_time]
    
    for e in range(max_epochs):
        func.train()
        optimizer.zero_grad()
        
        # 获取批数据
        batch_p, batch_q, _ = get_batch(ztrn, ptrn, mb)
        
        # 计算训练损失 - 与DKI.py完全一致
        total_loss = 0
        for i in range(mb):
            p_input = batch_p[i].unsqueeze(0)  # (1, N)
            q_target = batch_q[i].unsqueeze(0)  # (1, N)
            
            # 使用与DKI.py一致的ODE求解器设置
            try:
                # 尝试使用默认设置（与DKI.py一致）
                p_pred = odeint(func, p_input, batch_t)
                p_pred_final = p_pred[-1]
                total_loss += loss_bc(p_pred_final, q_target)
            except AssertionError as e:
                # 如果出现数值下溢，尝试调整求解器设置
                print(f"Epoch {e+1}: ODE求解器警告 - {e}")
                print("尝试调整求解器设置以继续训练...")
                
                # 使用更稳定的设置，但仅在必要时
                p_pred = odeint(func, p_input, batch_t, 
                               method='dopri5',
                               rtol=1e-6,
                               atol=1e-8,
                               options={'max_num_steps': 10000})
                p_pred_final = p_pred[-1]
                total_loss += loss_bc(p_pred_final, q_target)
        
        loss = total_loss / mb
        loss_train.append(loss.item())
        
        # 计算验证损失
        func.eval()
        with torch.no_grad():
            val_loss = 0
            val_count = 0
            
            # 分小批量进行验证以节省内存
            val_batch_size = min(10, zval.size(0))
            for start_idx in range(0, zval.size(0), val_batch_size):
                end_idx = min(start_idx + val_batch_size, zval.size(0))
                z_batch = zval[start_idx:end_idx]
                p_batch = pval[start_idx:end_idx]
                
                try:
                    # 使用默认设置
                    p_pred = odeint(func, z_batch, batch_t)
                    p_pred_final = p_pred[-1]
                    batch_val_loss = loss_bc(p_pred_final, p_batch)
                except AssertionError:
                    # 使用调整后的设置
                    p_pred = odeint(func, z_batch, batch_t,
                                   method='dopri5',
                                   rtol=1e-6,
                                   atol=1e-8,
                                   options={'max_num_steps': 10000})
                    p_pred_final = p_pred[-1]
                    batch_val_loss = loss_bc(p_pred_final, p_batch)
                
                val_loss += batch_val_loss.item() * (end_idx - start_idx)
                val_count += (end_idx - start_idx)
            
            val_loss /= val_count
            loss_val.append(val_loss)
            
            # 保存最佳模型
            if val_loss < Loss_opt:
                Loss_opt = val_loss
                best_model_state = copy.deepcopy(func.state_dict())
        
        # 反向传播 - 与DKI.py完全一致，无梯度裁剪
        func.train()
        loss.backward()
        optimizer.step()
        
        if (e + 1) % 100 == 0:
            print(f'Epoch [{e+1}/{max_epochs}], Train Loss: {loss.item():.4f}, Val Loss: {val_loss:.4f}')
    
    # 加载最佳模型
    if best_model_state is not None:
        func.load_state_dict(best_model_state)
    
    # 预测 - 分批次进行以节省内存
    func.eval()
    with torch.no_grad():
        # 测试集预测
        if ztst is not None:
            qtst_list = []
            batch_size = min(5, ztst.size(0))  # 更小的批次大小以避免内存问题
            for i in range(0, ztst.size(0), batch_size):
                end_idx = min(i + batch_size, ztst.size(0))
                z_batch = ztst[i:end_idx]
                
                try:
                    pred = odeint(func, z_batch, batch_t)
                except AssertionError:
                    # 如果失败，使用调整后的设置
                    pred = odeint(func, z_batch, batch_t,
                                 method='dopri5',
                                 rtol=1e-6,
                                 atol=1e-8,
                                 options={'max_num_steps': 10000})
                
                qtst_list.append(pred[-1].cpu().numpy())
            
            if len(qtst_list) > 0:
                qtst = np.vstack(qtst_list) if len(qtst_list) > 1 else qtst_list[0]
            else:
                qtst = np.array([])
        else:
            qtst = None
        
        # 全部训练数据预测
        qtrn_list = []
        batch_size = min(5, zall.size(0))
        for i in range(0, zall.size(0), batch_size):
            end_idx = min(i + batch_size, zall.size(0))
            z_batch = zall[i:end_idx]
            
            try:
                pred = odeint(func, z_batch, batch_t)
            except AssertionError:
                pred = odeint(func, z_batch, batch_t,
                             method='dopri5',
                             rtol=1e-6,
                             atol=1e-8,
                             options={'max_num_steps': 10000})
            
            qtrn_list.append(pred[-1].cpu().numpy())
        
        if len(qtrn_list) > 0:
            qtrn = np.vstack(qtrn_list) if len(qtrn_list) > 1 else qtrn_list[0]
        else:
            qtrn = np.array([])
    
    # 返回最后5个epoch的损失（与DKI.py一致）
    if len(loss_train) >= 5:
        last_train_losses = loss_train[-5:]
    else:
        last_train_losses = loss_train
    
    return last_train_losses, qtst, qtrn

if __name__ == "__main__":
    max_epochs = args.epochs
    LR = 0.01
    mb = 20  # 与DKI.py一致
    
    # 检查数据路径
    data_dir = '../data/' + str(dataset)
    if not os.path.exists(data_dir):
        print(f"Error: Data directory {data_dir} does not exist!")
        sys.exit(1)
    
    # 加载训练数据
    filepath_train = os.path.join(data_dir, 'Ptrain.csv')
    if not os.path.exists(filepath_train):
        print(f"Error: Training file {filepath_train} does not exist!")
        sys.exit(1)
    
    P = np.loadtxt(filepath_train, delimiter=',')
    print(f"Training data shape: {P.shape}")
    
    # 确保数据不是空的
    if P.size == 0:
        print("Error: Training data is empty!")
        sys.exit(1)
    
    # 获取数据维度
    if P.ndim == 1:
        P = P.reshape(1, -1)
    
    M, N = P.shape
    print(f"Features (M): {M}, Samples (N): {N}")
    
    # 划分验证集 - 与DKI.py完全一致：20%验证集
    number_of_cols = P.shape[1]
    random_indices = np.random.choice(number_of_cols, size=int(0.2*number_of_cols), replace=False)
    P_val = P[:, random_indices]
    P_train = P[:, np.setdiff1d(range(0, number_of_cols), random_indices)]
    
    # 处理数据
    ptrn, ztrn = process_data(P_train)
    pval, zval = process_data(P_val)
    pall, zall = process_data(P)
    
    print(f"Processed training data shape: {ptrn.shape}")
    print(f"Processed validation data shape: {pval.shape}")
    
    # 加载测试数据
    filepath_test = os.path.join(data_dir, 'Ztest.csv')
    if os.path.exists(filepath_test):
        P_test = np.loadtxt(filepath_test, delimiter=',')
        print(f"Test data shape: {P_test.shape}")
        
        if P_test.ndim == 1:
            P_test = P_test.reshape(1, -1)
        
        ptst, ztst = process_data(P_test)
        print(f"Processed test data shape: {ptst.shape}")
    else:
        print("Warning: Test file not found, using validation set as test")
        ptst, ztst = pval, zval
    
    # 获取输入维度（特征数）
    input_dim = M
    
    print(f'\nDataset: {dataset}')
    print(f'Input dimension: {input_dim}')
    print(f'Max Epochs: {max_epochs}')
    print('Training started...\n')
    
    # 设置随机种子以确保可重复性
    torch.manual_seed(20260123)
    np.random.seed(20260123)
    
    # 训练模型
    loss_train, qtst, qtrn = train_reptile(
        max_epochs, mb, LR, 
        ztrn, ptrn, ztst, ptst, 
        zval, pval, zall, pall, 
        input_dim
    )
    
    # 保存结果
    results_dir = '../results/' + str(dataset)
    os.makedirs(results_dir, exist_ok=True)
    
    # 保存loss记录
    loss_file_path = os.path.join(results_dir, 'loss_log.tsv')
    loss_array = np.array(loss_train).reshape(-1, 1)
    np.savetxt(loss_file_path, loss_array, delimiter='\t', header='Train_Loss', comments='')
    
    print(f"Loss log saved to {loss_file_path}")
    
    if qtst is not None and qtst.size > 0:
        np.savetxt(os.path.join(results_dir, 'qtst.csv'), qtst, delimiter=',')
        print(f"Test predictions saved to {os.path.join(results_dir, 'qtst.csv')}")
    
    if qtrn is not None and qtrn.size > 0:
        np.savetxt(os.path.join(results_dir, 'qtrn.csv'), qtrn, delimiter=',')
        print(f"Training predictions saved to {os.path.join(results_dir, 'qtrn.csv')}")
    
    print(f'\nAverage of last 5 training losses: {np.mean(loss_train):.6f}')
    print('Training completed!')
