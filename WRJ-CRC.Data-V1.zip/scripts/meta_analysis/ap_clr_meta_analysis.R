#!/usr/bin/env Rscript

# AP candidate-species CLR meta-analysis with project-level effects and random-effects pooling.
source(file.path("config", "project_paths.R"))
CONFIG <- list(
  project_root = PROJECT_ROOT,
  input_dir = AP_META_DATA_DIR,
  results_dir = RESULTS$ap_meta,
  metadata_file = "metadata_filtered.txt",
  taxonomy_file = "taxonomy_species.txt",
  candidate_file = file.path(RESULTS$importance, "Adenoma_rank_Species.txt"),
  qpcr_file = "self_select_species_ap.txt",
  allowed_groups = c(GROUP_HC, GROUP_AP),
  expected_project_count = 6L,
  minimum_group_n = 10L,
  minimum_meta_projects = 3L,
  variance_tolerance = 1e-12,
  zero_tolerance = 1e-12,
  clr_sum_tolerance = 1e-8,
  delta_multipliers = c(0.5, 1, 2),
  meta_method = "REML",
  meta_test = "knha",
  ci_level = 0.95,
  test_alternative = "two-sided",
  extreme_weight_percent = 80,
  random_seed = 20260810L,
  adjusted_models = list(
    Age_Gender = c("Age", "Gender"),
    Age_Gender_BMI = c("Age", "Gender", "BMI")
  )
)

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L) y else x

select_case_control_projects <- function(metadata) {
  required <- c("Sample_ID", "Project_ID", "Group")
  missing_columns <- setdiff(required, names(metadata))
  if (length(missing_columns) > 0L) {
    stop("metadata 缺少必要字段: ", paste(missing_columns, collapse = ", "), call. = FALSE)
  }

  selected <- metadata[metadata$Group %in% c(GROUP_HC, GROUP_AP), , drop = FALSE]
  group_sets <- split(selected$Group, selected$Project_ID)
  paired_projects <- names(group_sets)[vapply(
    group_sets,
    function(x) all(c(GROUP_HC, GROUP_AP) %in% unique(x)),
    logical(1)
  )]
  selected[selected$Project_ID %in% paired_projects, , drop = FALSE]
}

multiplicative_replace <- function(composition, delta) {
  composition <- as.matrix(composition)
  storage.mode(composition) <- "double"
  if (!is.finite(delta) || delta <= 0) stop("delta 必须为有限正数", call. = FALSE)
  if (any(!is.finite(composition)) || any(composition < 0)) {
    stop("组成矩阵必须为有限非负数", call. = FALSE)
  }

  row_totals <- rowSums(composition)
  if (any(row_totals <= 0)) stop("存在 species 总和为 0 的样本", call. = FALSE)
  composition <- sweep(composition, 1L, row_totals, "/")

  zero_count <- rowSums(composition == 0)
  if (any(zero_count * delta >= 1)) {
    stop("至少一个样本不满足 zero_count * delta < 1", call. = FALSE)
  }

  positive_scale <- 1 - zero_count * delta
  replaced <- sweep(composition, 1L, positive_scale, "*")
  replaced[composition == 0] <- delta

  if (max(abs(rowSums(replaced) - 1)) > 1e-10) {
    stop("乘法零替代后组成未严格闭合", call. = FALSE)
  }
  replaced
}

calculate_clr <- function(positive_composition) {
  positive_composition <- as.matrix(positive_composition)
  storage.mode(positive_composition) <- "double"
  if (any(!is.finite(positive_composition)) || any(positive_composition <= 0)) {
    stop("CLR 输入必须全部为有限正数", call. = FALSE)
  }
  log_values <- log(positive_composition)
  sweep(log_values, 1L, rowMeans(log_values), "-")
}

assess_effect_eligibility <- function(raw_target, clr_target, group, min_group_n,
                                      variance_tolerance = 1e-12) {
  group <- as.character(group)
  n_hc <- sum(group == GROUP_HC)
  n_ap <- sum(group == GROUP_AP)
  result <- list(
    eligible = FALSE,
    reason = NA_character_,
    n_HC = n_hc,
    n_AP = n_ap,
    group_specific_all_zero = FALSE
  )

  if (n_hc < min_group_n || n_ap < min_group_n) {
    result$reason <- "INSUFFICIENT_GROUP_N"
    return(result)
  }
  if (all(raw_target == 0)) {
    result$reason <- "ALL_ZERO_TARGET"
    return(result)
  }

  hc_all_zero <- all(raw_target[group == GROUP_HC] == 0)
  ap_all_zero <- all(raw_target[group == GROUP_AP] == 0)
  result$group_specific_all_zero <- xor(hc_all_zero, ap_all_zero)

  if (any(!is.finite(clr_target))) {
    result$reason <- "NONFINITE_CLR"
    return(result)
  }
  if (!is.finite(stats::var(clr_target)) || stats::var(clr_target) <= variance_tolerance) {
    result$reason <- "ZERO_CLR_VARIANCE"
    return(result)
  }

  result$eligible <- TRUE
  result$reason <- "ELIGIBLE"
  result
}

require_analysis_packages <- function() {
  packages <- c("data.table", "sandwich", "metafor")
  missing_packages <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing_packages) > 0L) {
    stop(
      "缺少必要 R 包: ", paste(missing_packages, collapse = ", "),
      "。请先安装后再运行分析。",
      call. = FALSE
    )
  }
}

make_logger <- function() {
  entries <- character()
  list(
    add = function(level, message_text) {
      line <- sprintf("[%s] [%s] %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), level, message_text)
      entries <<- c(entries, line)
      message(line)
      invisible(line)
    },
    get = function() entries
  )
}

safe_numeric <- function(x, field_name) {
  original_missing <- is.na(x) | trimws(as.character(x)) %in% c("", "NA", "N/A", "na", "NaN")
  converted <- suppressWarnings(as.numeric(x))
  newly_missing <- is.na(converted) & !original_missing
  if (any(newly_missing)) {
    stop(field_name, " 含无法转换为数值的非缺失值", call. = FALSE)
  }
  converted
}

fit_hc3_model <- function(model_data, model_formula) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::lm(model_formula, data = model_data),
    warning = function(w) {
      warning_messages <<- c(warning_messages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (is.na(stats::coef(fit)["group_ap"])) stop("Group 系数不可估计", call. = FALSE)

  vcov_hc3 <- withCallingHandlers(
    sandwich::vcovHC(fit, type = "HC3"),
    warning = function(w) {
      warning_messages <<- c(warning_messages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  beta <- unname(stats::coef(fit)["group_ap"])
  se <- sqrt(unname(vcov_hc3["group_ap", "group_ap"]))
  if (!is.finite(beta) || !is.finite(se) || se <= 0) stop("Group beta 或 HC3 SE 非有限", call. = FALSE)

  z_value <- beta / se
  critical <- stats::qnorm(0.975)
  list(
    beta = beta,
    se = se,
    ci_lower = beta - critical * se,
    ci_upper = beta + critical * se,
    p_value = 2 * stats::pnorm(abs(z_value), lower.tail = FALSE),
    warnings = paste(unique(warning_messages), collapse = " | "),
    residual_df = stats::df.residual(fit)
  )
}

fit_project_effect <- function(project_metadata, raw_target, clr_target, species,
                               project_id, min_group_n, variance_tolerance) {
  eligibility <- assess_effect_eligibility(
    raw_target = raw_target,
    clr_target = clr_target,
    group = project_metadata$Group,
    min_group_n = min_group_n,
    variance_tolerance = variance_tolerance
  )

  prevalence_hc <- mean(raw_target[project_metadata$Group == GROUP_HC] > 0)
  prevalence_ap <- mean(raw_target[project_metadata$Group == GROUP_AP] > 0)
  base_result <- data.table::data.table(
    Project_ID = project_id,
    Species = species,
    n_HC = eligibility$n_HC,
    n_AP = eligibility$n_AP,
    mean_CLR_HC = mean(clr_target[project_metadata$Group == GROUP_HC]),
    mean_CLR_AP = mean(clr_target[project_metadata$Group == GROUP_AP]),
    SD_CLR_HC = stats::sd(clr_target[project_metadata$Group == GROUP_HC]),
    SD_CLR_AP = stats::sd(clr_target[project_metadata$Group == GROUP_AP]),
    median_raw_HC = stats::median(raw_target[project_metadata$Group == GROUP_HC]),
    median_raw_AP = stats::median(raw_target[project_metadata$Group == GROUP_AP]),
    prevalence_HC = prevalence_hc,
    prevalence_AP = prevalence_ap,
    nonzero_HC = sum(raw_target[project_metadata$Group == GROUP_HC] > 0),
    nonzero_AP = sum(raw_target[project_metadata$Group == GROUP_AP] > 0),
    all_zero_target = all(raw_target == 0),
    zero_CLR_variance = !is.finite(stats::var(clr_target)) || stats::var(clr_target) <= variance_tolerance,
    group_specific_all_zero = eligibility$group_specific_all_zero,
    zero_pattern = if (all(raw_target == 0)) {
      "ALL_ZERO_TARGET"
    } else if (eligibility$group_specific_all_zero) {
      "GROUP_SPECIFIC_ALL_ZERO"
    } else {
      "BOTH_GROUPS_HAVE_NONZERO"
    },
    eligible = eligibility$eligible,
    exclusion_reason = eligibility$reason,
    beta_CLR = NA_real_,
    SE_HC3 = NA_real_,
    variance = NA_real_,
    CI_lower = NA_real_,
    CI_upper = NA_real_,
    P_value = NA_real_,
    Test_alternative = "two-sided",
    exp_beta = NA_real_,
    exp_CI_lower = NA_real_,
    exp_CI_upper = NA_real_,
    model_warning = ""
  )
  if (!eligibility$eligible) return(base_result)

  model_data <- data.frame(
    y = clr_target,
    group_ap = as.integer(project_metadata$Group == GROUP_AP)
  )
  fit_result <- tryCatch(
    fit_hc3_model(model_data, y ~ group_ap),
    error = function(e) e
  )
  if (inherits(fit_result, "error")) {
    base_result[, `:=`(
      eligible = FALSE,
      exclusion_reason = "MODEL_OR_HC3_ERROR",
      model_warning = conditionMessage(fit_result)
    )]
    return(base_result)
  }

  base_result[, `:=`(
    beta_CLR = fit_result$beta,
    SE_HC3 = fit_result$se,
    variance = fit_result$se^2,
    CI_lower = fit_result$ci_lower,
    CI_upper = fit_result$ci_upper,
    P_value = fit_result$p_value,
    exp_beta = exp(fit_result$beta),
    exp_CI_lower = exp(fit_result$ci_lower),
    exp_CI_upper = exp(fit_result$ci_upper),
    model_warning = fit_result$warnings
  )]
  base_result
}

fit_adjusted_project_effect <- function(project_metadata, raw_target, clr_target,
                                        species, project_id, model_name, covariates,
                                        min_group_n, variance_tolerance) {
  model_data <- data.frame(
    y = clr_target,
    raw_target = raw_target,
    group = project_metadata$Group,
    group_ap = as.integer(project_metadata$Group == GROUP_AP),
    stringsAsFactors = FALSE
  )
  for (covariate in covariates) model_data[[covariate]] <- project_metadata[[covariate]]
  if ("Age" %in% covariates) model_data$Age <- safe_numeric(model_data$Age, "Age")
  if ("BMI" %in% covariates) model_data$BMI <- safe_numeric(model_data$BMI, "BMI")
  if ("Gender" %in% covariates) {
    model_data$Gender <- trimws(as.character(model_data$Gender))
    model_data$Gender[model_data$Gender %in% c("", "NA", "N/A", "na")] <- NA_character_
    model_data$Gender <- factor(model_data$Gender)
  }

  complete <- stats::complete.cases(model_data[, c("y", "raw_target", "group", "group_ap", covariates), drop = FALSE])
  model_data <- model_data[complete, , drop = FALSE]
  n_hc <- sum(model_data$group == GROUP_HC)
  n_ap <- sum(model_data$group == GROUP_AP)
  base_result <- data.table::data.table(
    Model = model_name,
    Formula = paste("CLR ~ Group +", paste(covariates, collapse = " + ")),
    Project_ID = project_id,
    Species = species,
    n_complete = nrow(model_data),
    n_HC = n_hc,
    n_AP = n_ap,
    eligible = FALSE,
    exclusion_reason = NA_character_,
    beta_CLR = NA_real_,
    SE_HC3 = NA_real_,
    CI_lower = NA_real_,
    CI_upper = NA_real_,
    P_value = NA_real_,
    Test_alternative = "two-sided",
    model_warning = ""
  )
  if (n_hc < min_group_n || n_ap < min_group_n) {
    base_result[, exclusion_reason := "INSUFFICIENT_COMPLETE_CASE_GROUP_N"]
    return(base_result)
  }
  if (all(model_data$raw_target == 0)) {
    base_result[, exclusion_reason := "ALL_ZERO_TARGET_COMPLETE_CASES"]
    return(base_result)
  }
  if (stats::var(model_data$y) <= variance_tolerance) {
    base_result[, exclusion_reason := "ZERO_CLR_VARIANCE_COMPLETE_CASES"]
    return(base_result)
  }
  for (covariate in covariates) {
    if (length(unique(model_data[[covariate]])) < 2L) {
      base_result[, exclusion_reason := paste0("NO_VARIATION_", toupper(covariate))]
      return(base_result)
    }
  }

  model_formula <- stats::as.formula(paste("y ~ group_ap +", paste(covariates, collapse = " + ")))
  fit_result <- tryCatch(
    fit_hc3_model(model_data, model_formula),
    error = function(e) e
  )
  if (inherits(fit_result, "error")) {
    base_result[, `:=`(
      exclusion_reason = "ADJUSTED_MODEL_OR_HC3_ERROR",
      model_warning = conditionMessage(fit_result)
    )]
    return(base_result)
  }

  base_result[, `:=`(
    eligible = TRUE,
    exclusion_reason = "ELIGIBLE",
    beta_CLR = fit_result$beta,
    SE_HC3 = fit_result$se,
    CI_lower = fit_result$ci_lower,
    CI_upper = fit_result$ci_upper,
    P_value = fit_result$p_value,
    model_warning = fit_result$warnings
  )]
  base_result
}

empty_meta_result <- function(species, delta_multiplier, status, warning_text = "") {
  data.table::data.table(
    Species = species,
    Delta_multiplier = delta_multiplier,
    N_eligible_projects = 0L,
    Pooled_CLR_beta = NA_real_,
    Pooled_SE = NA_real_,
    CI_lower = NA_real_,
    CI_upper = NA_real_,
    P_value = NA_real_,
    Test_alternative = "two-sided",
    Exp_pooled_beta = NA_real_,
    Exp_CI_lower = NA_real_,
    Exp_CI_upper = NA_real_,
    Tau2 = NA_real_,
    I2 = NA_real_,
    Cochran_Q = NA_real_,
    Q_p = NA_real_,
    Prediction_interval_lower = NA_real_,
    Prediction_interval_upper = NA_real_,
    Exp_prediction_interval_lower = NA_real_,
    Exp_prediction_interval_upper = NA_real_,
    Max_weight_percent = NA_real_,
    Tau2_boundary = NA,
    Extreme_weight = NA,
    HK_SE_smaller_than_Wald_SE = NA,
    Meta_status = status,
    Meta_warning = warning_text
  )
}

fit_random_effects_meta <- function(effect_data, species, delta_multiplier, config) {
  eligible <- effect_data[
    eligible == TRUE & is.finite(beta_CLR) & is.finite(SE_HC3) & SE_HC3 > 0
  ]
  k <- nrow(eligible)
  if (k < config$minimum_meta_projects) {
    result <- empty_meta_result(species, delta_multiplier, "INSUFFICIENT_ELIGIBLE_PROJECTS")
    result[, N_eligible_projects := k]
    return(result)
  }

  warning_messages <- character()
  fit <- tryCatch(
    withCallingHandlers(
      metafor::rma.uni(
        yi = eligible$beta_CLR,
        sei = eligible$SE_HC3,
        method = config$meta_method,
        test = config$meta_test,
        slab = eligible$Project_ID
      ),
      warning = function(w) {
        warning_messages <<- c(warning_messages, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) e
  )
  if (inherits(fit, "error")) {
    result <- empty_meta_result(species, delta_multiplier, "META_MODEL_ERROR", conditionMessage(fit))
    result[, N_eligible_projects := k]
    return(result)
  }

  prediction <- tryCatch(
    withCallingHandlers(
      stats::predict(fit),
      warning = function(w) {
        warning_messages <<- c(warning_messages, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) e
  )
  pi_lower <- NA_real_
  pi_upper <- NA_real_
  if (inherits(prediction, "error")) {
    warning_messages <- c(warning_messages, paste("Prediction interval:", conditionMessage(prediction)))
  } else {
    pi_lower <- as.numeric(prediction$pi.lb %||% prediction$cr.lb %||% NA_real_)
    pi_upper <- as.numeric(prediction$pi.ub %||% prediction$cr.ub %||% NA_real_)
    if (!is.finite(pi_lower) || !is.finite(pi_upper)) {
      warning_messages <- c(warning_messages, "Prediction interval is non-finite")
    }
  }

  weights_percent <- tryCatch(as.numeric(stats::weights(fit)), error = function(e) rep(NA_real_, k))
  max_weight <- if (all(is.na(weights_percent))) NA_real_ else max(weights_percent, na.rm = TRUE)
  fit_wald <- tryCatch(
    metafor::rma.uni(
      yi = eligible$beta_CLR,
      sei = eligible$SE_HC3,
      method = config$meta_method,
      test = "z"
    ),
    error = function(e) NULL
  )
  hk_se_smaller <- if (is.null(fit_wald)) NA else as.numeric(fit$se) < as.numeric(fit_wald$se) - 1e-12
  if (isTRUE(hk_se_smaller)) {
    warning_messages <- c(warning_messages, "Knapp-Hartung SE is smaller than the unadjusted Wald SE")
  }
  if (is.finite(max_weight) && max_weight > config$extreme_weight_percent) {
    warning_messages <- c(warning_messages, "One Project has an extreme meta-analytic weight")
  }
  if (k <= 4L) warning_messages <- c(warning_messages, "Prediction interval is highly uncertain because k <= 4")

  pooled_beta <- as.numeric(fit$b)
  ci_lower <- as.numeric(fit$ci.lb)
  ci_upper <- as.numeric(fit$ci.ub)
  data.table::data.table(
    Species = species,
    Delta_multiplier = delta_multiplier,
    N_eligible_projects = k,
    Pooled_CLR_beta = pooled_beta,
    Pooled_SE = as.numeric(fit$se),
    CI_lower = ci_lower,
    CI_upper = ci_upper,
    P_value = as.numeric(fit$pval),
    Test_alternative = config$test_alternative,
    Exp_pooled_beta = exp(pooled_beta),
    Exp_CI_lower = exp(ci_lower),
    Exp_CI_upper = exp(ci_upper),
    Tau2 = as.numeric(fit$tau2),
    I2 = as.numeric(fit$I2),
    Cochran_Q = as.numeric(fit$QE),
    Q_p = as.numeric(fit$QEp),
    Prediction_interval_lower = pi_lower,
    Prediction_interval_upper = pi_upper,
    Exp_prediction_interval_lower = if (is.finite(pi_lower)) exp(pi_lower) else NA_real_,
    Exp_prediction_interval_upper = if (is.finite(pi_upper)) exp(pi_upper) else NA_real_,
    Max_weight_percent = max_weight,
    Tau2_boundary = isTRUE(as.numeric(fit$tau2) <= config$variance_tolerance),
    Extreme_weight = is.finite(max_weight) && max_weight > config$extreme_weight_percent,
    HK_SE_smaller_than_Wald_SE = hk_se_smaller,
    Meta_status = "OK",
    Meta_warning = paste(unique(warning_messages[nzchar(warning_messages)]), collapse = " | ")
  )
}

run_meta_by_species <- function(project_effects, candidate_species, delta_multiplier, config) {
  data.table::rbindlist(lapply(candidate_species, function(species) {
    fit_random_effects_meta(
      project_effects[Species == species],
      species = species,
      delta_multiplier = delta_multiplier,
      config = config
    )
  }), fill = TRUE)
}

add_direction_statistics <- function(meta_results, project_effects, zero_tolerance) {
  direction_rows <- lapply(meta_results$Species, function(species) {
    pooled <- meta_results[Species == species]$Pooled_CLR_beta[1]
    estimates <- project_effects[Species == species & eligible == TRUE & is.finite(beta_CLR)]$beta_CLR
    n_positive <- sum(estimates > zero_tolerance)
    n_negative <- sum(estimates < -zero_tolerance)
    n_zero <- sum(abs(estimates) <= zero_tolerance)
    pooled_sign <- sign(pooled)
    n_same <- if (!is.finite(pooled) || pooled_sign == 0) NA_integer_ else sum(sign(estimates) == pooled_sign)
    nonzero_count <- n_positive + n_negative
    pooled_direction <- if (!is.finite(pooled) || abs(pooled) <= zero_tolerance) {
      "Undetermined"
    } else if (pooled > 0) {
      "Positive"
    } else {
      "Negative"
    }
    dominant_direction <- if (n_positive > n_negative) {
      "Positive"
    } else if (n_negative > n_positive) {
      "Negative"
    } else {
      "Mixed"
    }
    data.table::data.table(
      Species = species,
      Pooled_direction = pooled_direction,
      Dominant_project_direction = dominant_direction,
      N_positive_projects = n_positive,
      N_negative_projects = n_negative,
      N_exact_zero = n_zero,
      N_same_direction_as_pooled = n_same,
      Eligible_denominator = length(estimates),
      Direction_consistency = if (length(estimates) == 0L || is.na(n_same)) NA_real_ else n_same / length(estimates),
      Direction_consistency_reference = "post-hoc pooled meta estimate",
      Dominant_direction_consistency = if (nonzero_count == 0L) NA_real_ else max(n_positive, n_negative) / nonzero_count
    )
  })
  merge(meta_results, data.table::rbindlist(direction_rows), by = "Species", all.x = TRUE, sort = FALSE)
}

run_leave_one_out <- function(project_effects, candidate_species, delta_multiplier, config) {
  rows <- list()
  row_index <- 0L
  for (species in candidate_species) {
    eligible <- project_effects[
      Species == species & eligible == TRUE & is.finite(beta_CLR) & is.finite(SE_HC3) & SE_HC3 > 0
    ]
    if (nrow(eligible) == 0L) next
    full_meta <- fit_random_effects_meta(eligible, species, delta_multiplier, config)
    for (omitted_project in eligible$Project_ID) {
      row_index <- row_index + 1L
      remaining <- eligible[Project_ID != omitted_project]
      if (nrow(remaining) < config$minimum_meta_projects) {
        rows[[row_index]] <- data.table::data.table(
          Species = species,
          Delta_multiplier = delta_multiplier,
          Omitted_project = omitted_project,
          N_remaining_projects = nrow(remaining),
          Full_pooled_beta = full_meta$Pooled_CLR_beta,
          LOO_pooled_beta = NA_real_,
          CI_lower = NA_real_,
          CI_upper = NA_real_,
          P_value = NA_real_,
          Exp_pooled_beta = NA_real_,
          Tau2 = NA_real_,
          I2 = NA_real_,
          Prediction_interval_lower = NA_real_,
          Prediction_interval_upper = NA_real_,
          Absolute_change_from_full = NA_real_,
          Same_direction_as_full = NA,
          CI_nonoverlap_zero = NA,
          LOO_status = "INSUFFICIENT_REMAINING_PROJECTS",
          LOO_warning = ""
        )
      } else {
        loo_meta <- fit_random_effects_meta(remaining, species, delta_multiplier, config)
        loo_beta <- loo_meta$Pooled_CLR_beta
        full_beta <- full_meta$Pooled_CLR_beta
        rows[[row_index]] <- data.table::data.table(
          Species = species,
          Delta_multiplier = delta_multiplier,
          Omitted_project = omitted_project,
          N_remaining_projects = nrow(remaining),
          Full_pooled_beta = full_beta,
          LOO_pooled_beta = loo_beta,
          CI_lower = loo_meta$CI_lower,
          CI_upper = loo_meta$CI_upper,
          P_value = loo_meta$P_value,
          Exp_pooled_beta = loo_meta$Exp_pooled_beta,
          Tau2 = loo_meta$Tau2,
          I2 = loo_meta$I2,
          Prediction_interval_lower = loo_meta$Prediction_interval_lower,
          Prediction_interval_upper = loo_meta$Prediction_interval_upper,
          Absolute_change_from_full = abs(loo_beta - full_beta),
          Same_direction_as_full = sign(loo_beta) == sign(full_beta),
          CI_nonoverlap_zero = loo_meta$CI_lower > 0 || loo_meta$CI_upper < 0,
          LOO_status = loo_meta$Meta_status,
          LOO_warning = loo_meta$Meta_warning
        )
      }
    }
  }
  if (length(rows) == 0L) return(data.table::data.table())
  data.table::rbindlist(rows, fill = TRUE)
}

summarize_loo <- function(loo_results, candidate_species, main_multiplier = 1) {
  data.table::rbindlist(lapply(candidate_species, function(species) {
    x <- loo_results[
      Species == species & Delta_multiplier == main_multiplier & LOO_status == "OK" & is.finite(LOO_pooled_beta)
    ]
    if (nrow(x) == 0L) {
      return(data.table::data.table(
        Species = species,
        LOO_direction_consistency = NA_real_,
        LOO_CI_nonoverlap_zero_count = NA_integer_,
        LOO_min_beta = NA_real_,
        LOO_max_beta = NA_real_,
        Max_LOO_change = NA_real_
      ))
    }
    data.table::data.table(
      Species = species,
      LOO_direction_consistency = mean(x$Same_direction_as_full),
      LOO_CI_nonoverlap_zero_count = sum(x$CI_nonoverlap_zero),
      LOO_min_beta = min(x$LOO_pooled_beta),
      LOO_max_beta = max(x$LOO_pooled_beta),
      Max_LOO_change = max(x$Absolute_change_from_full)
    )
  }), fill = TRUE)
}

summarize_delta_sensitivity <- function(all_meta_results, candidate_species, zero_tolerance) {
  data.table::rbindlist(lapply(candidate_species, function(species) {
    x <- all_meta_results[Species == species & is.finite(Pooled_CLR_beta)]
    main_beta <- x[Delta_multiplier == 1]$Pooled_CLR_beta[1]
    if (nrow(x) == 0L || length(main_beta) == 0L || !is.finite(main_beta)) {
      return(data.table::data.table(
        Species = species,
        Delta_direction_stability = NA_real_,
        Delta_beta_min = NA_real_,
        Delta_beta_max = NA_real_,
        Delta_beta_range = NA_real_,
        Delta_eligible_project_stability = NA,
        Zero_replacement_sensitive = NA
      ))
    }
    main_sign <- if (abs(main_beta) <= zero_tolerance) 0 else sign(main_beta)
    signs <- ifelse(abs(x$Pooled_CLR_beta) <= zero_tolerance, 0, sign(x$Pooled_CLR_beta))
    eligible_stable <- length(unique(x$N_eligible_projects)) == 1L && nrow(x) == 3L
    direction_stability <- mean(signs == main_sign)
    data.table::data.table(
      Species = species,
      Delta_direction_stability = direction_stability,
      Delta_beta_min = min(x$Pooled_CLR_beta),
      Delta_beta_max = max(x$Pooled_CLR_beta),
      Delta_beta_range = max(x$Pooled_CLR_beta) - min(x$Pooled_CLR_beta),
      Delta_eligible_project_stability = eligible_stable,
      Zero_replacement_sensitive = direction_stability < 1 || !eligible_stable
    )
  }), fill = TRUE)
}

write_embedded_config <- function(config, delta_main, universe_version, selected_projects, output_file) {
  lines <- c(
    paste0("run_date: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("random_seed: ", config$random_seed),
    paste0("selected_projects: [", paste(selected_projects, collapse = ", "), "]"),
    paste0("minimum_group_n: ", config$minimum_group_n),
    paste0("minimum_meta_projects: ", config$minimum_meta_projects),
    paste0("delta_main: ", format(delta_main, digits = 17, scientific = TRUE)),
    paste0("delta_multipliers: [", paste(config$delta_multipliers, collapse = ", "), "]"),
    paste0("global_universe_version: ", universe_version),
    paste0("meta_method: ", config$meta_method),
    paste0("meta_test: ", config$meta_test),
    paste0("test_alternative: ", config$test_alternative),
    "null_hypothesis: beta_CLR = 0",
    "alternative_hypothesis: beta_CLR != 0",
    "main_model: CLR ~ Group",
    "adjusted_model_1: CLR ~ Group + Age + Gender",
    "adjusted_model_2: CLR ~ Group + Age + Gender + BMI",
    "expected_direction_all_candidates: not_specified",
    "automatic_evidence_grade: false"
  )
  writeLines(lines, output_file, useBytes = TRUE)
}

main <- function(config = CONFIG) {
  require_analysis_packages()
  if (!identical(config$test_alternative, "two-sided")) {
    stop("本分析固定采用双侧检验；test_alternative 必须为 'two-sided'", call. = FALSE)
  }
  set.seed(config$random_seed)
  logger <- make_logger()
  logger$add("INFO", "开始 AP 固定全局 CLR 跨 Project Meta 分析")

  dir.create(config$results_dir, recursive = TRUE, showWarnings = FALSE)

  input_path <- function(filename) {
    if (identical(filename, config$candidate_file)) filename else file.path(config$input_dir, filename)
  }
  required_files <- vapply(
    c(config$metadata_file, config$taxonomy_file, config$candidate_file, config$qpcr_file),
    input_path,
    character(1)
  )
  missing_files <- required_files[!file.exists(required_files)]
  if (length(missing_files) > 0L) stop("缺少输入文件: ", paste(missing_files, collapse = ", "), call. = FALSE)

  metadata <- data.table::fread(input_path(config$metadata_file), sep = "\t", na.strings = c("NA", "N/A", ""))
  if (anyDuplicated(metadata$Sample_ID)) stop("metadata 中 Sample_ID 不唯一", call. = FALSE)
  if (anyNA(metadata$Project_ID) || anyNA(metadata$Group)) stop("metadata 存在缺失 Project_ID 或 Group", call. = FALSE)
  if (!"Country" %in% names(metadata)) stop("metadata 缺少 Country 字段", call. = FALSE)
  invalid_groups <- setdiff(unique(metadata$Group), c(GROUP_HC, GROUP_AP, GROUP_CRC))
  if (length(invalid_groups) > 0L) logger$add("WARN", paste("metadata 中存在其他组别:", paste(invalid_groups, collapse = ", ")))

  selected_metadata <- data.table::as.data.table(select_case_control_projects(metadata))
  selected_metadata[, Country := trimws(as.character(Country))]
  selected_metadata[Country == "USA and Canda", Country := "USA and Canada"]
  if (anyNA(selected_metadata$Country) || any(!nzchar(selected_metadata$Country))) {
    stop("纳入分析的 HC/AP 样本存在缺失 Country", call. = FALSE)
  }
  selected_projects <- sort(unique(selected_metadata$Project_ID))
  if (length(selected_projects) != config$expected_project_count) {
    stop(
      "同时含 HC/AP 的 Project 数为 ", length(selected_projects),
      "，与预期 ", config$expected_project_count, " 不符。实际为: ",
      paste(selected_projects, collapse = ", "),
      call. = FALSE
    )
  }
  data.table::setorder(selected_metadata, Project_ID, Group, Sample_ID)
  project_country <- selected_metadata[, .(
    Country = paste(sort(unique(Country)), collapse = " / ")
  ), by = Project_ID]
  project_country[, Project_label := paste0(Project_ID, " (", Country, ")")]
  logger$add("INFO", paste("固定纳入 6 个 Project:", paste(selected_projects, collapse = ", ")))

  candidates <- data.table::fread(input_path(config$candidate_file), sep = "\t")
  if (!"Variable" %in% names(candidates) || !"mean_rank" %in% names(candidates)) {
    stop("候选菌文件必须包含 Variable 和 mean_rank", call. = FALSE)
  }
  if (nrow(candidates) != 28L || anyDuplicated(candidates$Variable)) {
    stop("候选菌文件必须恰好包含 28 个不重复物种", call. = FALSE)
  }
  candidates[, `:=`(
    Species = Variable,
    Hypothesis_alternative = config$test_alternative,
    Original_rank = mean_rank
  )]

  qpcr <- data.table::fread(input_path(config$qpcr_file), sep = "\t")
  if (!"Species" %in% names(qpcr) || nrow(qpcr) != 8L || anyDuplicated(qpcr$Species)) {
    stop("qPCR 文件必须包含 8 个不重复 Species", call. = FALSE)
  }
  if (length(setdiff(qpcr$Species, candidates$Species)) > 0L) stop("存在不属于 28 候选菌的 qPCR 物种", call. = FALSE)
  candidates[, Original_qPCR_panel := Species %in% qpcr$Species]

  logger$add("INFO", "读取 taxonomy_species.txt；该步骤可能占用较多内存")
  taxonomy_table <- data.table::fread(
    input_path(config$taxonomy_file),
    sep = "\t",
    check.names = FALSE,
    na.strings = c("NA", "N/A", "")
  )
  if (ncol(taxonomy_table) < 2L || names(taxonomy_table)[1] != "Taxonomy") {
    stop("taxonomy_species.txt 第一列必须为 Taxonomy，后续列必须为 Sample_ID", call. = FALSE)
  }
  taxonomy_names <- taxonomy_table[[1]]
  if (anyDuplicated(taxonomy_names)) stop("taxonomy_species.txt 存在重复 taxonomy", call. = FALSE)
  if (any(!startsWith(taxonomy_names, "s__"))) stop("taxonomy 表含非 species 层级成分", call. = FALSE)
  sample_columns <- names(taxonomy_table)[-1]
  if (anyDuplicated(sample_columns)) stop("丰度表 Sample_ID 列重复", call. = FALSE)
  missing_abundance_samples <- setdiff(selected_metadata$Sample_ID, sample_columns)
  if (length(missing_abundance_samples) > 0L) {
    stop("选定 HC/AP 样本在丰度表中缺失: ", paste(head(missing_abundance_samples, 20L), collapse = ", "), call. = FALSE)
  }

  selected_sample_ids <- selected_metadata$Sample_ID
  abundance_matrix <- as.matrix(taxonomy_table[, ..selected_sample_ids])
  storage.mode(abundance_matrix) <- "double"
  rownames(abundance_matrix) <- taxonomy_names
  if (anyNA(abundance_matrix) || any(!is.finite(abundance_matrix))) stop("丰度矩阵含 NA/Inf 或非数值", call. = FALSE)
  if (any(abundance_matrix < 0) || any(abundance_matrix > 100 + 1e-8)) stop("丰度存在负值或大于 100 的值", call. = FALSE)
  if (length(setdiff(candidates$Species, taxonomy_names)) > 0L) stop("28 个候选菌未全部映射到最终 taxonomy", call. = FALSE)

  observed_in_six_projects <- rowSums(abundance_matrix > 0) > 0
  universe_species <- sort(unique(c(
    taxonomy_names[observed_in_six_projects],
    candidates$Species
  )))
  abundance_matrix <- abundance_matrix[universe_species, , drop = FALSE]
  raw_sample_by_species <- t(abundance_matrix)
  rm(taxonomy_table, abundance_matrix)
  gc(verbose = FALSE)

  sample_percent_sums <- rowSums(raw_sample_by_species)
  zero_sum_samples <- rownames(raw_sample_by_species)[sample_percent_sums <= 0]
  if (length(zero_sum_samples) > 0L) {
    logger$add("WARN", paste(length(zero_sum_samples), "个样本 species 总和为 0，已排除并记录"))
    selected_metadata <- selected_metadata[!Sample_ID %in% zero_sum_samples]
    raw_sample_by_species <- raw_sample_by_species[selected_metadata$Sample_ID, , drop = FALSE]
    sample_percent_sums <- rowSums(raw_sample_by_species)
  }
  composition <- sweep(raw_sample_by_species / 100, 1L, sample_percent_sums / 100, "/")
  positive_values <- composition[composition > 0]
  if (length(positive_values) == 0L) stop("选定样本中不存在严格正 species 丰度", call. = FALSE)
  delta_main <- min(positive_values) / 2
  logger$add("INFO", paste0("全局主 delta = ", format(delta_main, digits = 17, scientific = TRUE)))

  universe_table <- data.table::data.table(
    Coordinate_order = seq_along(universe_species),
    Species = universe_species,
    Observed_in_selected_projects = universe_species %in% taxonomy_names[observed_in_six_projects],
    Candidate_28 = universe_species %in% candidates$Species,
    qPCR_panel_8 = universe_species %in% qpcr$Species
  )
  universe_file <- file.path(config$results_dir, "01_global_species_universe.tsv")
  data.table::fwrite(universe_table, universe_file, sep = "\t", na = "NA")
  universe_hash <- unname(tools::md5sum(universe_file))
  universe_version <- paste0("U_MD5_", universe_hash, "_D", nrow(universe_table))

  all_project_effects <- list()
  all_meta_results <- list()
  all_loo_results <- list()
  clr_main <- NULL
  replaced_main <- NULL
  result_index <- 0L

  for (delta_multiplier in config$delta_multipliers) {
    result_index <- result_index + 1L
    delta_value <- delta_main * delta_multiplier
    logger$add("INFO", paste("运行 delta multiplier =", delta_multiplier))
    replaced <- multiplicative_replace(composition, delta_value)
    clr_matrix <- calculate_clr(replaced)
    if (any(!is.finite(clr_matrix)) || max(abs(rowSums(clr_matrix))) > config$clr_sum_tolerance) {
      stop("CLR 有非有限值或行和校验失败", call. = FALSE)
    }
    rownames(clr_matrix) <- selected_metadata$Sample_ID
    colnames(clr_matrix) <- universe_species
    rownames(replaced) <- selected_metadata$Sample_ID
    colnames(replaced) <- universe_species
    if (delta_multiplier == 1) {
      clr_main <- clr_matrix
      replaced_main <- replaced
    }

    effect_rows <- list()
    effect_index <- 0L
    for (project_id in selected_projects) {
      project_metadata <- selected_metadata[Project_ID == project_id]
      project_rows <- match(project_metadata$Sample_ID, rownames(clr_matrix))
      for (species in candidates$Species) {
        effect_index <- effect_index + 1L
        species_column <- match(species, universe_species)
        effect_rows[[effect_index]] <- fit_project_effect(
          project_metadata = project_metadata,
          raw_target = raw_sample_by_species[project_rows, species_column],
          clr_target = clr_matrix[project_rows, species_column],
          species = species,
          project_id = project_id,
          min_group_n = config$minimum_group_n,
          variance_tolerance = config$variance_tolerance
        )
      }
    }
    project_effects <- data.table::rbindlist(effect_rows, fill = TRUE)
    project_effects[, `:=`(Delta_multiplier = delta_multiplier, Delta_value = delta_value)]
    meta_results <- run_meta_by_species(project_effects, candidates$Species, delta_multiplier, config)
    meta_results <- add_direction_statistics(meta_results, project_effects, config$zero_tolerance)
    loo_results <- run_leave_one_out(project_effects, candidates$Species, delta_multiplier, config)

    all_project_effects[[result_index]] <- project_effects
    all_meta_results[[result_index]] <- meta_results
    all_loo_results[[result_index]] <- loo_results
  }

  project_effects_all <- data.table::rbindlist(all_project_effects, fill = TRUE)
  meta_results_all <- data.table::rbindlist(all_meta_results, fill = TRUE)
  loo_results_all <- data.table::rbindlist(all_loo_results, fill = TRUE)
  project_effects_all <- merge(
    project_effects_all, project_country,
    by = "Project_ID", all.x = TRUE, sort = FALSE
  )
  loo_results_all <- merge(
    loo_results_all, project_country,
    by.x = "Omitted_project", by.y = "Project_ID",
    all.x = TRUE, sort = FALSE
  )
  data.table::setnames(
    loo_results_all,
    c("Country", "Project_label"),
    c("Omitted_Country", "Omitted_project_label")
  )
  main_project_effects <- project_effects_all[Delta_multiplier == 1]
  main_meta_results <- meta_results_all[Delta_multiplier == 1]
  main_meta_results[, BH_q := NA_real_]
  finite_p <- which(is.finite(main_meta_results$P_value))
  main_meta_results$BH_q[finite_p] <- stats::p.adjust(main_meta_results$P_value[finite_p], method = "BH")

  loo_summary <- summarize_loo(loo_results_all, candidates$Species)
  delta_summary <- summarize_delta_sensitivity(meta_results_all, candidates$Species, config$zero_tolerance)

  sample_qc <- data.table::data.table(
    Sample_ID = selected_metadata$Sample_ID,
    Project_ID = selected_metadata$Project_ID,
    Country = selected_metadata$Country,
    Group = selected_metadata$Group,
    Original_species_percent_sum = sample_percent_sums,
    D_global_species = ncol(composition),
    Zero_fraction = rowMeans(composition == 0),
    Number_of_detected_species = rowSums(composition > 0),
    Minimum_positive_abundance = apply(composition, 1L, function(x) min(x[x > 0])),
    Geometric_center_after_replacement = exp(rowMeans(log(replaced_main))),
    Composition_sum_after_replacement = rowSums(replaced_main),
    CLR_sum_check = rowSums(clr_main)
  )

  project_species_qc <- main_project_effects[, .(
    Project_ID, Country, Project_label, Species, n_HC, n_AP, prevalence_HC, prevalence_AP,
    nonzero_HC, nonzero_AP, median_raw_HC, median_raw_AP,
    mean_CLR_HC, mean_CLR_AP, SD_CLR_HC, SD_CLR_AP,
    all_zero_target, zero_CLR_variance, group_specific_all_zero,
    zero_pattern, eligible, exclusion_reason
  )]

  adjusted_effect_rows <- list()
  adjusted_index <- 0L
  for (model_name in names(config$adjusted_models)) {
    covariates <- config$adjusted_models[[model_name]]
    missing_covariates <- setdiff(covariates, names(selected_metadata))
    if (length(missing_covariates) > 0L) {
      logger$add("WARN", paste("跳过调整模型", model_name, "，metadata 缺少:", paste(missing_covariates, collapse = ", ")))
      next
    }
    for (project_id in selected_projects) {
      project_metadata <- selected_metadata[Project_ID == project_id]
      project_rows <- match(project_metadata$Sample_ID, rownames(clr_main))
      for (species in candidates$Species) {
        adjusted_index <- adjusted_index + 1L
        species_column <- match(species, universe_species)
        adjusted_effect_rows[[adjusted_index]] <- fit_adjusted_project_effect(
          project_metadata = project_metadata,
          raw_target = raw_sample_by_species[project_rows, species_column],
          clr_target = clr_main[project_rows, species_column],
          species = species,
          project_id = project_id,
          model_name = model_name,
          covariates = covariates,
          min_group_n = config$minimum_group_n,
          variance_tolerance = config$variance_tolerance
        )
      }
    }
  }
  adjusted_project_effects <- if (length(adjusted_effect_rows) > 0L) {
    data.table::rbindlist(adjusted_effect_rows, fill = TRUE)
  } else {
    data.table::data.table()
  }
  if (nrow(adjusted_project_effects) > 0L) {
    adjusted_project_effects <- merge(
      adjusted_project_effects, project_country,
      by = "Project_ID", all.x = TRUE, sort = FALSE
    )
  }
  adjusted_meta_results <- data.table::data.table()
  if (nrow(adjusted_project_effects) > 0L) {
    adjusted_meta_results <- data.table::rbindlist(lapply(unique(adjusted_project_effects$Model), function(model_name) {
      effects <- adjusted_project_effects[Model == model_name]
      meta_input <- effects[, .(
        Project_ID, Species, eligible, beta_CLR, SE_HC3
      )]
      model_meta <- run_meta_by_species(meta_input, candidates$Species, 1, config)
      model_meta[, Model := model_name]
      model_meta
    }), fill = TRUE)
  }

  prevalence_summary <- main_project_effects[, .(
    Prevalence_HC_sample_weighted = sum(prevalence_HC * n_HC) / sum(n_HC),
    Prevalence_AP_sample_weighted = sum(prevalence_AP * n_AP) / sum(n_AP),
    Prevalence_HC_project_median = stats::median(prevalence_HC),
    Prevalence_AP_project_median = stats::median(prevalence_AP),
    Prevalence_HC_project_min = min(prevalence_HC),
    Prevalence_HC_project_max = max(prevalence_HC),
    Prevalence_AP_project_min = min(prevalence_AP),
    Prevalence_AP_project_max = max(prevalence_AP)
  ), by = Species]

  evidence_matrix <- merge(
    candidates[, .(
      Species, Original_rank, Hypothesis_alternative, Original_qPCR_panel
    )],
    main_meta_results,
    by = "Species",
    all.x = TRUE,
    sort = FALSE
  )
  evidence_matrix <- merge(evidence_matrix, loo_summary, by = "Species", all.x = TRUE, sort = FALSE)
  evidence_matrix <- merge(evidence_matrix, delta_summary, by = "Species", all.x = TRUE, sort = FALSE)
  evidence_matrix <- merge(evidence_matrix, prevalence_summary, by = "Species", all.x = TRUE, sort = FALSE)
  evidence_matrix[, `:=`(
    Global_universe_version = universe_version,
    D_global_species = length(universe_species),
    Delta_main = delta_main,
    N_total_projects = length(selected_projects),
    Eligible_total_label = paste0(N_eligible_projects, "/", length(selected_projects))
  )]

  for (model_name in c("Age_Gender", "Age_Gender_BMI")) {
    model_result <- adjusted_meta_results[Model == model_name, .(
      Species,
      Adjusted_beta = Pooled_CLR_beta,
      Adjusted_CI_lower = CI_lower,
      Adjusted_CI_upper = CI_upper,
      Adjusted_P_value = P_value,
      Adjusted_N_projects = N_eligible_projects,
      Adjusted_status = Meta_status
    )]
    if (nrow(model_result) > 0L) {
      data.table::setnames(
        model_result,
        setdiff(names(model_result), "Species"),
        paste0(model_name, "_", setdiff(names(model_result), "Species"))
      )
      evidence_matrix <- merge(evidence_matrix, model_result, by = "Species", all.x = TRUE, sort = FALSE)
    }
  }

  evidence_matrix[, Notes := paste(
    ifelse(!is.na(Original_qPCR_panel) & Original_qPCR_panel, "Original_qPCR_panel", ""),
    ifelse(!is.na(Zero_replacement_sensitive) & Zero_replacement_sensitive, "zero-replacement-sensitive", ""),
    ifelse(!is.na(Extreme_weight) & Extreme_weight, "extreme-meta-weight", ""),
    ifelse(!is.na(HK_SE_smaller_than_Wald_SE) & HK_SE_smaller_than_Wald_SE, "HK-SE-smaller-than-Wald-SE", ""),
    Meta_warning,
    sep = "; "
  )]
  data.table::setorder(evidence_matrix, Original_rank)

  clr_output <- data.table::as.data.table(clr_main, keep.rownames = "Sample_ID")
  data.table::fwrite(sample_qc, file.path(config$results_dir, "02_sample_qc.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(project_species_qc, file.path(config$results_dir, "03_project_species_qc.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(clr_output, file.path(config$results_dir, "04_clr_matrix_main.tsv.gz"), sep = "\t", na = "NA", compress = "gzip")
  data.table::fwrite(main_project_effects, file.path(config$results_dir, "05_project_level_effects.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(main_meta_results, file.path(config$results_dir, "06_meta_results_28.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(loo_results_all[Delta_multiplier == 1], file.path(config$results_dir, "07_leave_one_project_out.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(meta_results_all, file.path(config$results_dir, "08_delta_sensitivity.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(loo_results_all, file.path(config$results_dir, "08_delta_sensitivity_LOO.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(adjusted_project_effects, file.path(config$results_dir, "09_adjusted_project_effects.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(adjusted_meta_results, file.path(config$results_dir, "09_adjusted_meta_results.tsv"), sep = "\t", na = "NA")
  data.table::fwrite(evidence_matrix, file.path(config$results_dir, "10_evidence_matrix_28.tsv"), sep = "\t", na = "NA")

  main_project_effects[, logger$add(
    "INFO",
    paste0("主分析 Project×Species 状态 ", exclusion_reason, ": ", .N)
  ), by = exclusion_reason]
  if (any(nzchar(main_project_effects$model_warning), na.rm = TRUE)) {
    logger$add("WARN", paste(sum(nzchar(main_project_effects$model_warning), na.rm = TRUE), "个主模型记录了 warning；详见 05_project_level_effects.tsv"))
  }
  if (any(nzchar(main_meta_results$Meta_warning), na.rm = TRUE)) {
    logger$add("WARN", paste(sum(nzchar(main_meta_results$Meta_warning), na.rm = TRUE), "个主 Meta 模型记录了 warning；详见 06_meta_results_28.tsv"))
  }
  if (nrow(adjusted_project_effects) > 0L) {
    adjusted_project_effects[, logger$add(
      "INFO",
      paste0("调整模型 ", Model, " 状态 ", exclusion_reason, ": ", .N)
    ), by = .(Model, exclusion_reason)]
  }

  write_embedded_config(
    config, delta_main, universe_version, selected_projects,
    file.path(config$results_dir, "00_run_config.yml")
  )
  writeLines(capture.output(sessionInfo()), file.path(config$results_dir, "00_session_info.txt"), useBytes = TRUE)
  logger$add("INFO", "分析脚本完成；请检查所有 warning、excluded/not-estimable 记录后再解释结果")
  writeLines(logger$get(), file.path(config$results_dir, "00_analysis_log.txt"), useBytes = TRUE)
  invisible(evidence_matrix)
}

if (!identical(Sys.getenv("AP_META_TEST_MODE"), "true")) {
  main()
}
