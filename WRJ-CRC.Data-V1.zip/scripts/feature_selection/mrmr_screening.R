#!/usr/bin/env Rscript
# Repeated project-grouped nested CV for mRMR feature-panel screening.
source(file.path("config", "project_paths.R"))
source(file.path("scripts", "feature_selection", "mrmr_panel_core.R"), encoding = "UTF-8")
suppressPackageStartupMessages(library(data.table))

parse_arguments <- function(arguments) {
  out <- list(data_root = PUBLIC_DATA_DIR, rank_root = RESULTS$importance,
              output_root = RESULTS$mrmr, tasks = c("AP", "CRC"),
              smoke = FALSE, resume = TRUE)
  for (argument in arguments) {
    if (argument == "--smoke") out$smoke <- TRUE
    else if (argument == "--no-resume") out$resume <- FALSE
    else if (grepl("^--data-root=", argument)) out$data_root <- sub("^--data-root=", "", argument)
    else if (grepl("^--rank-root=", argument)) out$rank_root <- sub("^--rank-root=", "", argument)
    else if (grepl("^--output-root=", argument)) out$output_root <- sub("^--output-root=", "", argument)
    else if (grepl("^--tasks=", argument)) out$tasks <- strsplit(sub("^--tasks=", "", argument), ",", fixed = TRUE)[[1]]
    else stop("Unknown argument: ", argument, call. = FALSE)
  }
  out$tasks <- toupper(trimws(out$tasks))
  assert_true(all(out$tasks %in% c("AP", "CRC")), "--tasks must contain AP and/or CRC")
  out
}

write_table <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  data.table::fwrite(x, path, sep = "\t", quote = FALSE, na = "NA")
}

load_inputs <- function(data_root, rank_root) {
  paths <- c(
    metadata = file.path(data_root, "metadata_filtered.txt"),
    taxonomy = file.path(data_root, "taxonomy_species.txt"),
    AP_rank = file.path(rank_root, "Adenoma_rank_Species.txt"),
    CRC_rank = file.path(rank_root, "CRC_rank_Species.txt")
  )
  assert_true(all(file.exists(paths)), paste("Missing input file(s):",
                                             paste(paths[!file.exists(paths)], collapse = ", ")))
  metadata <- as.data.frame(data.table::fread(paths[["metadata"]], sep = "\t", check.names = FALSE))
  assert_true(all(c("Sample_ID", "Project_ID", "Group") %in% names(metadata)),
              "metadata must contain Sample_ID, Project_ID and Group")
  assert_true(!anyDuplicated(metadata$Sample_ID), "metadata contains duplicated Sample_ID")
  ap_rank <- prepare_rank_table(as.data.frame(data.table::fread(paths[["AP_rank"]], sep = "\t")), 28L)
  crc_rank <- prepare_rank_table(as.data.frame(data.table::fread(paths[["CRC_rank"]], sep = "\t")), 28L)
  candidates <- unique(c(ap_rank$Variable, crc_rank$Variable))
  taxonomy <- as.data.frame(data.table::fread(
    paths[["taxonomy"]], sep = "\t", select = c("Taxonomy", metadata$Sample_ID),
    check.names = FALSE
  ))
  assert_true("Taxonomy" %in% names(taxonomy), "taxonomy table lacks Taxonomy column")
  assert_true(all(metadata$Sample_ID %in% names(taxonomy)),
              "one or more metadata samples are absent from taxonomy table")
  assert_true(!anyDuplicated(taxonomy$Taxonomy), "taxonomy table contains duplicated species")
  assert_true(all(candidates %in% taxonomy$Taxonomy), "ranked species are absent from taxonomy table")
  taxonomy <- taxonomy[match(candidates, taxonomy$Taxonomy), , drop = FALSE]
  abundance <- t(as.matrix(taxonomy[, metadata$Sample_ID, drop = FALSE]))
  storage.mode(abundance) <- "double"
  rownames(abundance) <- metadata$Sample_ID
  colnames(abundance) <- taxonomy$Taxonomy
  assert_true(all(is.finite(abundance)) && all(abundance >= 0),
              "candidate abundance contains missing, infinite or negative values")
  list(metadata = metadata, abundance = abundance,
       rank_tables = list(AP = ap_rank, CRC = crc_rank), paths = paths)
}

bind_repeat_results <- function(results, field) {
  do.call(rbind, lapply(results, `[[`, field))
}

aggregate_auc_table <- function(predictions, positive, negative = GROUP_HC) {
  averaged <- aggregate_oof_probabilities(predictions)
  rows <- lapply(sort(unique(averaged$K)), function(k) {
    z <- averaged[averaged$K == k, , drop = FALSE]
    data.frame(Task = unique(z$Task), K = k,
               AUC = safe_auc(z$Truth, z$Probability, positive, negative))
  })
  do.call(rbind, rows)
}


run_task <- function(task, inputs, config, output_root, resume) {
  positive <- if (task == "AP") GROUP_AP else GROUP_CRC
  negative <- GROUP_HC
  rank_table <- inputs$rank_tables[[task]]
  metadata <- inputs$metadata[inputs$metadata$Group %in% c(negative, positive), , drop = FALSE]
  metadata$Group <- factor(metadata$Group, levels = c(negative, positive))
  assert_true(nlevels(droplevels(metadata$Group)) == 2L,
              paste(task, "data do not contain both classes"))
  result_dir <- file.path(output_root, "02_results", task, "screening")
  object_dir <- file.path(output_root, "objects")
  checkpoint_dir <- file.path(object_dir, paste0(task, "_checkpoints"))
  log_dir <- file.path(output_root, "logs")
  invisible(lapply(c(result_dir, object_dir, checkpoint_dir, log_dir),
                   dir.create, recursive = TRUE, showWarnings = FALSE))
  outer_assignments <- make_repeated_balanced_project_folds(
    metadata, positive = positive, negative = negative, v = config$outer_v,
    repeats = config$outer_repeats, seed = config$base_seed,
    n_candidates = if (config$smoke) 100L else 1000L
  )
  signature <- list(task = task, candidates = rank_table$Variable,
                    sample_ids = metadata$Sample_ID, config = config,
                    outer_assignments = outer_assignments[
                      , c("Project_ID", "Fold", "Repeat"), drop = FALSE
                    ])
  repeat_results <- vector("list", config$outer_repeats)
  for (repeat_id in seq_len(config$outer_repeats)) {
    checkpoint <- file.path(checkpoint_dir, sprintf("%s_repeat_%02d.rds", task, repeat_id))
    if (resume && file.exists(checkpoint)) {
      saved <- readRDS(checkpoint)
      assert_true(isTRUE(all.equal(saved$signature, signature)),
                  paste("Checkpoint configuration mismatch:", checkpoint))
      repeat_results[[repeat_id]] <- saved$result
      message(task, " repeat ", repeat_id, " loaded from checkpoint")
    } else {
      outer_assignment <- outer_assignments[
        outer_assignments$Repeat == repeat_id, , drop = FALSE
      ]
      repeat_results[[repeat_id]] <- run_one_project_cv_repeat(
        task_name = task, metadata = metadata, abundance = inputs$abundance,
        rank_table = rank_table, positive = positive, negative = negative,
        k_values = config$k_values, outer_v = config$outer_v,
        inner_v = config$inner_v, repeat_id = repeat_id,
        base_seed = config$base_seed, alpha_grid = config$alpha_grid,
        outer_assignment = outer_assignment
      )
      saveRDS(list(signature = signature, result = repeat_results[[repeat_id]]), checkpoint)
    }
  }
  result <- lapply(c("fold_assignments", "rankings", "panels", "predictions",
                     "fold_auc", "tuning", "coefficients"),
                   function(field) bind_repeat_results(repeat_results, field))
  names(result) <- c("fold_assignments", "rankings", "panels", "predictions",
                     "fold_auc", "tuning", "coefficients")
  validate_repeated_project_partitions(
    result$fold_assignments,
    expected_repeats = config$outer_repeats,
    expected_folds = config$outer_v
  )
  result$repeat_auc <- calculate_repeat_auc(result$predictions, positive, negative)
  result$auc_summary <- summarise_auc_by_k(result$repeat_auc)
  result$aggregated_predictions <- aggregate_oof_probabilities(result$predictions)
  result$aggregated_auc <- aggregate_auc_table(result$predictions, positive, negative)
  result$pairwise_delong <- pairwise_delong_all_k(result$predictions, positive, negative)
  result$adjacent_delong <- adjacent_delong_table(result$pairwise_delong)
  result$selection_frequency <- build_selection_frequency_by_k(result$rankings,
                                                                 config$k_values)
  result$evidence <- build_species_evidence(rank_table, result$rankings,
                                             result$panels, result$coefficients)
  result$manual_template <- make_manual_decision_template(result$evidence)
  result$rank_table <- rank_table
  result$config <- config
  result$task <- task
  result$positive <- positive
  result$negative <- negative
  tables <- list(
    "01_candidate_pool.tsv" = rank_table,
    "02_outer_project_fold_assignments.tsv" = result$fold_assignments,
    "03_mrmr_complete_rankings.tsv" = result$rankings,
    "04_mrmr_panels_by_k.tsv" = result$panels,
    "05_outer_fold_predictions.tsv" = result$predictions,
    "06_outer_fold_auc.tsv" = result$fold_auc,
    "07_repeat_oof_auc.tsv" = result$repeat_auc,
    "08_auc_summary_by_k.tsv" = result$auc_summary,
    "09_averaged_oof_predictions.tsv" = result$aggregated_predictions,
    "10_averaged_oof_auc_by_k.tsv" = result$aggregated_auc,
    "11_all_pairwise_delong.tsv" = result$pairwise_delong,
    "12_adjacent_delong.tsv" = result$adjacent_delong,
    "13_species_selection_frequency_by_k.tsv" = result$selection_frequency,
    "14_elastic_net_tuning.tsv" = result$tuning,
    "15_elastic_net_coefficients.tsv" = result$coefficients,
    "16_species_evidence_matrix.tsv" = result$evidence,
    "17_manual_decision_template.tsv" = result$manual_template
  )
  for (name in names(tables)) write_table(tables[[name]], file.path(result_dir, name))
  saveRDS(result, file.path(object_dir, paste0(task, "_screening_complete.rds")))
  capture.output(sessionInfo(), file = file.path(log_dir, paste0(task, "_sessionInfo.txt")))
  message(task, " screening complete: ", normalizePath(result_dir))
  invisible(result)
}

arguments <- parse_arguments(commandArgs(trailingOnly = TRUE))
config <- if (arguments$smoke) {
  list(outer_v = 3L, outer_repeats = 1L, inner_v = 3L, k_values = 1:3,
       alpha_grid = c(.5, 1), base_seed = 20260805L, smoke = TRUE)
} else {
  list(outer_v = 5L, outer_repeats = 10L, inner_v = 4L, k_values = 1:28,
       alpha_grid = c(.10, .25, .50, .75, 1), base_seed = 20260805L, smoke = FALSE)
}
dir.create(arguments$output_root, recursive = TRUE, showWarnings = FALSE)
inputs <- load_inputs(arguments$data_root, arguments$rank_root)
invisible(lapply(arguments$tasks, run_task, inputs = inputs, config = config,
                 output_root = arguments$output_root, resume = arguments$resume))
