suppressWarnings(suppressPackageStartupMessages({
  library(mRMRe)
  library(glmnet)
  library(pROC)
}))

assert_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

prepare_rank_table <- function(rank_table, n_candidates = 28L) {
  required <- c("Variable", "mean_rank")
  assert_true(all(required %in% names(rank_table)),
              "rank table must contain Variable and mean_rank")
  assert_true(!anyDuplicated(rank_table$Variable), "rank table contains duplicated species")
  assert_true(all(is.finite(rank_table$mean_rank)), "mean_rank contains non-finite values")
  assert_true(nrow(rank_table) >= n_candidates, paste0("rank table must contain at least ",
                                                       n_candidates, " species"))
  out <- rank_table[order(rank_table$mean_rank, rank_table$Variable), , drop = FALSE]
  out <- out[seq_len(n_candidates), , drop = FALSE]
  out$Fixed_rank <- seq_len(n_candidates)
  rownames(out) <- NULL
  out
}

project_class_counts <- function(metadata, positive, negative = "HC") {
  x <- metadata[metadata$Group %in% c(negative, positive), , drop = FALSE]
  projects <- sort(unique(x$Project_ID))
  out <- data.frame(
    Project_ID = projects,
    N_positive = vapply(projects, function(p) sum(x$Project_ID == p & x$Group == positive), integer(1)),
    N_negative = vapply(projects, function(p) sum(x$Project_ID == p & x$Group == negative), integer(1))
  )
  out$N_total <- out$N_positive + out$N_negative
  out
}

make_balanced_project_folds <- function(metadata, positive, negative = "HC", v = 5L, seed = 1L) {
  counts <- project_class_counts(metadata, positive, negative)
  assert_true(nrow(counts) >= v, "fewer projects than folds")
  assert_true(sum(counts$N_positive > 0) >= v, "fewer positive-containing projects than folds")
  assert_true(sum(counts$N_negative > 0) >= v, "fewer negative-containing projects than folds")
  choose_one <- function(x) if (length(x) == 1L) x else sample(x, 1L)
  for (attempt in 0:999) {
    set.seed(as.integer(seed + attempt))
    assignment <- rep(NA_integer_, nrow(counts))
    fold_pos <- fold_neg <- fold_total <- numeric(v)
    fold_pos_projects <- integer(v)
    positive_idx <- sample(which(counts$N_positive > 0))
    positive_idx <- positive_idx[order(-counts$N_positive[positive_idx],
                                       -counts$N_total[positive_idx])]
    for (idx in positive_idx) {
      candidate <- which(fold_pos_projects == min(fold_pos_projects))
      candidate <- candidate[fold_pos[candidate] == min(fold_pos[candidate])]
      candidate <- candidate[fold_total[candidate] == min(fold_total[candidate])]
      chosen <- choose_one(candidate)
      assignment[idx] <- chosen
      fold_pos_projects[chosen] <- fold_pos_projects[chosen] + 1L
      fold_pos[chosen] <- fold_pos[chosen] + counts$N_positive[idx]
      fold_neg[chosen] <- fold_neg[chosen] + counts$N_negative[idx]
      fold_total[chosen] <- fold_total[chosen] + counts$N_total[idx]
    }
    remaining <- which(is.na(assignment))
    if (length(remaining)) {
      remaining <- sample(remaining)
      remaining <- remaining[order(-counts$N_total[remaining])]
      for (idx in remaining) {
        candidate <- which(fold_total == min(fold_total))
        chosen <- choose_one(candidate)
        assignment[idx] <- chosen
        fold_pos[chosen] <- fold_pos[chosen] + counts$N_positive[idx]
        fold_neg[chosen] <- fold_neg[chosen] + counts$N_negative[idx]
        fold_total[chosen] <- fold_total[chosen] + counts$N_total[idx]
      }
    }
    result <- data.frame(Project_ID = counts$Project_ID, Fold = assignment,
                         Seed = as.integer(seed), Attempt = attempt)
    if (all(fold_pos > 0) && all(fold_neg > 0)) {
      check_project_folds(metadata, result, positive, negative)
      return(result[order(result$Project_ID), , drop = FALSE])
    }
  }
  stop("unable to construct class-balanced project folds", call. = FALSE)
}

canonicalize_project_fold_labels <- function(assignment) {
  fold_sets <- vapply(sort(unique(assignment$Fold)), function(fold) {
    paste(sort(as.character(assignment$Project_ID[assignment$Fold == fold])),
          collapse = ",")
  }, character(1))
  old_labels <- sort(unique(assignment$Fold))[order(fold_sets)]
  assignment$Fold <- match(assignment$Fold, old_labels)
  assignment
}

canonical_project_partition_signature <- function(assignment) {
  assignment <- canonicalize_project_fold_labels(assignment)
  fold_sets <- vapply(sort(unique(assignment$Fold)), function(fold) {
    paste(sort(as.character(assignment$Project_ID[assignment$Fold == fold])),
          collapse = ",")
  }, character(1))
  paste(sort(fold_sets), collapse = "|")
}

validate_repeated_project_partitions <- function(
    assignments, expected_repeats = 10L, expected_folds = 5L) {
  required <- c("Project_ID", "Fold", "Repeat")
  assert_true(all(required %in% names(assignments)),
              "repeated fold assignments lack Project_ID, Fold or Repeat")
  repeats <- sort(unique(as.integer(assignments$Repeat)))
  assert_true(identical(repeats, seq_len(as.integer(expected_repeats))),
              paste0("expected ", expected_repeats, " repeated project partitions"))
  project_sets <- vector("list", length(repeats))
  signatures <- character(length(repeats))
  for (i in seq_along(repeats)) {
    z <- assignments[assignments$Repeat == repeats[i], , drop = FALSE]
    assert_true(!anyDuplicated(z$Project_ID),
                "a Project_ID occurs more than once within a repeat")
    assert_true(length(unique(z$Fold)) == as.integer(expected_folds),
                paste0("each repeat must contain ", expected_folds, " folds"))
    project_sets[[i]] <- sort(as.character(z$Project_ID))
    signatures[i] <- canonical_project_partition_signature(z)
  }
  assert_true(all(vapply(project_sets[-1], identical, logical(1), project_sets[[1]])),
              "repeats do not contain the same Project_ID set")
  assert_true(length(unique(signatures)) == length(signatures),
              "repeated CV contains equivalent project partitions that differ only by fold labels")
  TRUE
}

project_partition_balance_score <- function(counts, fold, v) {
  fold_positive <- vapply(seq_len(v), function(f) {
    sum(counts$N_positive[fold == f])
  }, numeric(1))
  fold_negative <- vapply(seq_len(v), function(f) {
    sum(counts$N_negative[fold == f])
  }, numeric(1))
  fold_total <- vapply(seq_len(v), function(f) {
    sum(counts$N_total[fold == f])
  }, numeric(1))
  target_positive <- sum(counts$N_positive) / v
  target_negative <- sum(counts$N_negative) / v
  target_total <- sum(counts$N_total) / v
  sum(((fold_positive - target_positive) / max(target_positive, 1))^2) +
    sum(((fold_negative - target_negative) / max(target_negative, 1))^2) +
    0.25 * sum(((fold_total - target_total) / max(target_total, 1))^2)
}

make_repeated_balanced_project_folds <- function(
    metadata, positive, negative = "HC", v = 5L, repeats = 10L,
    seed = 1L, n_candidates = 1000L) {
  v <- as.integer(v)
  repeats <- as.integer(repeats)
  n_candidates <- as.integer(n_candidates)
  assert_true(repeats >= 1L, "number of repeats must be positive")
  assert_true(n_candidates >= 1L, "n_candidates must be positive")
  counts <- project_class_counts(metadata, positive, negative)
  base <- canonicalize_project_fold_labels(
    make_balanced_project_folds(metadata, positive, negative, v, seed)
  )
  fold_sizes <- tabulate(base$Fold, nbins = v)
  fold_slots <- rep(seq_len(v), fold_sizes)
  results <- vector("list", repeats)
  signatures <- character(0)

  for (repeat_id in seq_len(repeats)) {
    best <- NULL
    best_score <- Inf
    if (repeat_id == 1L) {
      best <- base
      best_score <- project_partition_balance_score(counts, best$Fold, v)
    }
    for (candidate_id in seq_len(n_candidates)) {
      set.seed(as.integer(seed + repeat_id * 100000L + candidate_id))
      candidate <- data.frame(
        Project_ID = counts$Project_ID,
        Fold = sample(fold_slots, length(fold_slots), replace = FALSE),
        Seed = as.integer(seed + repeat_id * 100000L + candidate_id),
        Attempt = candidate_id
      )
      fold_positive <- vapply(seq_len(v), function(f) {
        sum(counts$N_positive[candidate$Fold == f])
      }, numeric(1))
      fold_negative <- vapply(seq_len(v), function(f) {
        sum(counts$N_negative[candidate$Fold == f])
      }, numeric(1))
      if (any(fold_positive == 0) || any(fold_negative == 0)) next
      candidate <- canonicalize_project_fold_labels(candidate)
      signature <- canonical_project_partition_signature(candidate)
      if (signature %in% signatures) next
      score <- project_partition_balance_score(counts, candidate$Fold, v)
      if (score < best_score) {
        best <- candidate
        best_score <- score
      }
    }
    assert_true(!is.null(best), paste0(
      "unable to generate unique balanced project partition for repeat ", repeat_id
    ))
    best$Repeat <- repeat_id
    best$Balance_score <- best_score
    best <- best[order(best$Project_ID), , drop = FALSE]
    results[[repeat_id]] <- best
    signatures <- c(signatures, canonical_project_partition_signature(best))
  }
  out <- do.call(rbind, results)
  rownames(out) <- NULL
  validate_repeated_project_partitions(out, repeats, v)
  invisible(lapply(split(out, out$Repeat), function(z) {
    check_project_folds(metadata, z, positive, negative)
  }))
  out
}

check_project_folds <- function(metadata, assignment, positive, negative = "HC") {
  assert_true(!anyDuplicated(assignment$Project_ID), "Project_ID assigned more than once")
  joined <- merge(metadata, assignment[, c("Project_ID", "Fold")],
                  by = "Project_ID", all.x = TRUE)
  assert_true(!anyNA(joined$Fold), "one or more projects are unassigned")
  valid <- vapply(split(joined$Group, joined$Fold),
                  function(z) all(c(negative, positive) %in% z), logical(1))
  assert_true(all(valid), "an outer or inner fold lacks one class")
  TRUE
}

fit_preprocessor <- function(train_matrix) {
  x <- as.matrix(train_matrix)
  assert_true(!is.null(colnames(x)), "abundance matrix lacks species names")
  assert_true(all(is.finite(x)) && all(x >= 0), "abundance must be finite and nonnegative")
  nonzero <- x[x > 0]
  assert_true(length(nonzero) > 0L, "training abundance contains no nonzero value")
  pseudocount <- min(nonzero) / 2
  logged <- log2(x + pseudocount)
  means <- colMeans(logged)
  sds <- apply(logged, 2, stats::sd)
  zero_variance <- names(sds)[!is.finite(sds) | sds <= .Machine$double.eps]
  list(pseudocount = pseudocount, means = means, sds = sds,
       zero_variance = zero_variance, feature_order = colnames(x))
}

apply_preprocessor <- function(matrix, preprocessor, allow_subset = FALSE) {
  x <- as.matrix(matrix)
  requested <- colnames(x)
  if (allow_subset) {
    assert_true(all(requested %in% preprocessor$feature_order), "preprocessor feature mismatch")
    features <- requested
  } else {
    assert_true(all(preprocessor$feature_order %in% requested), "preprocessor feature mismatch")
    features <- preprocessor$feature_order
  }
  x <- x[, features, drop = FALSE]
  logged <- log2(x + preprocessor$pseudocount)
  z <- sweep(logged, 2, preprocessor$means[features], "-")
  safe_sds <- preprocessor$sds[features]
  safe_sds[!is.finite(safe_sds) | safe_sds <= .Machine$double.eps] <- 1
  z <- sweep(z, 2, safe_sds, "/")
  zero <- intersect(features, preprocessor$zero_variance)
  if (length(zero)) z[, zero] <- 0
  storage.mode(z) <- "double"
  z
}

run_mrmr_complete_ranking <- function(train_z, y, positive, seed = 1L) {
  x <- as.matrix(train_z)
  candidates <- colnames(x)
  assert_true(length(candidates) > 0L && !anyDuplicated(candidates),
              "mRMR candidate names are missing or duplicated")
  assert_true(nrow(x) == length(y), "mRMR outcome length mismatch")
  sds <- apply(x, 2, stats::sd)
  valid <- candidates[is.finite(sds) & sds > .Machine$double.eps]
  zero_variance <- setdiff(candidates, valid)
  assert_true(length(valid) > 0L, "all mRMR candidates have zero variance")
  frame <- data.frame(target = as.numeric(y == positive), x[, valid, drop = FALSE],
                      check.names = FALSE)
  frame[] <- lapply(frame, as.numeric)
  set.seed(as.integer(seed))
  data_object <- mRMRe::mRMR.data(data = frame)
  fit <- mRMRe::mRMR.classic(data = data_object, target_indices = 1,
                             feature_count = length(valid))
  indices <- as.integer(mRMRe::solutions(fit)[[1]][, 1])
  species <- names(frame)[indices]
  raw_scores <- as.numeric(mRMRe::scores(fit)[[1]][, 1])
  assert_true(length(species) == length(valid) && length(raw_scores) == length(valid),
              "mRMR solution and score length mismatch")
  percentile <- rank(raw_scores, ties.method = "average") / length(raw_scores)
  out <- data.frame(
    Species = c(species, zero_variance),
    MRMR_rank = seq_along(c(species, zero_variance)),
    MRMR_score = c(raw_scores, rep(NA_real_, length(zero_variance))),
    Score_percentile = c(percentile, rep(NA_real_, length(zero_variance))),
    Zero_variance = c(rep(FALSE, length(species)), rep(TRUE, length(zero_variance)))
  )
  assert_true(nrow(out) == length(candidates), "mRMR ranking length mismatch")
  assert_true(!anyDuplicated(out$Species) && setequal(out$Species, candidates),
              "mRMR ranking is not a complete candidate permutation")
  out
}

species_for_k <- function(ranking, k) {
  k <- as.integer(k)
  assert_true(length(k) == 1L && k >= 1L && k <= nrow(ranking),
              "K is outside the mRMR ranking range")
  ranking$Species[seq_len(k)]
}

make_inner_foldid <- function(y, projects, positive, negative = "HC",
                              max_v = 4L, seed = 1L) {
  metadata <- data.frame(Sample_ID = seq_along(y), Project_ID = projects, Group = y)
  counts <- project_class_counts(metadata, positive, negative)
  v <- min(as.integer(max_v), nrow(counts), sum(counts$N_positive > 0),
           sum(counts$N_negative > 0))
  assert_true(v >= 3L, paste0(
    "fewer than three feasible grouped inner folds: projects=", nrow(counts),
    ", positive_projects=", sum(counts$N_positive > 0),
    ", negative_projects=", sum(counts$N_negative > 0)
  ))
  assignment <- make_balanced_project_folds(metadata, positive, negative, v, seed)
  assignment$Fold[match(projects, assignment$Project_ID)]
}

fit_predict_elastic_net <- function(train_x, train_y, train_projects, test_x,
                                    positive, negative = "HC", inner_v = 4L,
                                    seed = 1L,
                                    alpha_grid = c(.10, .25, .50, .75, 1)) {
  train_x <- as.matrix(train_x)
  test_x <- as.matrix(test_x)
  assert_true(nrow(train_x) == length(train_y) && length(train_y) == length(train_projects),
              "elastic-net training dimensions do not match")
  assert_true(identical(colnames(train_x), colnames(test_x)),
              "elastic-net train/test features do not match")
  if (ncol(train_x) == 1L) {
    train_x <- cbind(train_x, .glmnet_zero_placeholder = 0)
    test_x <- cbind(test_x, .glmnet_zero_placeholder = 0)
  }
  alphas <- sort(unique(alpha_grid[is.finite(alpha_grid) & alpha_grid > 0 & alpha_grid <= 1]))
  assert_true(length(alphas) > 0L, "elastic-net alpha grid is empty")
  foldid <- make_inner_foldid(train_y, train_projects, positive, negative, inner_v, seed)
  y01 <- as.integer(train_y == positive)
  cv_fits <- lapply(alphas, function(alpha) {
    set.seed(as.integer(seed + round(alpha * 1000)))
    glmnet::cv.glmnet(
      x = train_x, y = y01, family = "binomial", alpha = alpha,
      foldid = foldid, type.measure = "auc", standardize = FALSE
    )
  })
  inner_auc <- vapply(cv_fits, function(fit) max(fit$cvm, na.rm = TRUE), numeric(1))
  chosen <- which.max(inner_auc)
  alpha <- alphas[chosen]
  lambda <- cv_fits[[chosen]]$lambda.min
  final_fit <- glmnet::glmnet(
    x = train_x, y = y01, family = "binomial", alpha = alpha,
    lambda = lambda, standardize = FALSE
  )
  probability <- as.numeric(stats::predict(final_fit, newx = test_x, type = "response"))
  beta <- as.matrix(stats::coef(final_fit, s = lambda))[, 1]
  coefficients <- data.frame(
    Term = names(beta), Coefficient = as.numeric(beta),
    Nonzero = abs(as.numeric(beta)) > 1e-12
  )
  coefficients <- coefficients[coefficients$Term != ".glmnet_zero_placeholder", , drop = FALSE]
  list(
    probability = probability, alpha = alpha, lambda = lambda,
    inner_auc = inner_auc[chosen], inner_folds = max(foldid),
    nonzero_count = sum(coefficients$Nonzero & coefficients$Term != "(Intercept)"),
    coefficients = coefficients
  )
}

safe_auc <- function(truth, probability, positive, negative = "HC") {
  keep <- is.finite(probability) & truth %in% c(negative, positive)
  if (sum(keep) < 2L || length(unique(truth[keep])) < 2L) return(NA_real_)
  as.numeric(pROC::auc(pROC::roc(
    response = factor(truth[keep], levels = c(negative, positive)),
    predictor = probability[keep], levels = c(negative, positive),
    direction = "<", quiet = TRUE
  )))
}

run_one_project_cv_repeat <- function(task_name, metadata, abundance, rank_table,
                                      positive, negative = "HC", k_values = 1:28,
                                      outer_v = 5L, inner_v = 4L, repeat_id = 1L,
                                      base_seed = 20260805L,
                                      alpha_grid = c(.10, .25, .50, .75, 1),
                                      outer_assignment = NULL,
                                      progress = message) {
  required_meta <- c("Sample_ID", "Project_ID", "Group")
  assert_true(all(required_meta %in% names(metadata)), "metadata lacks required columns")
  candidates <- rank_table$Variable
  assert_true(length(candidates) == 28L, "mRMR candidate pool must contain 28 species")
  assert_true(all(metadata$Sample_ID %in% rownames(abundance)),
              "one or more metadata samples are absent from abundance")
  assert_true(all(candidates %in% colnames(abundance)),
              "one or more candidates are absent from abundance")
  k_values <- sort(unique(as.integer(k_values)))
  assert_true(length(k_values) > 0L && min(k_values) >= 1L && max(k_values) <= 28L,
              "K values must lie in 1:28")
  abundance <- as.matrix(abundance[metadata$Sample_ID, candidates, drop = FALSE])
  assignment <- if (is.null(outer_assignment)) {
    make_balanced_project_folds(
      metadata, positive, negative, outer_v, base_seed + repeat_id * 10000L
    )
  } else {
    outer_assignment
  }
  check_project_folds(metadata, assignment, positive, negative)
  assert_true(length(unique(assignment$Fold)) == outer_v,
              "outer assignment fold count does not match outer_v")
  assignment$Task <- task_name
  assignment$Repeat <- repeat_id
  ranking_rows <- panel_rows <- prediction_rows <- auc_rows <- tuning_rows <- coefficient_rows <- list()
  ri <- pi <- pri <- ai <- ti <- ci <- 0L
  for (fold in seq_len(outer_v)) {
    test_projects <- assignment$Project_ID[assignment$Fold == fold]
    test_idx <- metadata$Project_ID %in% test_projects
    train_idx <- !test_idx
    train_raw <- abundance[train_idx, , drop = FALSE]
    test_raw <- abundance[test_idx, , drop = FALSE]
    prep <- fit_preprocessor(train_raw)
    train_z <- apply_preprocessor(train_raw, prep)
    test_z <- apply_preprocessor(test_raw, prep)
    ranking <- run_mrmr_complete_ranking(
      train_z, metadata$Group[train_idx], positive,
      seed = base_seed + repeat_id * 100000L + fold * 1000L
    )
    ranking$Task <- task_name
    ranking$Repeat <- repeat_id
    ranking$Fold <- fold
    ri <- ri + 1L
    ranking_rows[[ri]] <- ranking
    for (k in k_values) {
      species <- species_for_k(ranking, k)
      selected_ranking <- ranking[seq_len(k),
                                  c("Species", "MRMR_rank", "MRMR_score",
                                    "Score_percentile", "Zero_variance")]
      selected_ranking$Task <- task_name
      selected_ranking$Repeat <- repeat_id
      selected_ranking$Fold <- fold
      selected_ranking$K <- k
      pi <- pi + 1L
      panel_rows[[pi]] <- selected_ranking
      fit <- fit_predict_elastic_net(
        train_z[, species, drop = FALSE], metadata$Group[train_idx],
        metadata$Project_ID[train_idx], test_z[, species, drop = FALSE],
        positive, negative, inner_v,
        seed = base_seed + repeat_id * 1000000L + fold * 10000L + k * 100L,
        alpha_grid = alpha_grid
      )
      pri <- pri + 1L
      prediction_rows[[pri]] <- data.frame(
        Task = task_name, Sample_ID = metadata$Sample_ID[test_idx],
        Project_ID = metadata$Project_ID[test_idx], Truth = metadata$Group[test_idx],
        Repeat = repeat_id, Fold = fold, K = k, Probability = fit$probability
      )
      ai <- ai + 1L
      auc_rows[[ai]] <- data.frame(
        Task = task_name, Repeat = repeat_id, Fold = fold, K = k,
        AUC = safe_auc(metadata$Group[test_idx], fit$probability, positive, negative)
      )
      ti <- ti + 1L
      tuning_rows[[ti]] <- data.frame(
        Task = task_name, Repeat = repeat_id, Fold = fold, K = k,
        Alpha = fit$alpha, Lambda = fit$lambda, Inner_AUC = fit$inner_auc,
        Inner_folds = fit$inner_folds, Nonzero_count = fit$nonzero_count
      )
      coef <- fit$coefficients
      coef$Task <- task_name
      coef$Repeat <- repeat_id
      coef$Fold <- fold
      coef$K <- k
      ci <- ci + 1L
      coefficient_rows[[ci]] <- coef
    }
    progress(task_name, " repeat ", repeat_id, ", fold ", fold, "/", outer_v, " complete")
  }
  list(
    fold_assignments = assignment,
    rankings = do.call(rbind, ranking_rows),
    panels = do.call(rbind, panel_rows),
    predictions = do.call(rbind, prediction_rows),
    fold_auc = do.call(rbind, auc_rows),
    tuning = do.call(rbind, tuning_rows),
    coefficients = do.call(rbind, coefficient_rows)
  )
}

calculate_repeat_auc <- function(predictions, positive, negative = "HC") {
  keys <- unique(predictions[, c("Task", "Repeat", "K")])
  do.call(rbind, lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, ]
    z <- predictions[predictions$Task == key$Task & predictions$Repeat == key$Repeat &
                       predictions$K == key$K, , drop = FALSE]
    data.frame(key, AUC = safe_auc(z$Truth, z$Probability, positive, negative))
  }))
}

summarise_auc_by_k <- function(repeat_auc) {
  keys <- unique(repeat_auc[, c("Task", "K")])
  do.call(rbind, lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, ]
    values <- repeat_auc$AUC[repeat_auc$Task == key$Task & repeat_auc$K == key$K]
    values <- values[is.finite(values)]
    n <- length(values)
    mean_auc <- if (n) mean(values) else NA_real_
    sd_auc <- if (n > 1L) stats::sd(values) else NA_real_
    se_auc <- if (n > 1L) sd_auc / sqrt(n) else NA_real_
    critical <- if (n > 1L) stats::qt(.975, n - 1L) else NA_real_
    data.frame(
      key, N_repeats = n, Mean_AUC = mean_auc, SD_AUC = sd_auc, SE_AUC = se_auc,
      CI_low = if (n > 1L) max(0, mean_auc - critical * se_auc) else NA_real_,
      CI_high = if (n > 1L) min(1, mean_auc + critical * se_auc) else NA_real_
    )
  }))
}

aggregate_oof_probabilities <- function(predictions) {
  aggregate(Probability ~ Task + Sample_ID + Truth + K, predictions, mean)
}

pairwise_delong_all_k <- function(predictions, positive, negative = "HC") {
  averaged <- aggregate_oof_probabilities(predictions)
  task_rows <- list(); task_index <- 0L
  for (task in unique(averaged$Task)) {
    task_data <- averaged[averaged$Task == task, , drop = FALSE]
    ks <- sort(unique(task_data$K))
    pairs <- utils::combn(ks, 2)
    rows <- vector("list", ncol(pairs))
    for (i in seq_len(ncol(pairs))) {
      k_low <- pairs[1, i]; k_high <- pairs[2, i]
      low <- task_data[task_data$K == k_low,
                       c("Sample_ID", "Truth", "Probability")]
      high <- task_data[task_data$K == k_high, c("Sample_ID", "Probability")]
      names(low)[3] <- "Probability_low"
      names(high)[2] <- "Probability_high"
      paired <- merge(low, high, by = "Sample_ID")
      auc_low <- safe_auc(paired$Truth, paired$Probability_low, positive, negative)
      auc_high <- safe_auc(paired$Truth, paired$Probability_high, positive, negative)
      roc_low <- pROC::roc(
        factor(paired$Truth, levels = c(negative, positive)), paired$Probability_low,
        levels = c(negative, positive), direction = "<", quiet = TRUE
      )
      roc_high <- pROC::roc(
        factor(paired$Truth, levels = c(negative, positive)), paired$Probability_high,
        levels = c(negative, positive), direction = "<", quiet = TRUE
      )
      p_value <- tryCatch(
        as.numeric(pROC::roc.test(roc_low, roc_high, paired = TRUE, method = "delong")$p.value),
        error = function(e) NA_real_
      )
      rows[[i]] <- data.frame(
        Task = task, K_low = k_low, K_high = k_high,
        AUC_low = auc_low, AUC_high = auc_high,
        Delta_AUC_high_minus_low = auc_high - auc_low,
        DeLong_P = p_value
      )
    }
    out <- do.call(rbind, rows)
    out$BH_q <- stats::p.adjust(out$DeLong_P, method = "BH")
    task_index <- task_index + 1L
    task_rows[[task_index]] <- out
  }
  do.call(rbind, task_rows)
}

adjacent_delong_table <- function(pairwise_table) {
  pairwise_table[pairwise_table$K_high - pairwise_table$K_low == 1L, , drop = FALSE]
}

build_selection_frequency_by_k <- function(rankings, k_values = 1:28) {
  species <- sort(unique(rankings$Species))
  total_folds <- nrow(unique(rankings[, c("Task", "Repeat", "Fold")]))
  rows <- lapply(species, function(s) {
    ranks <- rankings$MRMR_rank[rankings$Species == s]
    data.frame(
      Species = s, K = as.integer(k_values),
      Selection_frequency = vapply(k_values, function(k) mean(ranks <= k), numeric(1)),
      N_selected_folds = vapply(k_values, function(k) sum(ranks <= k), integer(1)),
      N_total_folds = total_folds
    )
  })
  do.call(rbind, rows)
}

safe_mean <- function(x) if (any(is.finite(x))) mean(x[is.finite(x)]) else NA_real_
safe_median <- function(x) if (any(is.finite(x))) stats::median(x[is.finite(x)]) else NA_real_
safe_sd <- function(x) if (sum(is.finite(x)) > 1L) stats::sd(x[is.finite(x)]) else NA_real_
safe_iqr <- function(x) if (any(is.finite(x))) stats::IQR(x[is.finite(x)]) else NA_real_

build_species_evidence <- function(rank_table, rankings, panels, coefficients,
                                   focus_k = c(8L, 10L)) {
  total_folds <- nrow(unique(rankings[, c("Task", "Repeat", "Fold")]))
  evidence <- data.frame(
    Species = rank_table$Variable,
    Original_fixed_rank = rank_table$Fixed_rank,
    Original_mean_rank = rank_table$mean_rank
  )
  optional_original <- setdiff(names(rank_table), c("Variable", "Fixed_rank", "mean_rank"))
  for (field in optional_original) evidence[[paste0("Original_", field)]] <- rank_table[[field]]
  rank_summary <- lapply(evidence$Species, function(species) {
    z <- rankings[rankings$Species == species, , drop = FALSE]
    data.frame(
      Species = species,
      MRMR_mean_rank = safe_mean(z$MRMR_rank),
      MRMR_median_rank = safe_median(z$MRMR_rank),
      MRMR_sd_rank = safe_sd(z$MRMR_rank),
      MRMR_IQR_rank = safe_iqr(z$MRMR_rank),
      MRMR_mean_score = safe_mean(z$MRMR_score),
      MRMR_median_score = safe_median(z$MRMR_score),
      MRMR_mean_score_percentile = safe_mean(z$Score_percentile),
      MRMR_median_score_percentile = safe_median(z$Score_percentile),
      Top8_frequency = mean(z$MRMR_rank <= 8L),
      Top10_frequency = mean(z$MRMR_rank <= 10L)
    )
  })
  rank_summary <- do.call(rbind, rank_summary)
  evidence <- merge(evidence, rank_summary, by = "Species", sort = FALSE)
  evidence <- evidence[match(rank_table$Variable, evidence$Species), , drop = FALSE]
  for (k in as.integer(focus_k)) {
    prefix <- paste0("K", k, "_")
    overall_nonzero <- conditional_nonzero <- median_abs <- positive_frequency <-
      direction_consistency <- rep(NA_real_, nrow(evidence))
    dominant_direction <- rep(NA_character_, nrow(evidence))
    for (i in seq_len(nrow(evidence))) {
      species <- evidence$Species[i]
      selected <- panels[panels$K == k & panels$Species == species,
                         c("Task", "Repeat", "Fold"), drop = FALSE]
      coef <- coefficients[coefficients$K == k & coefficients$Term == species, , drop = FALSE]
      n_nonzero <- sum(coef$Nonzero, na.rm = TRUE)
      overall_nonzero[i] <- n_nonzero / total_folds
      conditional_nonzero[i] <- if (nrow(selected)) n_nonzero / nrow(selected) else NA_real_
      nonzero_values <- coef$Coefficient[coef$Nonzero & is.finite(coef$Coefficient)]
      median_abs[i] <- if (length(nonzero_values)) stats::median(abs(nonzero_values)) else NA_real_
      if (length(nonzero_values)) {
        positive_frequency[i] <- mean(nonzero_values > 0)
        dominant_direction[i] <- if (positive_frequency[i] >= .5) "Positive" else "Negative"
        direction_consistency[i] <- max(positive_frequency[i], 1 - positive_frequency[i])
      }
    }
    evidence[[paste0(prefix, "overall_nonzero_frequency")]] <- overall_nonzero
    evidence[[paste0(prefix, "conditional_nonzero_frequency")]] <- conditional_nonzero
    evidence[[paste0(prefix, "median_abs_nonzero_coefficient")]] <- median_abs
    evidence[[paste0(prefix, "positive_coefficient_frequency")]] <- positive_frequency
    evidence[[paste0(prefix, "dominant_direction")]] <- dominant_direction
    evidence[[paste0(prefix, "direction_consistency")]] <- direction_consistency
  }
  evidence
}

make_manual_decision_template <- function(evidence) {
  data.frame(
    Species = evidence$Species,
    Include = NA,
    Manual_priority = NA,
    Literature_support = "",
    PCR_feasibility = "",
    Biological_rationale = "",
    Reviewer = "",
    Notes = "",
    check.names = FALSE
  )
}

parse_include_values <- function(x) {
  if (is.logical(x)) return(x)
  values <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(values))
  out[values %in% c("TRUE", "1")] <- TRUE
  out[values %in% c("FALSE", "0")] <- FALSE
  assert_true(!anyNA(out), "Include must contain only TRUE/FALSE or 1/0")
  out
}

read_manual_panel <- function(decision, rank_table) {
  if (is.character(decision) && length(decision) == 1L) {
    assert_true(file.exists(decision), "manual decision file does not exist")
    decision <- as.data.frame(data.table::fread(decision, sep = "\t", check.names = FALSE))
  }
  assert_true(is.data.frame(decision), "manual decision input must be a table or file path")
  assert_true(all(c("Species", "Include") %in% names(decision)),
              "manual decision table must contain Species and Include")
  assert_true(!anyDuplicated(decision$Species), "manual decision table contains duplicate species")
  assert_true(all(decision$Species %in% rank_table$Variable),
              "manual decision table contains species outside the candidate pool")
  include <- parse_include_values(decision$Include)
  assert_true(any(include), "manual decision table must include at least one species")
  selected <- decision[include, , drop = FALSE]
  selected$Include <- TRUE
  selected$Original_fixed_rank <- rank_table$Fixed_rank[match(selected$Species, rank_table$Variable)]
  selected$Original_mean_rank <- rank_table$mean_rank[match(selected$Species, rank_table$Variable)]
  if ("Manual_priority" %in% names(selected)) {
    priority <- suppressWarnings(as.numeric(selected$Manual_priority))
    selected <- selected[order(is.na(priority), priority, selected$Original_fixed_rank), , drop = FALSE]
  } else {
    selected <- selected[order(selected$Original_fixed_rank), , drop = FALSE]
  }
  rownames(selected) <- NULL
  selected
}

run_fixed_manual_panel_cv <- function(task_name, metadata, abundance, panel,
                                      fold_assignments, positive, negative = "HC",
                                      inner_v = 4L, base_seed = 20260805L,
                                      alpha_grid = c(.10, .25, .50, .75, 1),
                                      progress = message) {
  species <- panel$Species
  k <- length(species)
  assert_true(k >= 1L && all(species %in% colnames(abundance)),
              "manual panel species are absent from abundance")
  abundance <- as.matrix(abundance[metadata$Sample_ID, species, drop = FALSE])
  repeats <- sort(unique(fold_assignments$Repeat))
  prediction_rows <- auc_rows <- tuning_rows <- coefficient_rows <- list()
  pi <- ai <- ti <- ci <- 0L
  for (repeat_id in repeats) {
    assignment <- fold_assignments[fold_assignments$Repeat == repeat_id, , drop = FALSE]
    check_project_folds(metadata, assignment, positive, negative)
    for (fold in sort(unique(assignment$Fold))) {
      test_projects <- assignment$Project_ID[assignment$Fold == fold]
      test_idx <- metadata$Project_ID %in% test_projects
      train_idx <- !test_idx
      prep <- fit_preprocessor(abundance[train_idx, , drop = FALSE])
      train_z <- apply_preprocessor(abundance[train_idx, , drop = FALSE], prep)
      test_z <- apply_preprocessor(abundance[test_idx, , drop = FALSE], prep)
      fit <- fit_predict_elastic_net(
        train_z, metadata$Group[train_idx], metadata$Project_ID[train_idx], test_z,
        positive, negative, inner_v,
        seed = base_seed + repeat_id * 1000000L + fold * 10000L + k * 100L,
        alpha_grid = alpha_grid
      )
      pi <- pi + 1L
      prediction_rows[[pi]] <- data.frame(
        Task = task_name, Sample_ID = metadata$Sample_ID[test_idx],
        Project_ID = metadata$Project_ID[test_idx], Truth = metadata$Group[test_idx],
        Repeat = repeat_id, Fold = fold, K = k, Probability = fit$probability
      )
      ai <- ai + 1L
      auc_rows[[ai]] <- data.frame(
        Task = task_name, Repeat = repeat_id, Fold = fold, K = k,
        AUC = safe_auc(metadata$Group[test_idx], fit$probability, positive, negative)
      )
      ti <- ti + 1L
      tuning_rows[[ti]] <- data.frame(
        Task = task_name, Repeat = repeat_id, Fold = fold, K = k,
        Alpha = fit$alpha, Lambda = fit$lambda, Inner_AUC = fit$inner_auc,
        Inner_folds = fit$inner_folds, Nonzero_count = fit$nonzero_count
      )
      coef <- fit$coefficients
      coef$Task <- task_name; coef$Repeat <- repeat_id; coef$Fold <- fold; coef$K <- k
      ci <- ci + 1L
      coefficient_rows[[ci]] <- coef
    }
    progress(task_name, " manual panel repeat ", repeat_id, " complete")
  }
  predictions <- do.call(rbind, prediction_rows)
  repeat_auc <- calculate_repeat_auc(predictions, positive, negative)
  list(
    panel = panel, predictions = predictions,
    fold_auc = do.call(rbind, auc_rows), repeat_auc = repeat_auc,
    auc_summary = summarise_auc_by_k(repeat_auc),
    tuning = do.call(rbind, tuning_rows),
    coefficients = do.call(rbind, coefficient_rows)
  )
}

compare_manual_with_mrmr <- function(manual_predictions, mrmr_predictions,
                                     positive, negative = "HC") {
  manual_avg <- aggregate(Probability ~ Sample_ID + Truth, manual_predictions, mean)
  mrmr_avg <- aggregate(Probability ~ Sample_ID + Truth, mrmr_predictions, mean)
  names(manual_avg)[3] <- "Manual_probability"
  names(mrmr_avg)[3] <- "MRMR_probability"
  paired <- merge(manual_avg, mrmr_avg, by = c("Sample_ID", "Truth"))
  manual_auc <- safe_auc(paired$Truth, paired$Manual_probability, positive, negative)
  mrmr_auc <- safe_auc(paired$Truth, paired$MRMR_probability, positive, negative)
  roc_manual <- pROC::roc(factor(paired$Truth, levels = c(negative, positive)),
                          paired$Manual_probability, levels = c(negative, positive),
                          direction = "<", quiet = TRUE)
  roc_mrmr <- pROC::roc(factor(paired$Truth, levels = c(negative, positive)),
                        paired$MRMR_probability, levels = c(negative, positive),
                        direction = "<", quiet = TRUE)
  p_value <- tryCatch(
    as.numeric(pROC::roc.test(roc_manual, roc_mrmr, paired = TRUE, method = "delong")$p.value),
    error = function(e) NA_real_
  )
  aggregate_result <- data.frame(
    Manual_AUC = manual_auc, MRMR_AUC = mrmr_auc,
    Delta_AUC_manual_minus_mrmr = manual_auc - mrmr_auc,
    DeLong_P = p_value
  )
  repeats <- intersect(unique(manual_predictions$Repeat), unique(mrmr_predictions$Repeat))
  repeat_rows <- lapply(repeats, function(r) {
    m1 <- manual_predictions[manual_predictions$Repeat == r, ]
    m2 <- mrmr_predictions[mrmr_predictions$Repeat == r, ]
    data.frame(
      Repeat = r,
      Manual_AUC = safe_auc(m1$Truth, m1$Probability, positive, negative),
      MRMR_AUC = safe_auc(m2$Truth, m2$Probability, positive, negative)
    )
  })
  repeat_result <- do.call(rbind, repeat_rows)
  repeat_result$Delta_AUC_manual_minus_mrmr <- repeat_result$Manual_AUC - repeat_result$MRMR_AUC
  list(aggregate = aggregate_result, by_repeat = repeat_result,
       averaged_predictions = paired)
}

summarise_fixed_panel_coefficients <- function(coefficients, panel) {
  species <- panel$Species
  total_fits <- nrow(unique(coefficients[, c("Task", "Repeat", "Fold", "K")]))
  assert_true(total_fits > 0L, "manual panel contains no fitted coefficient records")
  rows <- lapply(species, function(term) {
    z <- coefficients[coefficients$Term == term, , drop = FALSE]
    nonzero <- z$Coefficient[z$Nonzero & is.finite(z$Coefficient)]
    positive_frequency <- if (length(nonzero)) mean(nonzero > 0) else NA_real_
    data.frame(
      Species = term,
      Nonzero_frequency = sum(z$Nonzero, na.rm = TRUE) / total_fits,
      Median_abs_nonzero_coefficient = if (length(nonzero)) median(abs(nonzero)) else NA_real_,
      Positive_coefficient_frequency = positive_frequency,
      Dominant_direction = if (!length(nonzero)) NA_character_ else
        if (positive_frequency >= .5) "Positive" else "Negative",
      Direction_consistency = if (!length(nonzero)) NA_real_ else
        max(positive_frequency, 1 - positive_frequency)
    )
  })
  out <- do.call(rbind, rows)
  out$Original_fixed_rank <- panel$Original_fixed_rank[match(out$Species, panel$Species)]
  out$Original_mean_rank <- panel$Original_mean_rank[match(out$Species, panel$Species)]
  out
}
