#!/usr/bin/env Rscript
# LASSO feature selection with unpenalized clinical covariates.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(glmnet)
  library(dplyr)
  library(tidyr)
  library(tibble)
})

input_files <- c(
  abundance = file.path(PUBLIC_DATA_DIR, "taxonomy_species.txt"),
  metadata = file.path(PUBLIC_DATA_DIR, "metadata_filtered.txt"),
  AP_candidates = file.path(PUBLIC_DATA_DIR, "species_for_adenoma.txt"),
  CRC_candidates = file.path(PUBLIC_DATA_DIR, "species_for_crc.txt")
)
assert_files_exist(input_files, "LASSO input")

abd_data <- read.delim(input_files[["abundance"]], row.names = 1, check.names = FALSE)
metadata <- read.delim(input_files[["metadata"]], row.names = 1, check.names = FALSE)
metadata$Sample_ID <- rownames(metadata)
metadata$Age <- suppressWarnings(as.numeric(as.character(metadata$Age)))
species_AP <- readLines(input_files[["AP_candidates"]], warn = FALSE)
species_CRC <- readLines(input_files[["CRC_candidates"]], warn = FALSE)
species_AP <- species_AP[nzchar(species_AP) & species_AP != "Species"]
species_CRC <- species_CRC[nzchar(species_CRC) & species_CRC != "Species"]

preprocess_for_lasso <- function(abundance, meta, target_group, species_list) {
  required_meta <- c("Group", "Age", "Gender", "Country")
  missing <- setdiff(required_meta, names(meta))
  if (length(missing)) stop("Metadata missing: ", paste(missing, collapse = ", "))
  sub_meta <- meta %>% filter(.data$Group %in% c(GROUP_HC, target_group)) %>%
    filter(complete.cases(Group, Age, Gender, Country))
  common_samples <- intersect(rownames(sub_meta), colnames(abundance))
  if (!length(common_samples)) stop("No common samples between metadata and abundance matrix.")
  sub_meta <- sub_meta[common_samples, , drop = FALSE]
  sub_abd <- abundance[, common_samples, drop = FALSE]
  valid_species <- intersect(species_list, rownames(sub_abd))
  if (!length(valid_species)) stop("No candidate species found in the abundance matrix.")
  sub_abd <- sub_abd[valid_species, , drop = FALSE]
  positive_values <- sub_abd[sub_abd > 0]
  if (!length(positive_values)) stop("All candidate abundances are zero.")
  pseudo_count <- min(positive_values, na.rm = TRUE) / 2
  sub_abd_log <- log2(sub_abd + pseudo_count)
  sub_abd_scaled <- scale(t(sub_abd_log))
  model_df <- data.frame(sub_meta[, required_meta, drop = FALSE], sub_abd_scaled,
                         check.names = FALSE)
  rownames(model_df) <- common_samples
  model_df$Group <- factor(ifelse(model_df$Group == GROUP_HC, GROUP_HC, target_group),
                           levels = c(GROUP_HC, target_group))
  model_df
}

run_lasso_analysis <- function(model_data, model_name, seed = 20260318L) {
  x_mat <- model.matrix(Group ~ ., data = model_data)[, -1L, drop = FALSE]
  y <- model_data$Group
  penalty_factors <- rep(1, ncol(x_mat))
  covariate_cols <- grep("Age|Gender|Country", colnames(x_mat))
  penalty_factors[covariate_cols] <- 0
  set.seed(seed)
  cv_fit <- cv.glmnet(x_mat, y, family = "binomial", alpha = 1,
                      penalty.factor = penalty_factors,
                      type.measure = "deviance", nfolds = 10)
  coef_mat <- as.matrix(coef(cv_fit, s = "lambda.1se"))
  coefficient_table <- data.frame(
    Feature = rownames(coef_mat), Coefficient = as.numeric(coef_mat[, 1L]),
    stringsAsFactors = FALSE
  ) %>% filter(Coefficient != 0, Feature != "(Intercept)")
  selected_species <- coefficient_table %>% filter(!grepl("Age|Gender|Country", Feature))
  list(model_name = model_name, cv_model = cv_fit,
       selected_features = coefficient_table, selected_species = selected_species,
       lambda_min = cv_fit$lambda.min, lambda_1se = cv_fit$lambda.1se)
}

data_AP <- preprocess_for_lasso(abd_data, metadata, GROUP_AP, species_AP)
data_CRC <- preprocess_for_lasso(abd_data, metadata, GROUP_CRC, species_CRC)
results_AP <- run_lasso_analysis(data_AP, "HC_vs_AP")
results_CRC <- run_lasso_analysis(data_CRC, "HC_vs_CRC")

ensure_dir(RESULTS$lasso)
write.table(results_AP$selected_species,
            file.path(RESULTS$lasso, "Species_for_Adenoma_1se.txt"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(results_CRC$selected_species,
            file.path(RESULTS$lasso, "Species_for_CRC_1se.txt"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(results_AP$selected_features,
            file.path(RESULTS$lasso, "AP_all_nonzero_coefficients.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(results_CRC$selected_features,
            file.path(RESULTS$lasso, "CRC_all_nonzero_coefficients.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
saveRDS(list(AP = results_AP, CRC = results_CRC),
        file.path(RESULTS$lasso, "lasso_models.rds"), compress = "xz")
write.table(data.frame(Task = c("AP", "CRC"),
                       Lambda_min = c(results_AP$lambda_min, results_CRC$lambda_min),
                       Lambda_1se = c(results_AP$lambda_1se, results_CRC$lambda_1se),
                       N_selected_species = c(nrow(results_AP$selected_species),
                                              nrow(results_CRC$selected_species))),
            file.path(RESULTS$lasso, "lasso_selection_summary.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

writeLines(capture.output(sessionInfo()), file.path(RESULTS$lasso, "sessionInfo.txt"), useBytes = TRUE)
