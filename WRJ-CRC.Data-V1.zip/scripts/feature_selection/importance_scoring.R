#!/usr/bin/env Rscript
# Composite species-importance scoring across Bayesian, SHAP, and KS evidence.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
})

input_files <- c(
  bayes_AP = file.path(RESULTS$bayesian, "Adenoma_bayes_results.txt"),
  bayes_CRC = file.path(RESULTS$bayesian, "CRC_bayes_results.txt"),
  shap_AP = file.path(RESULTS$random_forest, "Adenoma_Shap_Abs_Mean.txt"),
  shap_CRC = file.path(RESULTS$random_forest, "CRC_Shap_Abs_Mean.txt"),
  ks = file.path(PUBLIC_DATA_DIR, "Diff_ks.txt")
)
assert_files_exist(input_files, "importance-scoring input")
ks_results <- read.delim(input_files[["ks"]], check.names = FALSE)

robust_normalize <- function(x, probs = c(0.025, 0.975)) {
  x <- as.numeric(x)
  finite <- is.finite(x)
  if (!any(finite)) return(rep(NA_real_, length(x)))
  bounds <- stats::quantile(x[finite], probs = probs, na.rm = TRUE, names = FALSE)
  if (diff(bounds) <= .Machine$double.eps) return(ifelse(finite, 0.5, NA_real_))
  pmax(0, pmin(1, (x - bounds[1L]) / diff(bounds)))
}
weight_scenarios <- list(
  Bayes.3_RF.3_KS.3 = c(1/3, 1/3, 1/3),
  Bayes.5_RF.3_KS.2 = c(0.5, 0.3, 0.2),
  Bayes.3_RF.5_KS.2 = c(0.3, 0.5, 0.2),
  Bayes.3_RF.2_KS.5 = c(0.3, 0.2, 0.5),
  Bayes.6_RF.2_KS.2 = c(0.6, 0.2, 0.2),
  Bayes.2_RF.6_KS.2 = c(0.2, 0.6, 0.2),
  Bayes.2_RF.2_KS.6 = c(0.2, 0.2, 0.6),
  Bayes.4_RF.4_KS.2 = c(0.4, 0.4, 0.2),
  Bayes.2_RF.4_KS.4 = c(0.2, 0.4, 0.4),
  Bayes.4_RF.2_KS.4 = c(0.4, 0.2, 0.4),
  Bayes.1_RF.1_KS.8 = c(0.1, 0.1, 0.8),
  Bayes.1_RF.8_KS.1 = c(0.1, 0.8, 0.1),
  Bayes.8_RF.1_KS.1 = c(0.8, 0.1, 0.1)
)

score_one_task <- function(task, bayes_file, shap_file, ks_effect_column,
                           ks_median_column, output_prefix) {
  bayes <- read.delim(bayes_file, check.names = FALSE)
  shap <- read.delim(shap_file, check.names = FALSE)
  required_bayes <- c("Variable", "Estimate_Mean", "pd", "Correlation",
                      "CI_High", "CI_Low", "P_adj")
  required_shap <- c("feature", "mean_abs_shap")
  if (!all(required_bayes %in% names(bayes))) {
    stop("Bayesian results for ", task, " lack: ",
         paste(setdiff(required_bayes, names(bayes)), collapse = ", "))
  }
  if (!all(required_shap %in% names(shap))) {
    stop("SHAP results for ", task, " lack: ",
         paste(setdiff(required_shap, names(shap)), collapse = ", "))
  }
  if (!all(c("species_name", ks_effect_column, ks_median_column) %in% names(ks_results))) {
    stop("KS results lack the required columns for ", task, ".")
  }
  bayes$CI_Width <- abs(bayes$CI_High - bayes$CI_Low)
  bayes$CI_Precision <- abs(bayes$Estimate_Mean) / pmax(bayes$CI_Width, 1e-10)
  bayes$neg_log10_p_adj <- -log10(pmax(as.numeric(bayes$P_adj), .Machine$double.xmin))
  bayes$pd_norm <- robust_normalize(bayes$pd)
  bayes$effect_norm <- robust_normalize(abs(bayes$Estimate_Mean))
  bayes$cor_norm <- robust_normalize(abs(bayes$Correlation))
  bayes$sig_norm <- robust_normalize(bayes$neg_log10_p_adj)
  bayes$precision_norm <- robust_normalize(bayes$CI_Precision)
  bayes$bayes_geom <- sign(bayes$Estimate_Mean) * sqrt(bayes$pd_norm * bayes$effect_norm)
  bayes$cor_geom <- sign(bayes$Correlation) * sqrt(bayes$cor_norm * bayes$sig_norm)
  same_direction <- sign(bayes$Estimate_Mean) == sign(bayes$Correlation)
  evidence_strength <- sqrt(abs(bayes$bayes_geom) * abs(bayes$cor_geom))
  bayes$consistent_factor <- ifelse(same_direction, 1 + 0.2 * evidence_strength,
                                    1 - 0.3 * evidence_strength)
  bayes$bayes_score <- sign(bayes$Estimate_Mean) *
    exp(0.5 * log(pmax(abs(bayes$bayes_geom), 1e-10)) +
        0.3 * log(pmax(abs(bayes$cor_geom), 1e-10)) +
        0.2 * log(pmax(bayes$precision_norm, 1e-10))) * bayes$consistent_factor
  bayes$bayes_score_norm <- robust_normalize(abs(bayes$bayes_score))
  shap$shap_norm <- robust_normalize(shap$mean_abs_shap)
  ks <- data.frame(Variable = ks_results$species_name,
                   KS_median = ks_results[[ks_median_column]],
                   KS_effect = ks_results[[ks_effect_column]],
                   stringsAsFactors = FALSE)
  ks$ks_norm <- robust_normalize(abs(ks$KS_effect))
  combined <- bayes %>% select(Variable, Group, bayes_score_norm) %>%
    inner_join(shap %>% transmute(Variable = feature, shap_norm), by = "Variable") %>%
    inner_join(ks %>% select(Variable, KS_median, KS_effect, ks_norm), by = "Variable")
  if (!nrow(combined)) stop("No overlapping species across Bayesian, SHAP and KS inputs for ", task, ".")
  for (scenario in names(weight_scenarios)) {
    w <- weight_scenarios[[scenario]]
    combined[[scenario]] <- w[1] * combined$bayes_score_norm +
      w[2] * combined$shap_norm + w[3] * combined$ks_norm
  }
  rank_cols <- names(weight_scenarios)
  rank_table <- combined
  for (scenario in rank_cols) {
    rank_table[[paste0("rank_", scenario)]] <-
      rank(-rank_table[[scenario]], ties.method = "min")
  }
  rank_names <- grep("^rank_", names(rank_table), value = TRUE)
  rank_summary <- rank_table %>%
    mutate(mean_rank = rowMeans(across(all_of(rank_names)), na.rm = TRUE),
           sd_rank = apply(as.data.frame(across(all_of(rank_names))), 1, sd, na.rm = TRUE),
           rank_range = apply(as.data.frame(across(all_of(rank_names))), 1,
                              function(x) max(x, na.rm = TRUE) - min(x, na.rm = TRUE)),
           worst_rank = apply(as.data.frame(across(all_of(rank_names))), 1, max, na.rm = TRUE),
           best_rank = apply(as.data.frame(across(all_of(rank_names))), 1, min, na.rm = TRUE),
           stability_score = ifelse(max(sd_rank, na.rm = TRUE) > 0,
                                    1 - sd_rank / max(sd_rank, na.rm = TRUE), 1)) %>%
    arrange(mean_rank)
  ensure_dir(RESULTS$importance)
  write.table(combined, file.path(RESULTS$importance, paste0(output_prefix, "_composite_scores.tsv")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(rank_table, file.path(RESULTS$importance, paste0(output_prefix, "_rank_by_weight.tsv")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(rank_summary, file.path(RESULTS$importance, paste0(output_prefix, "_rank_summary.tsv")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(rank_summary, file.path(RESULTS$importance, paste0(output_prefix, "_rank_Species.txt")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  invisible(rank_summary)
}

rank_AP <- score_one_task(
  "AP", input_files[["bayes_AP"]], input_files[["shap_AP"]],
  ks_effect_column = "diff_ade_vs_hc", ks_median_column = "median_ade",
  output_prefix = "Adenoma"
)
rank_CRC <- score_one_task(
  "CRC", input_files[["bayes_CRC"]], input_files[["shap_CRC"]],
  ks_effect_column = "diff_crc_vs_hc", ks_median_column = "median_crc",
  output_prefix = "CRC"
)

writeLines(capture.output(sessionInfo()), file.path(RESULTS$importance, "sessionInfo.txt"), useBytes = TRUE)
