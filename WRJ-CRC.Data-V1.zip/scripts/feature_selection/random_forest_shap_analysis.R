#!/usr/bin/env Rscript
# Random-forest feature attribution using permutation importance and SHAP values.
# SHAP tables are retained because they are inputs to the composite species score.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(dplyr)
  library(ranger)
  library(fastshap)
  library(pROC)
})

input_files <- c(
  metadata = file.path(PUBLIC_DATA_DIR, "metadata_filtered.txt"),
  abundance = file.path(PUBLIC_DATA_DIR, "taxonomy_species.txt"),
  AP_features = file.path(RESULTS$lasso, "Species_for_Adenoma_1se.txt"),
  CRC_features = file.path(RESULTS$lasso, "Species_for_CRC_1se.txt")
)
assert_files_exist(input_files, "random-forest/SHAP input")
metadata <- read.delim(input_files[["metadata"]], check.names = FALSE)
sample_col <- if ("Sample_ID" %in% names(metadata)) "Sample_ID" else names(metadata)[1L]
metadata[[sample_col]] <- as.character(metadata[[sample_col]])
if (!"Sample_ID" %in% names(metadata)) metadata$Sample_ID <- metadata[[sample_col]]
metadata$Sample_ID <- as.character(metadata$Sample_ID)
rownames(metadata) <- metadata$Sample_ID
abundance <- read.delim(input_files[["abundance"]], row.names = 1, check.names = FALSE)
features_AP <- read.delim(input_files[["AP_features"]], check.names = FALSE)$Feature
features_CRC <- read.delim(input_files[["CRC_features"]], check.names = FALSE)$Feature

split_stratified <- function(group, proportion = 0.70, seed = 20260123L) {
  set.seed(seed)
  unlist(lapply(split(seq_along(group), group), function(idx) {
    n_train <- max(1L, min(length(idx) - 1L, floor(length(idx) * proportion)))
    sample(idx, n_train)
  }), use.names = FALSE)
}
run_rf_shap <- function(task, positive_group, feature_list, mtry, min_node_size,
                        class_weight = 1, seed = 20260316L) {
  common_features <- intersect(feature_list, rownames(abundance))
  if (!length(common_features)) stop("No selected species found for ", task, ".")
  common_samples <- intersect(metadata$Sample_ID, colnames(abundance))
  task_meta <- metadata[common_samples, , drop = FALSE] %>%
    filter(.data$Group %in% c(GROUP_HC, positive_group))
  sample_ids <- as.character(task_meta$Sample_ID)
  if (length(sample_ids) < 10L) stop("Too few samples for random forest task ", task, ".")
  if (any(table(task_meta$Group) < 2L)) stop("At least two samples per class are required for ", task, ".")
  feature_matrix <- t(as.matrix(abundance[common_features, sample_ids, drop = FALSE]))
  storage.mode(feature_matrix) <- "double"
  model_data <- data.frame(feature_matrix, check.names = FALSE)
  rownames(model_data) <- sample_ids
  model_data$Group <- factor(task_meta$Group, levels = c(GROUP_HC, positive_group))
  complete <- complete.cases(model_data)
  model_data <- model_data[complete, , drop = FALSE]
  if (length(unique(model_data$Group)) != 2L) stop("Both classes are required for ", task, ".")
  train_idx <- split_stratified(model_data$Group, seed = seed)
  test_idx <- setdiff(seq_len(nrow(model_data)), train_idx)
  train_data <- model_data[train_idx, , drop = FALSE]
  test_data <- model_data[test_idx, , drop = FALSE]
  p <- ncol(train_data) - 1L
  if (p < 1L) stop("No predictor features available for ", task, ".")
  mtry_use <- min(as.integer(mtry), p)
  weights <- c(1, class_weight)
  names(weights) <- c(GROUP_HC, positive_group)
  fit <- ranger::ranger(
    Group ~ ., data = train_data, num.trees = 1000L, mtry = mtry_use,
    min.node.size = as.integer(min_node_size), min.bucket = 10L,
    splitrule = "gini", importance = "permutation",
    class.weights = weights, probability = TRUE, seed = seed
  )
  predict_positive <- function(object, newdata) {
    as.numeric(predict(object, data = newdata)$predictions[, positive_group])
  }
  shap <- fastshap::explain(
    fit, X = train_data[, setdiff(names(train_data), "Group"), drop = FALSE],
    pred_wrapper = predict_positive, nsim = 100L, adjust = TRUE
  )
  shap_summary <- data.frame(
    feature = colnames(shap), mean_abs_shap = colMeans(abs(shap), na.rm = TRUE),
    mean_shap = colMeans(shap, na.rm = TRUE), stringsAsFactors = FALSE
  ) %>% arrange(desc(mean_abs_shap))
  shap_group <- aggregate(as.data.frame(shap), by = list(Group = train_data$Group), FUN = mean)
  row_positive <- shap_group[shap_group$Group == positive_group, -1L, drop = FALSE]
  row_negative <- shap_group[shap_group$Group == GROUP_HC, -1L, drop = FALSE]
  if (nrow(row_positive) != 1L || nrow(row_negative) != 1L) {
    stop("Could not calculate group-specific SHAP summaries for ", task, ".")
  }
  difference <- row_positive - row_negative
  difference$Group <- paste0("Diff(", positive_group, "-", GROUP_HC, ")")
  shap_group <- bind_rows(shap_group, difference[, c("Group", names(shap_group)[-1L])])
  shap_group_long <- as.data.frame(t(shap_group[, -1L, drop = FALSE]), check.names = FALSE)
  names(shap_group_long) <- shap_group$Group
  shap_group_long$feature <- rownames(shap_group_long)
  shap_group_long <- shap_group_long[, c("feature", setdiff(names(shap_group_long), "feature"))]
  test_prob <- predict(fit, data = test_data[, setdiff(names(test_data), "Group"), drop = FALSE])$predictions[, positive_group]
  roc_obj <- pROC::roc(test_data$Group, test_prob, levels = c(GROUP_HC, positive_group),
                       direction = "<", quiet = TRUE)
  perf <- data.frame(Task = task, N_train = nrow(train_data), N_test = nrow(test_data),
                     AUC_test = as.numeric(pROC::auc(roc_obj)),
                     stringsAsFactors = FALSE)
  list(model = fit, shap = shap, shap_summary = shap_summary,
       shap_by_group = shap_group_long, performance = perf,
       train_samples = rownames(train_data), test_samples = rownames(test_data),
       importance = data.frame(feature = names(fit$variable.importance),
                               permutation_importance = as.numeric(fit$variable.importance)))
}

ensure_dir(RESULTS$random_forest)
result_AP <- run_rf_shap("AP", GROUP_AP, features_AP, mtry = 5L,
                         min_node_size = 20L, class_weight = 4, seed = 20260316L)
result_CRC <- run_rf_shap("CRC", GROUP_CRC, features_CRC, mtry = 8L,
                          min_node_size = 30L, class_weight = 1, seed = 20260317L)
for (entry in list(AP = result_AP, CRC = result_CRC)) {
  task <- entry$performance$Task
  prefix <- if (task == "AP") "Adenoma" else "CRC"
  saveRDS(entry$model, file.path(RESULTS$random_forest, paste0(prefix, "_ranger_model.rds")),
          compress = "xz")
  saveRDS(entry$shap, file.path(RESULTS$random_forest, paste0(prefix, "_All_Shap.rds")),
          compress = "xz")
  write.table(entry$shap_summary,
              file.path(RESULTS$random_forest, paste0(prefix, "_Shap_Abs_Mean.txt")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(entry$shap_by_group,
              file.path(RESULTS$random_forest, paste0(prefix, "_Shap_Mean_by_Group.txt")),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(entry$importance,
              file.path(RESULTS$random_forest, paste0(prefix, "_permutation_importance.tsv")),
              sep = "\t", row.names = FALSE, quote = FALSE)
}
write.table(bind_rows(result_AP$performance, result_CRC$performance),
            file.path(RESULTS$random_forest, "random_forest_test_performance.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

writeLines(capture.output(sessionInfo()), file.path(RESULTS$random_forest, "sessionInfo.txt"), useBytes = TRUE)
