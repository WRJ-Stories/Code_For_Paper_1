#!/usr/bin/env Rscript
# Bayesian logistic regression and Spearman association analysis.
# The resulting posterior summaries are used by the composite species-ranking step.
source(file.path("config", "project_paths.R"))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(brms)
  library(posterior)
})

input_files <- c(
  metadata = file.path(PUBLIC_DATA_DIR, "metadata_filtered.txt"),
  abundance = file.path(PUBLIC_DATA_DIR, "taxonomy_species.txt"),
  AP_features = file.path(RESULTS$lasso, "Species_for_Adenoma_1se.txt"),
  CRC_features = file.path(RESULTS$lasso, "Species_for_CRC_1se.txt")
)
assert_files_exist(input_files, "Bayesian regression input")

metadata <- read.delim(input_files[["metadata"]], row.names = 1, check.names = FALSE)
species <- read.delim(input_files[["abundance"]], row.names = 1, check.names = FALSE)
features_AP <- read.delim(input_files[["AP_features"]], check.names = FALSE)$Feature
features_CRC <- read.delim(input_files[["CRC_features"]], check.names = FALSE)$Feature

species_t <- as.data.frame(t(as.matrix(species)), check.names = FALSE)
common_samples <- intersect(rownames(species_t), rownames(metadata))
if (!length(common_samples)) stop("No common samples between metadata and species abundance.")
species_t <- species_t[common_samples, , drop = FALSE]
metadata <- metadata[common_samples, , drop = FALSE]
storage.mode(species_t) <- "double"
positive_values <- unlist(species_t[species_t > 0], use.names = FALSE)
if (!length(positive_values)) stop("The abundance matrix contains no positive values.")
pseudo_count <- min(positive_values, na.rm = TRUE) / 2
species_scaled <- as.data.frame(scale(log2(species_t + pseudo_count)), check.names = FALSE)
original_feature_names <- colnames(species_scaled)
colnames(species_scaled) <- sub("^s__", "", original_feature_names)
model_data <- cbind(metadata, species_scaled)
model_data$Age <- suppressWarnings(as.numeric(as.character(model_data$Age)))
model_data$Gender <- factor(model_data$Gender, levels = c("female", "male"))
model_data$Country <- factor(model_data$Country)
model_data <- model_data %>% select(-any_of(c("Cohort", "Project_ID", "Sequencing_method",
                                               "Geographic.location", "BMI"))) %>%
  filter(complete.cases(Age, Gender, Country, Group))

run_bayesian_model <- function(data, target_group, ref_group, species_features,
                               model_name, seed = 20260317L) {
  sub_data <- data %>% filter(Group %in% c(ref_group, target_group)) %>% droplevels()
  if (nrow(sub_data) == 0L || length(unique(sub_data$Group)) != 2L) {
    stop("Both groups are required for ", model_name, ". Check WRJCRC_GROUP_AP / metadata Group labels.")
  }
  valid_features <- intersect(gsub("^s__", "", species_features), colnames(sub_data))
  if (!length(valid_features)) stop("No selected species features available for ", model_name, ".")
  sub_data$Group <- factor(sub_data$Group, levels = c(ref_group, target_group))
  formula_str <- paste("Group ~ Gender + Age + (1 | Country) +",
                       paste(sprintf("`%s`", valid_features), collapse = " + "))
  priors <- c(
    brms::set_prior(brms::horseshoe(df = 1, par_ratio = 0.1), class = "b"),
    brms::set_prior("normal(0, 5)", class = "Intercept"),
    brms::set_prior("student_t(3, 0, 2.5)", class = "sd")
  )
  fit <- brms::brm(
    formula = brms::bf(stats::as.formula(formula_str)), data = sub_data,
    family = brms::bernoulli(link = "logit"), prior = priors,
    chains = 4, iter = 4000, warmup = 2000, cores = 4, seed = seed,
    control = list(adapt_delta = 0.99, max_treedepth = 15),
    refresh = 0
  )
  message("Completed Bayesian model: ", model_name)
  fit
}

fit_AP <- run_bayesian_model(model_data, GROUP_AP, GROUP_HC, features_AP, "HC_vs_AP")
fit_CRC <- run_bayesian_model(model_data, GROUP_CRC, GROUP_HC, features_CRC, "HC_vs_CRC")
ensure_dir(RESULTS$bayesian)
saveRDS(fit_AP, file.path(RESULTS$bayesian, "adenoma_bayes_model.rds"), compress = "xz")
saveRDS(fit_CRC, file.path(RESULTS$bayesian, "crc_bayes_model.rds"), compress = "xz")

extract_posterior_summary <- function(fit, output_group) {
  posterior::as_draws_df(fit) %>%
    select(starts_with("b_"), -any_of("b_Intercept")) %>%
    pivot_longer(cols = everything(), names_to = "Parameter", values_to = "Value") %>%
    mutate(Variable = paste0("s__", sub("^b_", "", Parameter)),
           Group = output_group)
}
posterior_draws <- bind_rows(
  extract_posterior_summary(fit_AP, "Adenoma"),
  extract_posterior_summary(fit_CRC, "CRC")
)
bayes_result_table <- posterior_draws %>%
  group_by(Variable, Group) %>%
  summarise(
    Estimate_Mean = mean(Value),
    CI_Low = quantile(Value, 0.025),
    CI_High = quantile(Value, 0.975),
    pd = max(mean(Value > 0), mean(Value < 0)),
    p_positive = mean(Value > 0),
    p_negative = mean(Value < 0),
    .groups = "drop"
  )

calculate_correlation <- function(data, species_features, target_col = "Group_numeric",
                                  method = "spearman", adjust_method = "BH") {
  valid_species <- intersect(gsub("^s__", "", species_features), colnames(data))
  results <- lapply(valid_species, function(feature) {
    x <- as.numeric(data[[feature]])
    y <- as.numeric(data[[target_col]])
    keep <- is.finite(x) & is.finite(y)
    if (sum(keep) < 3L || length(unique(x[keep])) < 2L || length(unique(y[keep])) < 2L) {
      return(data.frame(Variable = paste0("s__", feature),
                        Correlation = NA_real_, P_value = 1))
    }
    test <- suppressWarnings(stats::cor.test(x[keep], y[keep],
                                              method = method, exact = FALSE))
    data.frame(Variable = paste0("s__", feature),
               Correlation = unname(test$estimate), P_value = test$p.value)
  })
  if (!length(results)) stop("No valid species available for correlation analysis.")
  bind_rows(results) %>%
    mutate(P_adj = p.adjust(P_value, method = adjust_method)) %>%
    arrange(P_adj)
}
make_task_data <- function(data, positive_group, negative_group) {
  data %>% filter(Group %in% c(negative_group, positive_group)) %>%
    mutate(Group_numeric = as.integer(Group == positive_group)) %>% droplevels()
}
task_AP <- make_task_data(model_data, GROUP_AP, GROUP_HC)
task_CRC <- make_task_data(model_data, GROUP_CRC, GROUP_HC)
cor_AP <- calculate_correlation(task_AP, features_AP)
cor_CRC <- calculate_correlation(task_CRC, features_CRC)

combine_bayesian_and_correlation <- function(group_name, correlation_table, feature_list) {
  bayes <- bayes_result_table %>% filter(Group == group_name)
  bayes %>% inner_join(correlation_table, by = "Variable") %>%
    filter(Variable %in% paste0("s__", gsub("^s__", "", feature_list)),
           is.finite(Correlation)) %>%
    arrange(desc(abs(Estimate_Mean)))
}
result_AP <- combine_bayesian_and_correlation("Adenoma", cor_AP, features_AP)
result_CRC <- combine_bayesian_and_correlation("CRC", cor_CRC, features_CRC)
if (!nrow(result_AP) || !nrow(result_CRC)) {
  stop("Bayesian/correlation result merge is empty. Check feature names and group labels.")
}
write.table(result_AP, file.path(RESULTS$bayesian, "Adenoma_bayes_results.txt"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(result_CRC, file.path(RESULTS$bayesian, "CRC_bayes_results.txt"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(bind_rows(result_AP, result_CRC),
            file.path(RESULTS$bayesian, "combined_bayesian_association_results.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

capture.output(summary(fit_AP), file = file.path(RESULTS$bayesian, "adenoma_model_summary.txt"))
capture.output(summary(fit_CRC), file = file.path(RESULTS$bayesian, "crc_model_summary.txt"))
writeLines(capture.output(sessionInfo()), file.path(RESULTS$bayesian, "sessionInfo.txt"), useBytes = TRUE)
