# Local input data

This directory is reserved for input data required by the analysis scripts. No input data are distributed in this repository. Place authorized local files in the relevant subdirectories (`public_cohort/`, `ap_meta_analysis/`, and `clinical_cohort/`).

All data files under this directory are excluded from Git. Do not override this protection unless public redistribution has been explicitly approved and all applicable ethics, consent, institutional, and data-use requirements have been satisfied. For the clinical cohort, the current filenames are `NF_Cohort_1.txt` and `NF_Cohort2.txt`. In `NF_Cohort2.txt`, `ID` identifies the participant and `Sequence_ID` identifies the sequencing sample used to match abundance and functional tables. The former `EP_ID` and `SampleID` fields are not required. See the root `README.md` for the complete expected filenames and schemas.
